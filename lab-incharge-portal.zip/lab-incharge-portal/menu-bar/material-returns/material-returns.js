// Shared Front-end controller, Navigation systems, and database initialization

// Define default database structure
const DEFAULT_DATABASE = {
    currentUser: {
        username: "priya.sharma@rplms.com",
        name: "Dr. Priya Sharma",
        role: "Lab Incharge",
        avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150",
        status: "Online",
        location: "Main Lab Complex",
        timezone: "IST (UTC+5:30)",
        email: "priya.sharma@rplms.com",
        phone: "+91 98765 43210"
    },

    notifications: [
        { id: "NTF-001", icon: "📦", iconClass: "notif-icon-request", body: "TEAM-001 has submitted a new component request for Arduino Mega boards.", time: "2 min ago", unread: true },
        { id: "NTF-002", icon: "⏰", iconClass: "notif-icon-overdue", body: "TEAM-006 has 1 overdue equipment return — Raspberry Pi 4 (EQ-011).", time: "18 min ago", unread: true },
        { id: "NTF-003", icon: "🎫", iconClass: "notif-icon-ticket", body: "New damage ticket TKT-007 raised by TEAM-002 for Digital Oscilloscope.", time: "1 hr ago", unread: true },
        { id: "NTF-004", icon: "✅", iconClass: "notif-icon-info", body: "Component request REQ-012 for resistors was approved and marked fulfilled.", time: "3 hrs ago", unread: false },
        { id: "NTF-005", icon: "📋", iconClass: "notif-icon-request", body: "TEAM-005 submitted a material return for Soldering Station (EQ-012).", time: "5 hrs ago", unread: false },
        { id: "NTF-006", icon: "⚠️", iconClass: "notif-icon-overdue", body: "Inventory alert: 3D Printer (EQ-001) maintenance is due this week.", time: "Yesterday", unread: false }
    ],

    teams: [
        { id: "TEAM-001", name: "Solar Car Project", leader: "Anil Mehta", membersCount: 8, activeProjects: 2, status: "Active" },
        { id: "TEAM-002", name: "Drone Flight Tech", leader: "Vikas Pillai", membersCount: 5, activeProjects: 1, status: "Active" },
        { id: "TEAM-003", name: "Bio-Sensor Systems", leader: "Sarah Khan", membersCount: 6, activeProjects: 2, status: "Active" },
        { id: "TEAM-004", name: "Haptic Arm Development", leader: "John Doe", membersCount: 4, activeProjects: 1, status: "Suspended" },
        { id: "TEAM-005", name: "Smart Irrigation System", leader: "Rajesh Kumar", membersCount: 7, activeProjects: 2, status: "Active" },
        { id: "TEAM-006", name: "Eco Waste sorter", leader: "Deepa Nair", membersCount: 6, activeProjects: 1, status: "Active" },
        { id: "TEAM-007", name: "VTOL UAV Propulsion", leader: "Karan Johar", membersCount: 9, activeProjects: 3, status: "Active" },
        { id: "TEAM-008", name: "3D Prosthetic Hand", leader: "Aditi Rao", membersCount: 5, activeProjects: 1, status: "Active" },
        { id: "TEAM-009", name: "Autonomous AGV", leader: "Sanjay Dutt", membersCount: 6, activeProjects: 2, status: "Active" },
        { id: "TEAM-010", name: "Water Purifier IoT", leader: "Rita Sen", membersCount: 4, activeProjects: 1, status: "Active" },
        { id: "TEAM-011", name: "Robotics Arm Team", leader: "Preeti Zinta", membersCount: 7, activeProjects: 2, status: "Active" },
        { id: "TEAM-012", name: "Smart Traffic Guard", leader: "Amir Khan", membersCount: 5, activeProjects: 1, status: "Active" },
        { id: "TEAM-013", name: "Ocean Cleaner Probe", leader: "Shruti Roy", membersCount: 8, activeProjects: 2, status: "Active" },
        { id: "TEAM-014", name: "RFID Warehouse Robot", leader: "Abhay Singh", membersCount: 6, activeProjects: 1, status: "Active" },
        { id: "TEAM-015", name: "Waste Management", leader: "Nikhil Joshi", membersCount: 7, activeProjects: 1, status: "Active" },
        { id: "TEAM-016", name: "Exoskeleton Suit", leader: "Meera Iyer", membersCount: 6, activeProjects: 2, status: "Active" },
        { id: "TEAM-017", name: "Nano Filtration Unit", leader: "Arjun Verma", membersCount: 5, activeProjects: 1, status: "Active" },
        { id: "TEAM-018", name: "AI Crop Monitor", leader: "Pooja Reddy", membersCount: 7, activeProjects: 2, status: "Active" },
        { id: "TEAM-019", name: "Swarm Robotics Lab", leader: "Farhan Qureshi", membersCount: 8, activeProjects: 3, status: "Active" },
        { id: "TEAM-020", name: "EV Charging Station", leader: "Kavya Menon", membersCount: 6, activeProjects: 1, status: "Active" },
        { id: "TEAM-021", name: "Underwater ROV", leader: "Rohan Desai", membersCount: 5, activeProjects: 2, status: "Active" }
    ],
    equipment: [
        {
            sno: 1,
            eqpid: "EQP001",
            componentName: "3D Printer",
            make: "Creality",
            specification: "Ender 3 V2",
            totalCount: 3,
            componentType: "Manufacturing Equipment",
            lab: "Mechanical Lab",
            remarks: "Working Fine"
        },
        {
            sno: 2,
            eqpid: "EQP002",
            componentName: "Laser Cutter",
            make: "Ortur",
            specification: "Laser Master 2",
            totalCount: 10,
            componentType: "Manufacturing Equipment",
            lab: "Mechanical Lab",
            remarks: "Service Due"
        },
        {
            sno: 3,
            eqpid: "EQP003",
            componentName: "CNC Machine",
            make: "Genmitsu",
            specification: "3018-PRO",
            totalCount: 5,
            componentType: "Manufacturing Equipment",
            lab: "Manufacturing Lab",
            remarks: "Operational"
        }
    ],

    components: [
        {
            sno: 1,
            cid: "CID001",
            componentName: "Arduino Uno",
            make: "Arduino",
            specification: "ATmega328P",
            cost: 850,
            returnTimeline: "Project Completion",
            totalCount: 40,
            componentType: "Electronics",
            lab: "Embedded Lab",
            cupboard: "CUP-1",
            shelf1: "A1",
            count1: 20,
            shelf2: "A2",
            count2: 20,
            purpose: "Student Projects",
            comments: "Available"
        },
        {
            sno: 2,
            cid: "CID002",
            componentName: "Raspberry Pi 4",
            make: "Raspberry",
            specification: "8GB RAM",
            cost: 7000,
            returnTimeline: "Project Completion",
            totalCount: 15,
            componentType: "Embedded",
            lab: "IoT Lab",
            cupboard: "CUP-2",
            shelf1: "B1",
            count1: 8,
            shelf2: "B2",
            count2: 7,
            purpose: "Research",
            comments: "Limited"
        }
    ],

    tools: [
        {
            sno: 1,
            toolid: "T001",
            componentName: "Screw Driver Set",
            make: "Bosch",
            specification: "Professional Kit",
            cost: 2500,
            returnTimeline: "Daily",
            totalCount: 10,
            componentType: "Hand Tool",
            lab: "Mechanical Lab",
            cupboard: "CUP-5",
            shelf1: "A1",
            count1: 5,
            shelf2: "A2",
            count2: 5,
            purpose: "Maintenance",
            comments: "Good Condition"
        },
        {
            sno: 2,
            toolid: "T002",
            componentName: "Soldering Iron",
            make: "Hakko",
            specification: "60W",
            cost: 3200,
            returnTimeline: "Daily",
            totalCount: 12,
            componentType: "Electronic Tool",
            lab: "Embedded Lab",
            cupboard: "CUP-6",
            shelf1: "B1",
            count1: 6,
            shelf2: "B2",
            count2: 6,
            purpose: "PCB Assembly",
            comments: "Available"
        }
    ],

    inventory: [
        { id: "EQ-001", name: "3D Printer", type: "Equipment", manufacturer: "Creality", model: "Ender-3 V2", serial: "CRL-3DV2-2024-1125", location: "Mechanical Lab", status: "Available", dateAdded: "2025-06-15", description: "FDM 3D printer used for rapid prototyping and model making." },
        { id: "EQ-002", name: "Arduino Uno R3", type: "Component", manufacturer: "Arduino", model: "Uno Rev 3", serial: "ARD-UNO-99382", location: "Electronics Lab", status: "Available", dateAdded: "2025-01-10", description: "Microcontroller board based on the ATmega328P." },
        { id: "EQ-003", name: "Ultrasonic Sensor", type: "Component", manufacturer: "Elegoo", model: "HC-SR04", serial: "EL-HC-2092", location: "Electronics Lab", status: "Available", dateAdded: "2025-02-14", description: "Ultrasonic distance sensor module." },
        { id: "EQ-004", name: "Soil Moisture Sensor", type: "Component", manufacturer: "Generic", model: "YL-69", serial: "GEN-YL-77291", location: "Bio Lab", status: "Available", dateAdded: "2025-03-01", description: "Resistance-based soil moisture measurement probe." },
        { id: "EQ-005", name: "CNC Milling Machine", type: "Equipment", manufacturer: "SainSmart", model: "Genmitsu 3018-PRO", serial: "CNC-GEN-8827", location: "Mechanical Lab", status: "Maintenance", dateAdded: "2025-04-18", description: "Desktop CNC router for wood, acrylic, and PCB engraving." },
        { id: "EQ-006", name: "Digital Oscilloscope", type: "Equipment", manufacturer: "Rigol", model: "DS1202Z-E", serial: "RIG-DS-44932", location: "Electronics Lab", status: "Available", dateAdded: "2025-02-28", description: "200 MHz, 2-channel digital storage oscilloscope." },
        { id: "EQ-007", name: "DC Motor 12V", type: "Component", manufacturer: "Generic", model: "RS-555", serial: "GEN-DC-38291", location: "Mechanical Lab", status: "Available", dateAdded: "2025-05-02", description: "High torque 12V DC motor." },
        { id: "EQ-008", name: "16x2 LCD Display", type: "Component", manufacturer: "Generic", model: "HD44780", serial: "GEN-LCD-10293", location: "Electronics Lab", status: "Available", dateAdded: "2025-03-12", description: "Alpha-numeric display module with purple backlight." },
        { id: "EQ-009", name: "Li-ion Battery 18650", type: "Component", manufacturer: "Samsung", model: "25R 2500mAh", serial: "SAM-186-8291", location: "Electronics Lab", status: "Available", dateAdded: "2025-04-05", description: "High-discharge rechargeable lithium-ion cell." },
        { id: "EQ-010", name: "Laser Cutter", type: "Equipment", manufacturer: "Ortur", model: "Laser Master 2 Pro", serial: "ORT-LM2-88271", location: "Mechanical Lab", status: "Available", dateAdded: "2025-05-20", description: "Diode laser engraving and cutting machine." },
        { id: "EQ-011", name: "Raspberry Pi 4", type: "Component", manufacturer: "Raspberry Pi", model: "Model B 8GB", serial: "RPi4-8G-0029", location: "Electronics Lab", status: "Available", dateAdded: "2025-01-16", description: "Single board computer with 8GB RAM." },
        { id: "EQ-012", name: "Soldering Station", type: "Equipment", manufacturer: "Hakko", model: "FX-888D", serial: "HAK-FX-2023", location: "Electronics Lab", status: "Available", dateAdded: "2025-02-05", description: "Digital soldering station with temperature control." },
        { id: "EQ-013", name: "Bench Multimeter", type: "Equipment", manufacturer: "Fluke", model: "8808A", serial: "FLU-88-82910", location: "Electronics Lab", status: "Available", dateAdded: "2025-03-24", description: "5.5 digit precision benchtop digital multimeter." },
        { id: "EQ-014", name: "Bipolar NEMA 17", type: "Component", manufacturer: "Stepperonline", model: "17HS19", serial: "STEP-N17-3829", location: "Mechanical Lab", status: "Available", dateAdded: "2025-04-11", description: "High-torque stepper motor for CNC/3D Printers." },
        { id: "EQ-015", name: "LiPo Battery 11.1V", type: "Component", manufacturer: "Tattu", model: "2200mAh 3S 45C", serial: "TAT-LIPO-223", location: "Electronics Lab", status: "Available", dateAdded: "2025-05-30", description: "Lithium polymer pack for drones and RC vehicles." },
        { id: "EQ-016", name: "Hot Air Rework Station", type: "Equipment", manufacturer: "Quick", model: "861DW", serial: "QUI-861-9021", location: "Electronics Lab", status: "Available", dateAdded: "2025-02-12", description: "1000W professional lead-free hot air rework station." },
        { id: "EQ-017", name: "PIR Motion Sensor", type: "Component", manufacturer: "Adafruit", model: "HC-SR501", serial: "ADA-PIR-3329", location: "Electronics Lab", status: "Available", dateAdded: "2025-03-10", description: "Pyroelectric infrared motion detection module." },
        { id: "EQ-018", name: "Variable DC Power Supply", type: "Equipment", manufacturer: "Korado", model: "KA3005D", serial: "KOR-PWR-3829", location: "Electronics Lab", status: "Available", dateAdded: "2025-02-22", description: "Precision programmable DC linear power supply, 30V/5A." },
        { id: "EQ-019", name: "3D Scanner", type: "Equipment", manufacturer: "EinScan", model: "SE V2", serial: "EIN-SCAN-4822", location: "Mechanical Lab", status: "Available", dateAdded: "2025-06-02", description: "Desktop white light 3D scanner for modeling." },
        { id: "EQ-020", name: "Co2 Laser Tube", type: "Component", manufacturer: "RECI", model: "W2 90W", serial: "REC-CO2-9902", location: "Mechanical Lab", status: "Repairing", dateAdded: "2025-05-15", description: "CO2 glass laser tube replacement part." }
    ],

    materialRequests: [
        { id: "REQ-001", teamId: "TEAM-001", teamName: "Solar Car Project", item: "Li-ion Battery 18650", avail: 30, qty: 24, status: "Fully Issued", date: "2025-07-02", slot: "2.00-3.00" },
        { id: "REQ-002", teamId: "TEAM-005", teamName: "Smart Irrigation System", item: "Soil Moisture Sensor", avail: 30, qty: 5, status: "Pending", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-003", teamId: "TEAM-003", teamName: "Bio-Sensor Systems", item: "Arduino Uno R3", avail: 30, qty: 3, status: "Fully Issued", date: "2025-07-01", slot: "2.00-3.00" },
        { id: "REQ-004", teamId: "TEAM-011", teamName: "Robotics Arm Team", item: "DC Motor 12V", avail: 30, qty: 6, status: "Rejected", date: "2025-06-30", slot: "2.00-3.00" },
        { id: "REQ-005", teamId: "TEAM-002", teamName: "Drone Flight Tech", item: "LiPo Battery 11.1V", avail: 30, qty: 4, status: "Pending", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-006", teamId: "TEAM-008", teamName: "3D Prosthetic Hand", item: "Bipolar NEMA 17", avail: 30, qty: 10, status: "Fully Issued", date: "2025-06-28", slot: "2.00-3.00" },
        { id: "REQ-007", teamId: "TEAM-009", teamName: "Autonomous AGV", item: "Arduino Uno R3", avail: 30, qty: 2, status: "Pending", date: "2025-07-04", slot: "2.00-3.00" },
        { id: "REQ-008", teamId: "TEAM-015", teamName: "Waste Management", item: "Ultrasonic Sensor", avail: 30, qty: 4, status: "Fully Issued", date: "2025-06-27", slot: "2.00-3.00" },
        { id: "REQ-009", teamId: "TEAM-001", teamName: "Solar Car Project", item: "Raspberry Pi 4", avail: 30, qty: 2, status: "Pending", date: "2025-07-05", slot: "2.00-3.00" },
        { id: "REQ-010", teamId: "TEAM-002", teamName: "Drone Flight Tech", item: "PIR Motion Sensor", avail: 30, qty: 6, status: "Fully Issued", date: "2025-06-29", slot: "2.00-3.00" },
        { id: "REQ-011", teamId: "TEAM-003", teamName: "Bio-Sensor Systems", item: "16x2 LCD Display", avail: 30, qty: 4, status: "Pending", date: "2025-07-05", slot: "2.00-3.00" },
        { id: "REQ-012", teamId: "TEAM-004", teamName: "Haptic Arm Development", item: "Bipolar NEMA 17", avail: 30, qty: 3, status: "Rejected", date: "2025-06-26", slot: "2.00-3.00" },
        { id: "REQ-013", teamId: "TEAM-005", teamName: "Smart Irrigation System", item: "Arduino Uno R3", avail: 30, qty: 5, status: "Fully Issued", date: "2025-07-01", slot: "2.00-3.00" },
        { id: "REQ-014", teamId: "TEAM-006", teamName: "Eco Waste Sorter", item: "Raspberry Pi 4", avail: 30, qty: 1, status: "Pending", date: "2025-07-04", slot: "2.00-3.00" },
        { id: "REQ-015", teamId: "TEAM-006", teamName: "Eco Waste Sorter", item: "Ultrasonic Sensor", avail: 30, qty: 8, status: "Fully Issued", date: "2025-06-30", slot: "2.00-3.00" },
        { id: "REQ-016", teamId: "TEAM-007", teamName: "VTOL UAV Propulsion", item: "LiPo Battery 11.1V", avail: 30, qty: 6, status: "Fully Issued", date: "2025-07-02", slot: "2.00-3.00" },
        { id: "REQ-017", teamId: "TEAM-007", teamName: "VTOL UAV Propulsion", item: "DC Motor 12V", avail: 30, qty: 4, status: "Pending", date: "2025-07-05", slot: "2.00-3.00" },
        { id: "REQ-018", teamId: "TEAM-008", teamName: "3D Prosthetic Hand", item: "Li-ion Battery 18650", avail: 30, qty: 8, status: "Pending", date: "2025-07-04", slot: "2.00-3.00" },
        { id: "REQ-019", teamId: "TEAM-009", teamName: "Autonomous AGV", item: "PIR Motion Sensor", avail: 30, qty: 5, status: "Fully Issued", date: "2025-06-28", slot: "2.00-3.00" },
        { id: "REQ-020", teamId: "TEAM-010", teamName: "Water Purifier IoT", item: "Soil Moisture Sensor", avail: 30, qty: 6, status: "Fully Issued", date: "2025-07-01", slot: "2.00-3.00" },
        { id: "REQ-021", teamId: "TEAM-010", teamName: "Water Purifier IoT", item: "Arduino Uno R3", avail: 30, qty: 2, status: "Pending", date: "2025-07-05", slot: "2.00-3.00" },
        { id: "REQ-022", teamId: "TEAM-011", teamName: "Robotics Arm Team", item: "Bipolar NEMA 17", avail: 30, qty: 8, status: "Fully Issued", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-023", teamId: "TEAM-012", teamName: "Smart Traffic Guard", item: "Raspberry Pi 4", avail: 30, qty: 2, status: "Fully Issued", date: "2025-06-29", slot: "2.00-3.00" },
        { id: "REQ-024", teamId: "TEAM-012", teamName: "Smart Traffic Guard", item: "PIR Motion Sensor", avail: 30, qty: 10, status: "Pending", date: "2025-07-04", slot: "2.00-3.00" },
        { id: "REQ-025", teamId: "TEAM-013", teamName: "Ocean Cleaner Probe", item: "DC Motor 12V", avail: 30, qty: 3, status: "Fully Issued", date: "2025-07-02", slot: "2.00-3.00" },
        { id: "REQ-026", teamId: "TEAM-013", teamName: "Ocean Cleaner Probe", item: "Li-ion Battery 18650", avail: 30, qty: 12, status: "Pending", date: "2025-07-05", slot: "2.00-3.00" },
        { id: "REQ-027", teamId: "TEAM-014", teamName: "RFID Warehouse Robot", item: "Arduino Uno R3", avail: 30, qty: 4, status: "Fully Issued", date: "2025-06-30", slot: "2.00-3.00" },
        { id: "REQ-028", teamId: "TEAM-014", teamName: "RFID Warehouse Robot", item: "16x2 LCD Display", avail: 30, qty: 6, status: "Rejected", date: "2025-06-27", slot: "2.00-3.00" },
        { id: "REQ-029", teamId: "TEAM-015", teamName: "Waste Management", item: "Soil Moisture Sensor", avail: 30, qty: 5, status: "Pending", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-030", teamId: "TEAM-004", teamName: "Haptic Arm Development", item: "16x2 LCD Display", avail: 30, qty: 2, status: "Pending", date: "2025-07-05", slot: "2.00-3.00" },
        { id: "REQ-031", teamId: "TEAM-016", teamName: "Exoskeleton Suit", item: "Bipolar NEMA 17", avail: 30, qty: 6, status: "Fully Issued", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-032", teamId: "TEAM-016", teamName: "Exoskeleton Suit", item: "Arduino Uno R3", avail: 30, qty: 3, status: "Pending", date: "2025-07-06", slot: "2.00-3.00" },
        { id: "REQ-033", teamId: "TEAM-017", teamName: "Nano Filtration Unit", item: "Soil Moisture Sensor", avail: 30, qty: 8, status: "Fully Issued", date: "2025-07-02", slot: "2.00-3.00" },
        { id: "REQ-034", teamId: "TEAM-017", teamName: "Nano Filtration Unit", item: "DC Motor 12V", avail: 30, qty: 2, status: "Pending", date: "2025-07-06", slot: "2.00-3.00" },
        { id: "REQ-035", teamId: "TEAM-018", teamName: "AI Crop Monitor", item: "Raspberry Pi 4", avail: 30, qty: 3, status: "Fully Issued", date: "2025-07-04", slot: "2.00-3.00" },
        { id: "REQ-036", teamId: "TEAM-018", teamName: "AI Crop Monitor", item: "PIR Motion Sensor", avail: 30, qty: 6, status: "Pending", date: "2025-07-06", slot: "2.00-3.00" },
        { id: "REQ-037", teamId: "TEAM-019", teamName: "Swarm Robotics Lab", item: "Arduino Uno R3", avail: 30, qty: 8, status: "Fully Issued", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-038", teamId: "TEAM-019", teamName: "Swarm Robotics Lab", item: "LiPo Battery 11.1V", avail: 30, qty: 5, status: "Pending", date: "2025-07-06", slot: "2.00-3.00" },
        { id: "REQ-039", teamId: "TEAM-020", teamName: "EV Charging Station", item: "Li-ion Battery 18650", avail: 30, qty: 20, status: "Fully Issued", date: "2025-07-04", slot: "2.00-3.00" },
        { id: "REQ-040", teamId: "TEAM-020", teamName: "EV Charging Station", item: "Variable DC Power Supply", avail: 30, qty: 1, status: "Pending", date: "2025-07-06", slot: "2.00-3.00" },
        { id: "REQ-041", teamId: "TEAM-021", teamName: "Underwater ROV", item: "DC Motor 12V", avail: 30, qty: 4, status: "Fully Issued", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-042", teamId: "TEAM-021", teamName: "Underwater ROV", item: "Raspberry Pi 4", avail: 30, qty: 2, status: "Pending", date: "2025-07-06", slot: "2.00-3.00" }
    ],

    materialReturns: (function () {
        // Helper: offset days from today
        function daysFromToday(n) {
            const d = new Date();
            d.setDate(d.getDate() + n);
            return d.toISOString().slice(0, 10);
        }
        return [
            { id: "RET-001", teamId: "TEAM-001", teamName: "Solar Car Project", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(-4) },
            { id: "RET-002", teamId: "TEAM-003", teamName: "Bio-Sensor Systems", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(-10) },
            { id: "RET-003", teamId: "TEAM-005", teamName: "Smart Irrigation System", item: "Soldering Station", qty: 2, status: "Pending", date: daysFromToday(10) },
            { id: "RET-004", teamId: "TEAM-011", teamName: "Robotics Arm Team", item: "Variable DC Power Supply", qty: 1, status: "Pending", date: daysFromToday(7) },
            { id: "RET-005", teamId: "TEAM-002", teamName: "Drone Flight Tech", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(-3) },
            { id: "RET-006", teamId: "TEAM-013", teamName: "Ocean Cleaner Probe", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(9) },
            { id: "RET-007", teamId: "TEAM-001", teamName: "Solar Car Project", item: "Laser Cutter", qty: 1, status: "Pending", date: daysFromToday(8) },
            { id: "RET-008", teamId: "TEAM-001", teamName: "Solar Car Project", item: "3D Printer", qty: 1, status: "Pending", date: daysFromToday(-7) },
            { id: "RET-009", teamId: "TEAM-002", teamName: "Drone Flight Tech", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(6) },
            { id: "RET-010", teamId: "TEAM-002", teamName: "Drone Flight Tech", item: "Hot Air Rework Station", qty: 1, status: "Pending", date: daysFromToday(-11) },
            { id: "RET-011", teamId: "TEAM-003", teamName: "Bio-Sensor Systems", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(5) },
            { id: "RET-012", teamId: "TEAM-003", teamName: "Bio-Sensor Systems", item: "Variable DC Power Supply", qty: 1, status: "Pending", date: daysFromToday(-2) },
            { id: "RET-013", teamId: "TEAM-004", teamName: "Haptic Arm Development", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(-13) },
            { id: "RET-014", teamId: "TEAM-005", teamName: "Smart Irrigation System", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(-1) },
            { id: "RET-015", teamId: "TEAM-005", teamName: "Smart Irrigation System", item: "3D Printer", qty: 1, status: "Pending", date: daysFromToday(11) },
            { id: "RET-016", teamId: "TEAM-006", teamName: "Eco Waste Sorter", item: "Laser Cutter", qty: 1, status: "Pending", date: daysFromToday(4) },
            { id: "RET-017", teamId: "TEAM-006", teamName: "Eco Waste Sorter", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(-9) },
            { id: "RET-018", teamId: "TEAM-007", teamName: "VTOL UAV Propulsion", item: "CNC Milling Machine", qty: 1, status: "Pending", date: daysFromToday(13) },
            { id: "RET-019", teamId: "TEAM-007", teamName: "VTOL UAV Propulsion", item: "3D Scanner", qty: 1, status: "Pending", date: daysFromToday(-5) },
            { id: "RET-020", teamId: "TEAM-007", teamName: "VTOL UAV Propulsion", item: "Hot Air Rework Station", qty: 1, status: "Pending", date: daysFromToday(-12) },
            { id: "RET-021", teamId: "TEAM-008", teamName: "3D Prosthetic Hand", item: "3D Printer", qty: 1, status: "Pending", date: daysFromToday(5) },
            { id: "RET-022", teamId: "TEAM-008", teamName: "3D Prosthetic Hand", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(-4) },
            { id: "RET-023", teamId: "TEAM-009", teamName: "Autonomous AGV", item: "Laser Cutter", qty: 1, status: "Pending", date: daysFromToday(7) },
            { id: "RET-024", teamId: "TEAM-009", teamName: "Autonomous AGV", item: "Variable DC Power Supply", qty: 1, status: "Pending", date: daysFromToday(-8) },
            { id: "RET-025", teamId: "TEAM-010", teamName: "Water Purifier IoT", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(6) },
            { id: "RET-026", teamId: "TEAM-010", teamName: "Water Purifier IoT", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(-3) },
            { id: "RET-027", teamId: "TEAM-011", teamName: "Robotics Arm Team", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(-6) },
            { id: "RET-028", teamId: "TEAM-012", teamName: "Smart Traffic Guard", item: "3D Printer", qty: 1, status: "Pending", date: daysFromToday(9) },
            { id: "RET-029", teamId: "TEAM-012", teamName: "Smart Traffic Guard", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(-2) },
            { id: "RET-030", teamId: "TEAM-013", teamName: "Ocean Cleaner Probe", item: "Laser Cutter", qty: 1, status: "Pending", date: daysFromToday(-5) },
            { id: "RET-031", teamId: "TEAM-014", teamName: "RFID Warehouse Robot", item: "Variable DC Power Supply", qty: 1, status: "Pending", date: daysFromToday(8) },
            { id: "RET-032", teamId: "TEAM-014", teamName: "RFID Warehouse Robot", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(-1) },
            { id: "RET-033", teamId: "TEAM-015", teamName: "Waste Management", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(10) },
            { id: "RET-034", teamId: "TEAM-015", teamName: "Waste Management", item: "Hot Air Rework Station", qty: 1, status: "Pending", date: daysFromToday(-10) },
            { id: "RET-035", teamId: "TEAM-016", teamName: "Exoskeleton Suit", item: "Variable DC Power Supply", qty: 1, status: "Pending", date: daysFromToday(11) },
            { id: "RET-036", teamId: "TEAM-016", teamName: "Exoskeleton Suit", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(-7) },
            { id: "RET-037", teamId: "TEAM-017", teamName: "Nano Filtration Unit", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(9) },
            { id: "RET-038", teamId: "TEAM-017", teamName: "Nano Filtration Unit", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(-2) },
            { id: "RET-039", teamId: "TEAM-018", teamName: "AI Crop Monitor", item: "3D Printer", qty: 1, status: "Pending", date: daysFromToday(12) },
            { id: "RET-040", teamId: "TEAM-018", teamName: "AI Crop Monitor", item: "Laser Cutter", qty: 1, status: "Pending", date: daysFromToday(-8) },
            { id: "RET-041", teamId: "TEAM-019", teamName: "Swarm Robotics Lab", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(10) },
            { id: "RET-042", teamId: "TEAM-019", teamName: "Swarm Robotics Lab", item: "Hot Air Rework Station", qty: 1, status: "Pending", date: daysFromToday(-9) },
            { id: "RET-043", teamId: "TEAM-020", teamName: "EV Charging Station", item: "Variable DC Power Supply", qty: 1, status: "Pending", date: daysFromToday(8) },
            { id: "RET-044", teamId: "TEAM-020", teamName: "EV Charging Station", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(-1) },
            { id: "RET-045", teamId: "TEAM-021", teamName: "Underwater ROV", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(11) },
            { id: "RET-046", teamId: "TEAM-021", teamName: "Underwater ROV", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(-6) }
        ];
    })(),

    tickets: [
        {
            id: "TKT-001", type: "Procurement", assignedTo: "Administrator", subject: "Low Stock Components", priority: "High", date: "04 Jul 2025", status: "Open", assigneeRole: "System Admin", raisedBy: "Dr. Priya Sharma", time: "10:15 AM", reason: "Multiple inventory components have reached the minimum stock level. Procurement approval is requested to maintain smooth lab operations.", items: [
                { name: "Arduino Uno R3", qty: "05", min: "10" },
                { name: "Soil Moisture Sensor", qty: "02", min: "05" },
                { name: "16x2 LCD Display", qty: "03", min: "05" },
                { name: "DC Motor 12V", qty: "01", min: "03" },
                { name: "Li-ion Battery 18650", qty: "04", min: "10" }
            ], adminResponse: ""
        },

        { id: "TKT-002", type: "Damage", assignedTo: "TEAM-005", subject: "Arduino Uno R3 Damaged", priority: "Medium", date: "03 Jul 2025", status: "Pending", teamName: "Smart Irrigation System", equipmentName: "Arduino Uno R3", raisedBy: "Lab Incharge", time: "02:15 PM", damageDescription: "USB port is physically damaged during project testing.", fineAmount: "500", dueDate: "10 Jul 2025", remarks: "Fine to be paid by the team before next material issue.", teamResponse: "", lastUpdated: "03 Jul 2025, 02:15 PM" },

        { id: "TKT-003", type: "Damage", assignedTo: "TEAM-011", subject: "DC Motor 12V Broken", priority: "High", date: "02 Jul 2025", status: "In Progress", teamName: "Robotics Arm", equipmentName: "DC Motor 12V", raisedBy: "Lab Incharge", time: "11:30 AM", damageDescription: "Motor coil burned out due to overloading.", fineAmount: "300", dueDate: "09 Jul 2025", remarks: "Replacement motor cost.", teamResponse: "We have received the notice. Discussing with team leader.", lastUpdated: "02 Jul 2025, 03:00 PM" },

        {
            id: "TKT-004", type: "Procurement", assignedTo: "Administrator", subject: "Request for Additional Sensors", priority: "Medium", date: "01 Jul 2025", status: "In Progress", assigneeRole: "System Admin", raisedBy: "Dr. Priya Sharma", time: "09:45 AM", reason: "Additional sensors needed for upcoming workshop.", items: [
                { name: "Ultrasonic Sensor", qty: "15", min: "05" },
                { name: "PIR Motion Sensor", qty: "20", min: "05" }
            ], adminResponse: "Quotation requested from vendor."
        },

        { id: "TKT-005", type: "Damage", assignedTo: "TEAM-008", subject: "16x2 LCD Display Cracked", priority: "Low", date: "30 Jun 2025", status: "Resolved", teamName: "3D Prosthetic Hand", equipmentName: "16x2 LCD Display", raisedBy: "Lab Incharge", time: "04:00 PM", damageDescription: "Screen cracked during mechanical assembly mounting.", fineAmount: "150", dueDate: "07 Jul 2025", remarks: "Standard replacement fine.", teamResponse: "Fine paid. Receipt number #88271.", lastUpdated: "01 Jul 2025, 10:20 AM" },

        {
            id: "TKT-006", type: "Procurement", assignedTo: "Administrator", subject: "Low Stock - Batteries", priority: "High", date: "29 Jun 2025", status: "Resolved", assigneeRole: "System Admin", raisedBy: "Dr. Priya Sharma", time: "11:20 AM", reason: "Li-ion Battery stock critically low.", items: [
                { name: "Li-ion Battery 18650", qty: "02", min: "10" }
            ], adminResponse: "PO Issued. Delivery expected by next week."
        },

        { id: "TKT-007", type: "Damage", assignedTo: "TEAM-015", subject: "Soil Moisture Sensor Damaged", priority: "Medium", date: "28 Jun 2025", status: "Open", teamName: "Waste Management", equipmentName: "Soil Moisture Sensor", raisedBy: "Lab Incharge", time: "10:00 AM", damageDescription: "Corrosion due to extended water immersion test without waterproofing cover.", fineAmount: "200", dueDate: "05 Jul 2025", remarks: "Cost of sensor replacement.", teamResponse: "", lastUpdated: "28 Jun 2025, 10:00 AM" }
    ],
    bookedEquipment: [],
    equipmentRequests: [
        {
            teamId: "TEAM-001",
            teamName: "Solar Car Project",
            requests: [
                { id: "ER-101", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "10:00 AM - 12:00 PM", status: "Rejected", rejectionReason: "Sent for Repair" },
                { id: "ER-102", equipmentType: "Manufacturing", equipmentId: "EQ-005", equipmentName: "CNC Milling Machine", timeSlot: "02:00 PM - 04:00 PM", status: "Approved", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-002",
            teamName: "Drone Flight Tech",
            requests: [
                { id: "ER-201", equipmentType: "Manufacturing", equipmentId: "EQ-010", equipmentName: "Laser Cutter", timeSlot: "11:00 AM - 01:00 PM", status: "Rejected", rejectionReason: "It is damaged and it will available from tomorrow" }
            ]
        },
        {
            teamId: "TEAM-003",
            teamName: "Bio-Sensor Systems",
            requests: [
                { id: "ER-301", equipmentType: "Electronics", equipmentId: "EQ-006", equipmentName: "Digital Oscilloscope", timeSlot: "09:00 AM - 11:00 AM", status: "Approved", rejectionReason: "" },
                { id: "ER-302", equipmentType: "Electronics", equipmentId: "EQ-018", equipmentName: "Variable DC Power Supply", timeSlot: "01:00 PM - 03:00 PM", status: "Approved", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-005",
            teamName: "Smart Irrigation System",
            requests: [
                { id: "ER-501", equipmentType: "Electronics", equipmentId: "EQ-012", equipmentName: "Soldering Station", timeSlot: "02:00 PM - 04:00 PM", status: "Rejected", rejectionReason: "Sent for Repair" }
            ]
        },
        {
            teamId: "TEAM-004",
            teamName: "Haptic Arm Development",
            requests: [
                { id: "ER-401", equipmentType: "Electronics", equipmentId: "EQ-013", equipmentName: "Bench Multimeter", timeSlot: "03:00 PM - 05:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-402", equipmentType: "Manufacturing", equipmentId: "EQ-016", equipmentName: "Hot Air Rework Station", timeSlot: "10:00 AM - 12:00 PM", status: "Pending", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-006",
            teamName: "Eco Waste Sorter",
            requests: [
                { id: "ER-601", equipmentType: "Manufacturing", equipmentId: "EQ-010", equipmentName: "Laser Cutter", timeSlot: "02:00 PM - 04:00 PM", status: "Rejected", rejectionReason: "Slot not available, try next week" },
                { id: "ER-602", equipmentType: "Electronics", equipmentId: "EQ-011", equipmentName: "Raspberry Pi 4", timeSlot: "11:00 AM - 01:00 PM", status: "Approved", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-007",
            teamName: "VTOL UAV Propulsion",
            requests: [
                { id: "ER-701", equipmentType: "Manufacturing", equipmentId: "EQ-005", equipmentName: "CNC Milling Machine", timeSlot: "09:00 AM - 12:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-702", equipmentType: "Manufacturing", equipmentId: "EQ-019", equipmentName: "3D Scanner", timeSlot: "01:00 PM - 02:00 PM", status: "Pending", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-008",
            teamName: "3D Prosthetic Hand",
            requests: [
                { id: "ER-801", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "01:00 PM - 03:00 PM", status: "Rejected", rejectionReason: "Maintenance scheduled on this date" }
            ]
        },
        {
            teamId: "TEAM-009",
            teamName: "Autonomous AGV",
            requests: [
                { id: "ER-901", equipmentType: "Manufacturing", equipmentId: "EQ-010", equipmentName: "Laser Cutter", timeSlot: "10:00 AM - 12:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-902", equipmentType: "Electronics", equipmentId: "EQ-006", equipmentName: "Digital Oscilloscope", timeSlot: "02:00 PM - 04:00 PM", status: "Pending", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-010",
            teamName: "Water Purifier IoT",
            requests: [
                { id: "ER-1001", equipmentType: "Electronics", equipmentId: "EQ-012", equipmentName: "Soldering Station", timeSlot: "09:00 AM - 11:00 AM", status: "Approved", rejectionReason: "" },
                { id: "ER-1002", equipmentType: "Electronics", equipmentId: "EQ-013", equipmentName: "Bench Multimeter", timeSlot: "11:00 AM - 12:00 PM", status: "Rejected", rejectionReason: "Currently in use by another team" }
            ]
        },
        {
            teamId: "TEAM-011",
            teamName: "Robotics Arm Team",
            requests: [
                { id: "ER-1101", equipmentType: "Electronics", equipmentId: "EQ-018", equipmentName: "Variable DC Power Supply", timeSlot: "02:00 PM - 04:00 PM", status: "Pending", rejectionReason: "" },
                { id: "ER-1102", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "03:00 PM - 05:00 PM", status: "Approved", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-012",
            teamName: "Smart Traffic Guard",
            requests: [
                { id: "ER-1201", equipmentType: "Electronics", equipmentId: "EQ-011", equipmentName: "Raspberry Pi 4", timeSlot: "10:00 AM - 12:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-1202", equipmentType: "Electronics", equipmentId: "EQ-017", equipmentName: "PIR Motion Sensor", timeSlot: "01:00 PM - 03:00 PM", status: "Rejected", rejectionReason: "Out of stock" }
            ]
        },
        {
            teamId: "TEAM-013",
            teamName: "Ocean Cleaner Probe",
            requests: [
                { id: "ER-1301", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "09:00 AM - 11:00 AM", status: "Approved", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-014",
            teamName: "RFID Warehouse Robot",
            requests: [
                { id: "ER-1401", equipmentType: "Electronics", equipmentId: "EQ-013", equipmentName: "Bench Multimeter", timeSlot: "11:00 AM - 12:00 PM", status: "Rejected", rejectionReason: "Sent for calibration" },
                { id: "ER-1402", equipmentType: "Electronics", equipmentId: "EQ-006", equipmentName: "Digital Oscilloscope", timeSlot: "02:00 PM - 04:00 PM", status: "Pending", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-015",
            teamName: "Waste Management",
            requests: [
                { id: "ER-1501", equipmentType: "Electronics", equipmentId: "EQ-012", equipmentName: "Soldering Station", timeSlot: "01:00 PM - 03:00 PM", status: "Approved", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-016",
            teamName: "Exoskeleton Suit",
            requests: [
                { id: "ER-1601", equipmentType: "Electronics", equipmentId: "EQ-018", equipmentName: "Variable DC Power Supply", timeSlot: "09:00 AM - 11:00 AM", status: "Approved", rejectionReason: "" },
                { id: "ER-1602", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "01:00 PM - 03:00 PM", status: "Rejected", rejectionReason: "Nozzle replacement in progress" }
            ]
        },
        {
            teamId: "TEAM-017",
            teamName: "Nano Filtration Unit",
            requests: [
                { id: "ER-1701", equipmentType: "Electronics", equipmentId: "EQ-013", equipmentName: "Bench Multimeter", timeSlot: "10:00 AM - 12:00 PM", status: "Pending", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-018",
            teamName: "AI Crop Monitor",
            requests: [
                { id: "ER-1801", equipmentType: "Electronics", equipmentId: "EQ-011", equipmentName: "Raspberry Pi 4", timeSlot: "02:00 PM - 04:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-1802", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "09:00 AM - 11:00 AM", status: "Rejected", rejectionReason: "Filament depleted" }
            ]
        },
        {
            teamId: "TEAM-019",
            teamName: "Swarm Robotics Lab",
            requests: [
                { id: "ER-1901", equipmentType: "Electronics", equipmentId: "EQ-012", equipmentName: "Soldering Station", timeSlot: "10:00 AM - 12:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-1902", equipmentType: "Manufacturing", equipmentId: "EQ-010", equipmentName: "Laser Cutter", timeSlot: "02:00 PM - 04:00 PM", status: "Pending", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-020",
            teamName: "EV Charging Station",
            requests: [
                { id: "ER-2001", equipmentType: "Electronics", equipmentId: "EQ-018", equipmentName: "Variable DC Power Supply", timeSlot: "09:00 AM - 11:00 AM", status: "Rejected", rejectionReason: "Overbooked for this time slot" }
            ]
        },
        {
            teamId: "TEAM-021",
            teamName: "Underwater ROV",
            requests: [
                { id: "ER-2101", equipmentType: "Electronics", equipmentId: "EQ-006", equipmentName: "Digital Oscilloscope", timeSlot: "01:00 PM - 03:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-2102", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "10:00 AM - 12:00 PM", status: "Pending", rejectionReason: "" }
            ]
        }
    ]
};

// Generate dummy data up to 32 items for tickets
function fillRemainingTickets() {
    const types = ["Procurement", "Damage"];
    const priorities = ["High", "Medium", "Low"];
    const statuses = ["Open", "Pending", "In Progress", "Resolved"];
    const asignees = [
        { name: "TEAM-006", desc: "Eco Waste sorter" },
        { name: "TEAM-001", desc: "Solar Car Project" },
        { name: "Administrator", desc: "System Admin" },
        { name: "TEAM-002", desc: "Drone Flight Tech" },
        { name: "TEAM-003", desc: "Bio-Sensor Systems" }
    ];
    const equipment = ["Arduino Uno R3", "3D Printer", "CNC Milling Machine", "Digital Oscilloscope", "Raspberry Pi 4"];
    const dates = ["27 Jun 2025", "26 Jun 2025", "25 Jun 2025", "24 Jun 2025", "23 Jun 2025", "22 Jun 2025", "21 Jun 2025", "20 Jun 2025"];

    let baseId = 8;
    while (DEFAULT_DATABASE.tickets.length < 32) {
        const type = types[Math.floor(Math.random() * types.length)];
        const priority = priorities[Math.floor(Math.random() * priorities.length)];
        const status = statuses[Math.floor(Math.random() * statuses.length)];
        const date = dates[Math.floor(Math.random() * dates.length)];
        const id = `TKT-${String(baseId).padStart(3, '0')}`;
        baseId++;

        if (type === "Procurement") {
            DEFAULT_DATABASE.tickets.push({
                id,
                type,
                assignedTo: "Administrator",
                subject: `Refocking ${equipment[Math.floor(Math.random() * equipment.length)]}s`,
                priority,
                date,
                status,
                assigneeRole: "System Admin",
                raisedBy: "Dr. Priya Sharma",
                time: "02:00 PM",
                reason: "Stock replenishment request.",
                items: [
                    { name: "Item Replacements", qty: "02", min: "05" }
                ],
                adminResponse: status === "Resolved" ? "Request processed." : ""
            });
        } else {
            const teamIdx = Math.floor(Math.random() * asignees.length);
            DEFAULT_DATABASE.tickets.push({
                id,
                type,
                assignedTo: asignees[teamIdx].name,
                subject: `${equipment[Math.floor(Math.random() * equipment.length)]} Damaged`,
                priority,
                date,
                status,
                teamName: asignees[teamIdx].desc,
                equipmentName: equipment[Math.floor(Math.random() * equipment.length)],
                raisedBy: "Lab Incharge",
                time: "11:00 AM",
                damageDescription: "Physical structural damage observed post usage.",
                fineAmount: "450",
                dueDate: "12 Jul 2025",
                remarks: "Please deposit the replacement fine.",
                teamResponse: status === "Resolved" ? "Fine cleared." : "",
                lastUpdated: `${date}, 11:30 AM`
            });
        }
    }
}
fillRemainingTickets();


// Initialize LocalStorage database
const DB_VERSION = 12;
let MEMORY_DB = null;

function initLocalStorageDB() {
    try {
        const storedVersion = parseInt(localStorage.getItem("rplms_db_version") || "0");
        if (storedVersion < DB_VERSION) {
            localStorage.setItem("rplms_db", JSON.stringify(DEFAULT_DATABASE));
            localStorage.setItem("rplms_db_version", String(DB_VERSION));
        }
    } catch (e) {
        console.warn("LocalStorage access blocked. Falling back to in-memory database.", e);
        MEMORY_DB = DEFAULT_DATABASE;
    }
}
initLocalStorageDB();

// Read DB helper
function getDB() {
    try {
        return JSON.parse(localStorage.getItem("rplms_db")) || DEFAULT_DATABASE;
    } catch (e) {
        if (!MEMORY_DB) MEMORY_DB = DEFAULT_DATABASE;
        return MEMORY_DB;
    }
}

// Write DB helper
function setDB(db) {
    try {
        localStorage.setItem("rplms_db", JSON.stringify(db));
    } catch (e) {
        MEMORY_DB = db;
    }
}

// // Check logged in state (Bypassed to keep user auto-logged in)
// function checkAuth() {
//     const isLoggedIn = localStorage.getItem("rplms_logged_in");
//     const currentPage = window.location.pathname.split("/").pop();
//     if (!isLoggedIn && currentPage !== "login.html" && currentPage !== "") {
//         window.location.href = "login.html";
//     } else if (isLoggedIn && currentPage === "login.html") {
//         window.location.href = "index.html";
//     }
// }
// checkAuth();

// --- Sidebar & Layout Builder ---

function renderBaseLayout(activeMenu) {
    const db = getDB();
    const user = db.currentUser;

    // Calculate user initials dynamically
    const nameWithoutTitle = user.name.replace(/^(Dr\.|Mr\.|Ms\.|Mrs\.)\s+/i, '');
    const nameParts = nameWithoutTitle.split(/\s+/).filter(Boolean);
    let userInitials = 'F';
    if (nameParts.length > 0) {
        userInitials = nameParts.map(p => p[0]).join('').substring(0, 2).toUpperCase();
    }

    // Update avatar and username if elements exist
    const avatarEl = document.querySelector(".header-avatar");
    if (avatarEl) avatarEl.textContent = userInitials;

    const nameEl = document.querySelector(".header-user-name");
    if (nameEl) nameEl.textContent = user.name;

    // Set active class on sidebar items
    const navItems = document.querySelectorAll(".nav-links .nav-item");
    navItems.forEach(item => {
        item.classList.remove("active");
    });
    
    // Find the item corresponding to activeMenu
    const activeItem = document.querySelector(`.nav-links a[href*="/${activeMenu}/"], .nav-links a[href="${activeMenu}.html"], .nav-links a[href*="${activeMenu}"]`);
    if (activeItem) {
        const parentLi = activeItem.closest(".nav-item");
        if (parentLi) parentLi.classList.add("active");
    }

    // Attach logout click listener
    const logoutBtn = document.querySelector("#logoutBtn");
    if (logoutBtn) {
        logoutBtn.addEventListener("click", () => {
            localStorage.removeItem("rplms_logged_in");
        });
    }

    // Notifications Dropdown dynamic build
    function buildNotificationsDropdown() {
        const dbNow = getDB();
        const notifs = dbNow.notifications || [];
        const unreadCount = notifs.filter(n => n.unread).length;

        // Update the bell badge
        const badge = document.querySelector(".notif-wrapper .icon-badge");
        if (badge) {
            badge.textContent = unreadCount;
            badge.style.display = unreadCount > 0 ? "" : "none";
        }

        const dropdown = document.querySelector(".notifications-dropdown");
        if (!dropdown) return;

        const listHtml = notifs.length === 0
            ? `<div class="notif-empty"><span class="notif-empty-icon">🔔</span>No notifications yet</div>`
            : notifs.map(n => `
                <div class="notif-item ${n.unread ? 'unread' : ''}" data-notif-id="${n.id}">
                    <div class="notif-icon-wrapper ${n.iconClass}">${n.icon}</div>
                    <div class="notif-content">
                        <div class="notif-body">${n.body}</div>
                        <div class="notif-time">${n.time}</div>
                    </div>
                </div>`).join("");

        dropdown.innerHTML = `
            <div class="notif-header">
                <div class="notif-header-title">
                    Notifications
                    ${unreadCount > 0 ? `<span class="notif-count-badge">${unreadCount}</span>` : ''}
                </div>
                ${unreadCount > 0 ? '<button class="notif-header-action" id="markAllReadBtn">Mark all read</button>' : ''}
            </div>
            <div class="notif-list">${listHtml}</div>
        `;

        // Mark all read
        const markAllBtn = dropdown.querySelector("#markAllReadBtn");
        if (markAllBtn) {
            markAllBtn.addEventListener("click", (e) => {
                e.stopPropagation();
                const db2 = getDB();
                db2.notifications.forEach(n => n.unread = false);
                setDB(db2);
                buildNotificationsDropdown();
            });
        }

        // Mark individual as read on click
        dropdown.querySelectorAll(".notif-item").forEach(el => {
            el.addEventListener("click", () => {
                const id = el.dataset.notifId;
                const db2 = getDB();
                const notif = db2.notifications.find(n => n.id === id);
                if (notif) { notif.unread = false; setDB(db2); }
                buildNotificationsDropdown();
            });
        });
    }

    // Toggle dropdown open/close
    const bellBtn = document.querySelector(".notif-wrapper .header-icon-btn");
    const notifDropdown = document.querySelector(".notifications-dropdown");
    if (bellBtn && notifDropdown) {
        // Remove old listeners to avoid stacking
        const newBellBtn = bellBtn.cloneNode(true);
        bellBtn.parentNode.replaceChild(newBellBtn, bellBtn);

        newBellBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            const isOpen = notifDropdown.classList.toggle("open");
            if (isOpen) buildNotificationsDropdown();
        });

        // Close on outside click
        document.addEventListener("click", (e) => {
            if (!e.target.closest(".notif-wrapper")) {
                notifDropdown.classList.remove("open");
            }
        });

        // Initialize badge on page load
        buildNotificationsDropdown();
    }
}

// Custom Toast notification loader
function showToast(message, type = "success") {
    let container = document.querySelector(".toast-container");
    if (!container) {
        container = document.createElement("div");
        container.className = "toast-container";
        document.body.appendChild(container);
    }

    const toast = document.createElement("div");
    toast.className = `toast ${type}`;

    let icon = "&#10003;";
    if (type === "error") icon = "&#9888;";
    if (type === "warn") icon = "&#9757;";
    if (type === "info") icon = "&#8505;";

    toast.innerHTML = `
    <div class="toast-content">
      <span class="toast-icon">${icon}</span>
      <span class="toast-message">${message}</span>
    </div>
    <button class="toast-close">&times;</button>
  `;

    container.appendChild(toast);

    // Trigger show layout
    setTimeout(() => toast.classList.add("show"), 10);

    // Auto remove after 4 seconds
    const autoClose = setTimeout(() => {
        toast.classList.remove("show");
        setTimeout(() => toast.remove(), 300);
    }, 4000);

    // Close button trigger
    toast.querySelector(".toast-close").addEventListener("click", () => {
        clearTimeout(autoClose);
        toast.classList.remove("show");
        setTimeout(() => toast.remove(), 300);
    });
}

// Confirmation Popups Setup
function createConfirmationModal(title, bodyText, confirmCallback, confirmText = "Confirm", isDanger = false) {
    // Check if confirmation modal backdrop already exists
    let backdrop = document.getElementById("confirmModalBackdrop");
    if (!backdrop) {
        backdrop = document.createElement("div");
        backdrop.id = "confirmModalBackdrop";
        backdrop.className = "modal-backdrop";
        document.body.appendChild(backdrop);
    }

    backdrop.innerHTML = `
    <div class="modal-container" style="max-width: 420px;">
      <div class="modal-header" style="padding: 20px 24px;">
        <div class="modal-header-left">
          <div class="circle-icon-wrapper ${isDanger ? 'red-alert' : 'blue-info'}" style="width: 40px; height: 40px; font-size: 16px;">
            ${isDanger ? '&#9888;' : '&#8505;'}
          </div>
          <div class="card-header-text">
            <span class="card-title">${title}</span>
          </div>
        </div>
        <button class="modal-close-btn" id="confirmModalClose">&times;</button>
      </div>
      <div class="modal-body" style="padding: 20px 24px; font-size: 13px; color: var(--text-secondary); line-height: 1.5;">
        ${bodyText}
      </div>
      <div class="modal-footer" style="padding: 12px 24px;">
        <button class="btn btn-secondary" id="confirmCancelBtn" style="padding: 8px 16px; font-size: 12px;">Cancel</button>
        <button class="btn ${isDanger ? 'btn-danger' : 'btn-primary'}" id="confirmConfirmBtn" style="padding: 8px 16px; font-size: 12px;">${confirmText}</button>
      </div>
    </div>
  `;

    // Escape key handler
    const escapeHandler = function (e) {
        if (e.key === "Escape") {
            closeConfirm();
        }
    };

    function openConfirm() {
        backdrop.classList.add("show");
        document.addEventListener("keydown", escapeHandler);
    }

    function closeConfirm() {
        backdrop.classList.remove("show");
        document.removeEventListener("keydown", escapeHandler);
        setTimeout(() => backdrop.remove(), 300);
    }

    // Bind cancel actions
    backdrop.querySelector("#confirmModalClose").addEventListener("click", closeConfirm);
    backdrop.querySelector("#confirmCancelBtn").addEventListener("click", closeConfirm);
    backdrop.addEventListener("click", (e) => {
        if (e.target === backdrop) closeConfirm();
    });

    // Bind confirm action
    backdrop.querySelector("#confirmConfirmBtn").addEventListener("click", () => {
        confirmCallback();
        closeConfirm();
    });

    openConfirm();
}



// Debounce search inputs helper
function debounce(func, delay = 300) {
    let timer;
    return function (...args) {
        clearTimeout(timer);
        timer = setTimeout(() => {
            func.apply(this, args);
        }, delay);
    };
}

// Escape inputs to prevent XSS
function escapeHtml(str) {
    if (typeof str !== 'string') return str;
    return str.replace(/[&<>"']/g, function (match) {
        switch (match) {
            case '&': return '&amp;';
            case '<': return '&lt;';
            case '>': return '&gt;';
            case '"': return '&quot;';
            case "'": return '&#39;';
        }
    });
}

// Basic SQL injection keyword check
function hasSqlInfectionRisk(str) {
    if (typeof str !== 'string') return false;
    const sqlRegex = /\b(select|insert|update|delete|drop|alter|union|where|exec|truncate)\b/gi;
    return sqlRegex.test(str);
}
//common.js

/* === js/material-return.js === */
// Material Return Page Logic — Components & Tools Returns (shared drawer pattern)

document.addEventListener("DOMContentLoaded", () => {
    let db = getDB();

    // ── Seed toolReturns if not present ──────────────────────────────────────
    if (!db.toolReturns || db.toolReturns.length === 0) {
        function daysOffset(n) {
            const d = new Date();
            d.setDate(d.getDate() + n);
            return d.toISOString().slice(0, 10);
        }
        const statuses  = ["Pending","Pending","Pending","Pending","Pending","Pending","Pending","Pending","Pending","Pending","Pending","Pending"];
        const teamIds   = ["TEAM-001","TEAM-002","TEAM-003","TEAM-004","TEAM-005","TEAM-006","TEAM-007","TEAM-008","TEAM-009","TEAM-010","TEAM-011","TEAM-012"];
        const teamNames = ["Solar Car Project","Drone Flight Tech","Bio-Sensor Systems","Haptic Arm Development","Smart Irrigation System","Eco Waste Sorter","VTOL UAV Propulsion","3D Prosthetic Hand","Autonomous AGV","Water Purifier IoT","Robotics Arm Team","Smart Traffic Guard"];
        const toolItems = ["Screw Driver Set","Soldering Iron","Digital Multimeter","Wire Stripper","Hot Air Gun","Crimping Tool","Oscilloscope Probe","Allen Key Set","Plier Set","Torque Wrench"];
        db.toolReturns = teamIds.map((tid, i) => ({
            id: `TRET-${String(i + 1).padStart(3, "0")}`,
            teamId: tid,
            teamName: teamNames[i],
            item: toolItems[i % toolItems.length],
            qty: (i % 3) + 1,
            status: statuses[i],
            date: daysOffset(statuses[i] === "Overdue" ? -(i + 3) : statuses[i] === "Returned" ? -(i + 1) : (i + 4))
        }));
        setDB(db);
    }

    // ── State ─────────────────────────────────────────────────────────────────
    let currentView = "components"; // "components" | "tools"
    let currentFilters = { status: "All", search: "" };
    let currentPage = 1;
    const itemsPerPage = 20;

    // Active drawer state
    let activeTeamId = null;
    let activeTeamItems = [];

    // ── DOM refs ──────────────────────────────────────────────────────────────
    const searchInput       = document.getElementById("searchReturnsInput");
    const filterTabs        = document.querySelectorAll(".filter-tab");
    const kpiTotal          = document.getElementById("kpiTotalReturns");
    const kpiOverdue        = document.getElementById("kpiOverdueReturns");
    const kpiReturned       = document.getElementById("kpiReturnedCount");
    const tabComponents     = document.getElementById("tabComponents");
    const tabTools          = document.getElementById("tabTools");

    // ── View tab switching ────────────────────────────────────────────────────
    tabComponents.addEventListener("click", () => switchView("components"));
    tabTools.addEventListener("click",      () => switchView("tools"));

    function switchView(view) {
        currentView = view;
        currentPage = 1;
        currentFilters.status = "All";
        currentFilters.search = "";
        if (searchInput) searchInput.value = "";
        filterTabs.forEach(t => t.classList.toggle("active", t.dataset.status === "All"));

        tabComponents.classList.toggle("active", view === "components");
        tabTools.classList.toggle("active",      view === "tools");

        updateKPIs();
        renderCards();
    }

    // ── KPIs ──────────────────────────────────────────────────────────────────
    function updateKPIs() {
        const list = activeList();
        const activeReturns = list.filter(r => r.status !== "Returned" && r.status !== "Damaged").length;
        const overdueReturns = list.filter(r => r.status === "Overdue").length;
        const returnedReturns = list.filter(r => r.status === "Returned").length;
        const damagedReturns = list.filter(r => r.status === "Damaged").length;

        kpiTotal.textContent   = String(activeReturns).padStart(2, "0");
        kpiOverdue.textContent = String(overdueReturns).padStart(2, "0");
        kpiReturned.textContent = String(returnedReturns).padStart(2, "0");
        
        const kpiDamaged = document.getElementById("kpiDamagedReturns");
        if (kpiDamaged) {
            kpiDamaged.textContent = String(damagedReturns).padStart(2, "0");
        }
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    function activeList() {
        return currentView === "components" ? db.materialReturns : db.toolReturns;
    }

    function getGrouped(list) {
        const grouped = {};
        list.forEach(r => {
            if (!grouped[r.teamId]) grouped[r.teamId] = { teamId: r.teamId, teamName: r.teamName, items: [] };
            grouped[r.teamId].items.push(r);
        });
        return Object.values(grouped);
    }

    function resolveItemId(itemName) {
        if (currentView === "components") {
            const found = db.inventory.find(i => i.name === itemName);
            return found ? found.id : "EQ-???";
        } else {
            const found = db.tools.find(t => t.componentName === itemName);
            return found ? found.toolid : "T-???";
        }
    }

    // ── Render cards grid ─────────────────────────────────────────────────────
    function renderCards() {
        const container = document.getElementById("returnsGridContainer");
        if (!container) return;

        let grouped = getGrouped(activeList());

        // Filter by status
        grouped = grouped.filter(team => {
            const statuses = team.items.map(i => i.status);

            const isReturnedFilter = (s) =>
                s === "Returned" || s === "Damaged";

            const isAllReturned = statuses.every(s => isReturnedFilter(s));
            const hasPending = statuses.some(s => !isReturnedFilter(s));


            let statusMatch = true;
            if (currentFilters.status === "Pending") {
                statusMatch = statuses.some(s => s === "Pending" || s === "Partial Returned" || s === "Partial Damaged");
            } else if (currentFilters.status === "Returned") {
                statusMatch = statuses.every(s => s === "Returned" || s === "Damaged");
            } else {
                statusMatch = true;
            }




            // Filter by search
            const s = currentFilters.search.toLowerCase();
            const searchMatch = !s ||
                team.teamName.toLowerCase().includes(s) ||
                team.teamId.toLowerCase().includes(s) ||
                team.items.some(i => i.item.toLowerCase().includes(s));

            return statusMatch && searchMatch;
        });

        // Sort by teamId
        grouped.sort((a, b) => a.teamId < b.teamId ? -1 : a.teamId > b.teamId ? 1 : 0);

        // Paginate
        const total = grouped.length;
        const totalPages = Math.ceil(total / itemsPerPage) || 1;
        if (currentPage > totalPages) currentPage = totalPages;
        const start = (currentPage - 1) * itemsPerPage;
        const page  = grouped.slice(start, start + itemsPerPage);

        if (page.length === 0) {
            container.innerHTML = `
                <div style="grid-column:1/-1;padding:48px 16px;text-align:center;">
                    <div class="empty-state">
                        <span class="empty-state-icon">&#8617;</span>
                        <span class="empty-state-title">No Return Items Found</span>
                        <p class="empty-state-desc">No active team returns match your current filter.</p>
                    </div>
                </div>`;
            return;
        }

        container.innerHTML = page.map(team => {
            const statuses    = team.items.map(i => i.status);
            const allReturned = statuses.every(s => s === "Returned" || s === "Damaged");
            const hasDamaged  = statuses.includes("Damaged");
            
            let badgeClass  = "status-pending";
            let cardStatus  = "Pending";

            if (allReturned) {
                // After submission (checkbox selection), overall must be resolved.
                // Show only:
                // - "Returned" for any Returned / Partial Returned mix
                // - "Returned (Damaged)" if any Damaged/Partial Damaged and no Partial/Returned-good items
                const hasGood = statuses.includes("Returned") || statuses.includes("Partial Returned");
                const hasBad  = statuses.includes("Damaged") || statuses.includes("Partial Damaged");

                badgeClass = "status-resolved";

                if (hasBad && !hasGood) {
                    cardStatus = "Returned (Damaged)";
                } else {
                    cardStatus = "Returned";
                }
            }



            
            const ids         = team.items[0].id;
            // If every item is resolved (Returned/Damaged/Partial...), allow viewing details
            const btnLabel    = allReturned ? "View Return Details" : "Process Return";


            const itemsListHtml = team.items.map(i => {
                let statusLabel = "";
                let colorClass = "";
                
                if (i.status === "Returned") {
                    statusLabel = "Returned (Good)";
                    colorClass = "color: #16A34A; font-weight: 600;";
                } else if (i.status === "Damaged") {
                    statusLabel = "Damaged";
                    colorClass = "color: #EF4444; font-weight: 600;";
                } else if (i.status === "Partial Returned") {
                    statusLabel = "Partial Return (Good)";
                    colorClass = "color: #16A34A; font-weight: 600;";
                } else if (i.status === "Partial Damaged") {
                    statusLabel = "Partial Return (Damaged)";
                    colorClass = "color: #EF4444; font-weight: 600;";
                } else {
                    statusLabel = "Pending";
                    colorClass = "color: #D97706; font-weight: 600;";
                }

                
                return `<div style="display: flex; justify-content: space-between; font-size: 12px; margin-top: 6px; padding: 4px 0; border-bottom: 1px dashed var(--border-color);">
                    <span style="color: var(--text-primary); font-weight: 500;">${i.item} (x${i.qty})</span>
                    <span style="${colorClass}">${statusLabel}</span>
                </div>`;
            }).join("");

            return `
                <div class="req-card" onclick="openReturnDrawer('${team.teamId}')"
                     style="cursor:pointer;display:flex;flex-direction:column;justify-content:space-between;min-height:220px;">
                    <div>
                        <div class="card-header">
                            <span class="badge ${badgeClass}">${cardStatus}</span>
                        </div>
                        <div class="card-body" style="margin-bottom:0;">
                            <div><strong>Team ID</strong>${team.teamId}</div>
                            <div><strong>Return ID</strong>${ids}</div>
                            <div style="margin-top:12px; border-top:1.5px solid var(--border-color); padding-top:8px;">
                                <div style="font-size:11px; font-weight:700; text-transform:uppercase; color:var(--text-secondary); margin-bottom:4px;">Items List</div>
                                ${itemsListHtml}
                            </div>
                        </div>
                    </div>
                    <div style="display:flex;justify-content:flex-end;margin-top:16px;">
                        <button class="btn ${allReturned ? 'btn-secondary' : 'btn-primary'}"
                                style="width:auto;min-width:150px;font-size:12.5px;padding:8px 16px;"
                                onclick="event.stopPropagation();openReturnDrawer('${team.teamId}')">
                            ${btnLabel}
                        </button>
                    </div>
                </div>`;
        }).join("");
    }

    // ── Shared drawer open ────────────────────────────────────────────────────
    window.openReturnDrawer = function (teamId) {
        db = getDB();
        const team = getGrouped(activeList()).find(t => t.teamId === teamId);
        if (!team) return;

        activeTeamId    = teamId;
        activeTeamItems = team.items;

        // Header
        document.getElementById("drawerTeamName").textContent = team.teamName;
        document.getElementById("drawerTeamId").textContent   = team.teamId;
        document.getElementById("metaActiveReturns").textContent =
            team.items.filter(i => i.status !== "Returned").length;
        document.getElementById("metaOverdueCount").textContent =
            team.items.filter(i => i.status === "Overdue").length;

        // Adapt column labels and section title to current view
        const isTools = currentView === "tools";
        document.getElementById("drawerTableTitle").textContent =
            isTools ? "Issued Tools for Return" : "Issued Items for Return";
        document.getElementById("drawerColId").textContent   = isTools ? "Tool ID"   : "Item ID";
        document.getElementById("drawerColName").textContent = isTools ? "Tool Name" : "Item Name";
        document.getElementById("labelIssued").textContent   = isTools ? "Total Tools Issued"    : "Total Items Issued";
        document.getElementById("labelReturned").textContent = isTools ? "Total Tools Returned"  : "Total Items Returned";

        // Render rows
        const tbody = document.getElementById("bodyReturns");
        tbody.innerHTML = "";
        team.items.forEach(item => {
            const itemId = resolveItemId(item.item);
            // Always render all items as interactive — no static Good/Damaged text
            const retQty = item.returnedQty !== undefined ? item.returnedQty : item.qty;
            // Always start as Pending in the drawer UI.
            // Lab Incharge must explicitly check returned-in-good before submission.
            const isGood = "";


            const qtyHtml = `
                <input type="number" class="qty-input"
                       id="qty-return-${item.id}"
                       min="0" max="${item.qty}" value="${retQty}"
                       oninput="validateAndRecalculate('${item.id}',${item.qty})">`;

            const conditionHtml = `
                <input type="checkbox"
                       style="width:16px;height:16px;transform:scale(1.1);accent-color:var(--primary-color);cursor:pointer;"
                       id="chk-return-${item.id}" ${isGood}
                       onchange="recalculateReturnSummary()">`;


            const tr = document.createElement("tr");
            tr.innerHTML = `
                <td><strong>${itemId}</strong></td>
                <td style="max-width:140px;overflow:hidden;text-overflow:ellipsis;">${item.item}</td>
                <td>${item.qty}</td>
                <td>${qtyHtml}</td>
                <td style="text-align:center;">${conditionHtml}</td>`;
            tbody.appendChild(tr);

            // If qty is set to 0, disable the checkbox for that component/item.
            const qtyInputEl = document.getElementById(`qty-return-${item.id}`);
            const chkEl = document.getElementById(`chk-return-${item.id}`);
            if (qtyInputEl && chkEl) {
                const applyDisable = () => {
                    const v = parseInt(qtyInputEl.value) || 0;
                    if (v <= 0) {
                        chkEl.checked = false;
                        chkEl.disabled = true;
                        chkEl.style.cursor = "not-allowed";
                        chkEl.style.opacity = "0.6";
                    } else {
                        chkEl.disabled = false;
                        chkEl.style.cursor = "pointer";
                        chkEl.style.opacity = "1";
                    }
                };
                qtyInputEl.addEventListener("input", applyDisable);
                applyDisable();
            }

        });

        // Reset the Lab In-Charge verification checkbox every time the drawer opens
        const verifyChk = document.getElementById("chk-incharge-verify");
        if (verifyChk) verifyChk.checked = false;

        document.getElementById("drawerOverlay").classList.add("show");
        document.getElementById("returnReviewDrawer").classList.add("show");
        recalculateReturnSummary();
    };

    // ── Drawer close ──────────────────────────────────────────────────────────
    window.closeDrawer = function () {
        document.getElementById("drawerOverlay").classList.remove("show");
        document.getElementById("returnReviewDrawer").classList.remove("show");
        activeTeamId    = null;
        activeTeamItems = [];
    };

    // ── Qty validation ────────────────────────────────────────────────────────
    window.validateAndRecalculate = function (id, maxQty) {
        const input = document.getElementById(`qty-return-${id}`);
        if (input) {
            let val = parseInt(input.value);
            if (isNaN(val) || val < 0) input.value = 0;
            else if (val > maxQty)     input.value = maxQty;
        }
        recalculateReturnSummary();
    };

    // ── Summary recalculation ─────────────────────────────────────────────────
    window.recalculateReturnSummary = function () {
        if (!activeTeamId || !activeTeamItems.length) return;
        let totalIssued = 0, totalReturned = 0, totalDamaged = 0;

        // All items are now always interactive — read from inputs directly
        activeTeamItems.forEach(item => {
            const qtyEl = document.getElementById(`qty-return-${item.id}`);
            const chkEl = document.getElementById(`chk-return-${item.id}`);
            let qty = 0;

            if (qtyEl) {
                qty = parseInt(qtyEl.value) || 0;
                totalReturned += qty;
            }
            if (chkEl && !chkEl.checked) {
                totalDamaged++;
            }
            totalIssued += item.qty;
        });

        document.getElementById("sumIssued").textContent   = totalIssued;
        document.getElementById("sumReturned").textContent = totalReturned;
        document.getElementById("sumDamaged").textContent  = totalDamaged;

        const status = "Pending";
        document.getElementById("sumStatus").textContent = status;
        
        const badge = document.getElementById("drawerStatusBadge");
        badge.textContent = status;
        badge.className   = `badge status-pending`;

        // Always show submit & cancel buttons since all items are editable
        const submitBtn = document.querySelector('.drawer-footer .btn-primary');
        const cancelBtn = document.querySelector('.drawer-footer .btn-secondary');
        if (submitBtn) submitBtn.style.display = "block";
        if (cancelBtn) cancelBtn.textContent = "Cancel";
    };

    // ── Submit return ─────────────────────────────────────────────────────────
    window.submitReturn = function () {
        if (!activeTeamId || !activeTeamItems.length) return;

        // ── Mandatory Lab In-Charge verification check ──────────────────────────
        const verifyChk = document.getElementById("chk-incharge-verify");
        if (!verifyChk || !verifyChk.checked) {
            showToast("Lab In-Charge verification is required. Please check the confirmation box before submitting.", "warn");
            return;
        }

        let dbNow = getDB();
        let ticketsAdded = 0;
        const listKey = currentView === "components" ? "materialReturns" : "toolReturns";

        activeTeamItems.forEach(item => {
            const qtyEl = document.getElementById(`qty-return-${item.id}`);
            const chkEl = document.getElementById(`chk-return-${item.id}`);
            if (!qtyEl || !chkEl) return;

            const returnedQty = parseInt(qtyEl.value) || 0;
            const isGood      = chkEl.checked;
            const idx         = dbNow[listKey].findIndex(r => r.id === item.id);

            if (idx > -1) {
                dbNow[listKey][idx].returnedQty = returnedQty;
                dbNow[listKey][idx].isGood      = isGood;

                // If lab incharge returns less than issued:
                // - when marked Good -> Partial return (Good)
                // - when marked Damaged -> Partial return (Damaged)
                // Otherwise:
                // - full return -> Returned / Damaged
                const isPartial = returnedQty < item.qty;
                if (isPartial) {
                    dbNow[listKey][idx].status = isGood ? "Partial Returned" : "Partial Damaged";
                } else {
                    dbNow[listKey][idx].status = isGood ? "Returned" : "Damaged";
                }


                if (!isGood) {
                    dbNow[listKey][idx].ticketRaised = true;
                    ticketsAdded++;
                    dbNow.tickets.push(buildDamageTicket(dbNow, activeTeamId, item, returnedQty));

                    // Update the item status in inventory to "Repairing"
                    const itemId = resolveItemId(item.item);
                    if (currentView === "components") {
                        const invItem = dbNow.inventory.find(inv => inv.id === itemId);
                        if (invItem) invItem.status = "Repairing";
                    } else {
                        const toolItem = dbNow.tools.find(t => t.toolid === itemId);
                        if (toolItem) toolItem.status = "Damaged";
                    }
                }
            }
        });

        setDB(dbNow);
        db = dbNow;

        const msg = ticketsAdded > 0
            ? `Return submitted: ${ticketsAdded} item(s) flagged for Damage Ticket.`
            : "Returns submitted and verified successfully!";
        showToast(msg, ticketsAdded > 0 ? "warn" : "success");

        closeDrawer();
        updateKPIs();
        renderCards();
    };

    // ── Damage ticket builder ─────────────────────────────────────────────────
    function buildDamageTicket(dbNow, teamId, item, returnedQty) {
        const last    = dbNow.tickets.length > 0 ? dbNow.tickets[dbNow.tickets.length - 1] : { id: "TKT-000" };
        const nextNum = (parseInt(last.id.split("-")[1]) || 0) + 1;
        const nextId  = "TKT-" + String(nextNum).padStart(3, "0");
        const today   = new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
        const due     = new Date(Date.now() + 7 * 86400000).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" });
        const time    = new Date().toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
        return {
            id: nextId, type: "Damage", assignedTo: teamId,
            subject: `${item.item} Damaged`, priority: "High",
            date: today, status: "Pending",
            teamName: item.teamName, equipmentName: item.item,
            raisedBy: "Lab Incharge", time,
            damageDescription: `Item returned in damaged/faulty condition. Returned: ${returnedQty}/${item.qty} units.`,
            fineAmount: "500", dueDate: due,
            remarks: "Auto-generated upon material return check-in — flagged for inspection.",
            teamResponse: "", lastUpdated: `${today}, ${time}`
        };
    }

    // ── Search & filter listeners ─────────────────────────────────────────────
    if (searchInput) {
        searchInput.addEventListener("input", debounce(e => {
            currentFilters.search = e.target.value.trim();
            currentPage = 1;
            renderCards();
        }, 250));
    }

    filterTabs.forEach(tab => {
        tab.addEventListener("click", () => {
            filterTabs.forEach(t => t.classList.remove("active"));
            tab.classList.add("active");
            currentFilters.status = tab.dataset.status;
            currentPage = 1;
            renderCards();
        });
    });

    // ── Initial load ──────────────────────────────────────────────────────────
    updateKPIs();
    renderCards();
});


/* === js/material-returns.js === */
// ==========================================================================
// 1. INITIAL RETURNS DATASETS (TOOLS & COMPONENTS)
// ==========================================================================
const initialReturns = [
  {
    id: "TR-2025-0012",
    team: "Team Alpha",
    project: "Smart Irrigation",
    leader: "Surendhan",
    faculty: "Dr. Kumar",
    issuedDate: "14 May 2025 10:00 AM",
    expectedReturn: "15 May 2025 05:00 PM",
    items: [
      { name: "Screwdriver (Phillips)", issued: 5, alreadyReturned: 3, returnedToday: 2, good: 2, damaged: 0, missing: 0, remarks: "" },
      { name: "Plier", issued: 2, alreadyReturned: 1, returnedToday: 1, good: 1, damaged: 0, missing: 0, remarks: "" },
      { name: "Cutter", issued: 1, alreadyReturned: 0, returnedToday: 1, good: 0, damaged: 0, missing: 1, remarks: "Team informed that it is misplaced during testing and not able to locate." },
      { name: "Multimeter", issued: 1, alreadyReturned: 0, returnedToday: 1, good: 1, damaged: 0, missing: 0, remarks: "" }
    ],
    status: "Pending",
    verifiedOn: ""
  },
  {
    id: "TR-2025-0021",
    team: "Team Beta",
    project: "Line Follower Robot",
    leader: "Karthik",
    faculty: "Dr. Priya",
    issuedDate: "14 May 2025 11:00 AM",
    expectedReturn: "15 May 2025 04:00 PM",
    items: [
      { name: "Multimeter", issued: 1, alreadyReturned: 0, returnedToday: 1, good: 1, damaged: 0, missing: 0, remarks: "" }
    ],
    status: "Pending",
    verifiedOn: ""
  },
  {
    id: "TR-2025-0028",
    team: "Team Gamma",
    project: "Home Automation",
    leader: "Lokesh",
    faculty: "Prof. Ramesh",
    issuedDate: "14 May 2025 01:00 PM",
    expectedReturn: "15 May 2025 03:00 PM",
    items: [
      { name: "Screwdriver (Phillips)", issued: 1, alreadyReturned: 0, returnedToday: 1, good: 1, damaged: 0, missing: 0, remarks: "" },
      { name: "Cutter", issued: 1, alreadyReturned: 0, returnedToday: 1, good: 1, damaged: 0, missing: 0, remarks: "" }
    ],
    status: "Pending",
    verifiedOn: ""
  },
  {
    id: "TR-2025-0035",
    team: "Team Delta",
    project: "Weather Station",
    leader: "Vignesh",
    faculty: "Dr. Kumar",
    issuedDate: "14 May 2025 02:00 PM",
    expectedReturn: "15 May 2025 02:00 PM",
    items: [
      { name: "Plier", issued: 1, alreadyReturned: 1, returnedToday: 0, good: 0, damaged: 0, missing: 0, remarks: "" }
    ],
    status: "Completed",
    verifiedOn: "15 May 2025 02:30 PM"
  }
];

const initialComponentReturns = [
  {
    id: "CR-2025-0001",
    team: "Team Alpha",
    project: "Smart Irrigation",
    leader: "Surendhan",
    faculty: "Dr. Kumar",
    issuedDate: "14 May 2025 10:00 AM",
    expectedReturn: "Project Completion",
    items: [
      { name: "Arduino Uno R3", issued: 2, alreadyReturned: 1, returnedToday: 1, good: 1, damaged: 0, missing: 0, remarks: "" },
      { name: "Servo Motor SG90", issued: 4, alreadyReturned: 2, returnedToday: 2, good: 2, damaged: 0, missing: 0, remarks: "" },
      { name: "Breadboard 830 Points", issued: 2, alreadyReturned: 1, returnedToday: 1, good: 1, damaged: 0, missing: 0, remarks: "" }
    ],
    status: "Pending",
    verifiedOn: ""
  },
  {
    id: "CR-2025-0002",
    team: "Team Beta",
    project: "Line Follower Robot",
    leader: "Karthik",
    faculty: "Dr. Priya",
    issuedDate: "14 May 2025 11:00 AM",
    expectedReturn: "Project Completion",
    items: [
      { name: "Ultrasonic Sensor", issued: 3, alreadyReturned: 1, returnedToday: 2, good: 2, damaged: 0, missing: 0, remarks: "" },
      { name: "Lithium Ion Battery", issued: 5, alreadyReturned: 3, returnedToday: 2, good: 1, damaged: 0, missing: 1, remarks: "One battery core swelling exception reported." }
    ],
    status: "Pending",
    verifiedOn: ""
  },
  {
    id: "CR-2025-0003",
    team: "Team Delta",
    project: "Weather Station",
    leader: "Vignesh",
    faculty: "Dr. Kumar",
    issuedDate: "14 May 2025 02:00 PM",
    expectedReturn: "Project Completion",
    items: [
      { name: "Raspberry Pi 4", issued: 1, alreadyReturned: 1, returnedToday: 0, good: 0, damaged: 0, missing: 0, remarks: "" }
    ],
    status: "Completed",
    verifiedOn: "Project Completion"
  }
];

// ==========================================================================
// 2. STATE OBJECT
// ==========================================================================
// Helper to save returns state
function saveReturnsState() {
  try {
    localStorage.setItem("rplms_returns_tool", JSON.stringify(state.returns));
    localStorage.setItem("rplms_returns_component", JSON.stringify(state.componentReturns));
  } catch (e) {
    console.warn("LocalStorage write failed in material-returns.js:", e);
  }
}

// Load returns from localStorage if present
let loadedReturns = [];
let loadedComponentReturns = [];

try {
  const storedTools = localStorage.getItem("rplms_returns_tool");
  const storedComps = localStorage.getItem("rplms_returns_component");
  
  if (storedTools && storedComps) {
    loadedReturns = JSON.parse(storedTools);
    loadedComponentReturns = JSON.parse(storedComps);
  } else {
    loadedReturns = JSON.parse(JSON.stringify(initialReturns));
    loadedComponentReturns = JSON.parse(JSON.stringify(initialComponentReturns));
    try {
      localStorage.setItem("rplms_returns_tool", JSON.stringify(loadedReturns));
      localStorage.setItem("rplms_returns_component", JSON.stringify(loadedComponentReturns));
    } catch (e) {}
  }
} catch (e) {
  console.warn("LocalStorage access blocked in material-returns.js. Using memory fallback.", e);
  loadedReturns = JSON.parse(JSON.stringify(initialReturns));
  loadedComponentReturns = JSON.parse(JSON.stringify(initialComponentReturns));
}

const state = {
  currentPage: "page-tool-returns",
  lastActivePage: "page-tool-returns",
  activeCategory: "tool", // "tool" or "component"
  returns: loadedReturns,
  componentReturns: loadedComponentReturns,
  activeReturnId: null,
  returnFilters: {
    search: "",
    faculty: "All",
    status: "All",
    date: "2025-05-15"
  },
  activeExceptionTarget: null
};

// ==========================================================================
// 3. DOM ELEMENTS
// ==========================================================================
const DOM = {
  get sidebarMenuItems() { return document.querySelectorAll(".sidebar-menu .menu-item"); },
  get dropdownChevron() { return document.querySelector(".dropdown-chevron"); },
  get returnsDropdownParent() { return document.querySelector(".menu-item-dropdown"); },
  get pageTitle() { return document.getElementById("page-title"); },
  
  get pageDashboard() { return document.getElementById("page-dashboard"); },
  get pageToolReturns() { return document.getElementById("page-tool-returns"); },
  get pageVerifyReturn() { return document.getElementById("page-verify-return"); },
  get pageSuccessReturn() { return document.getElementById("page-success-return"); },
  get pageDummy() { return document.getElementById("page-dummy"); },
  get dummyTitle() { return document.getElementById("dummy-title"); },
  get dummyDesc() { return document.getElementById("dummy-desc"); },
  get btnBackToActive() { return document.getElementById("btn-back-to-active"); },

  get returnsQueueBody() { return document.getElementById("returns-queue-table-body"); },
  get verifyToolsBody() { return document.getElementById("verify-tools-table-body"); },
  get successExceptionsList() { return document.getElementById("success-exceptions-list"); },
  get returnSearchInput() { return document.getElementById("return-search-input"); },
  get returnFacultySelect() { return document.getElementById("return-faculty-select"); },
  get returnStatusSelect() { return document.getElementById("return-status-select"); },
  get returnDateInput() { return document.getElementById("return-date-input"); },
  get btnClearReturnFilters() { return document.getElementById("btn-clear-return-filters"); },
  get btnBackToQueueHeader() { return document.getElementById("btn-back-to-queue-header"); },
  get btnCancelVerification() { return document.getElementById("btn-cancel-verification"); },
  get btnCompleteVerification() { return document.getElementById("btn-complete-verification"); },
  get btnSuccessViewDetails() { return document.getElementById("btn-success-view-details"); },
  get btnSuccessBackQueue() { return document.getElementById("btn-success-back-queue"); },

  get modalMarkDamaged() { return document.getElementById("modal-mark-damaged"); },
  get modalMarkMissing() { return document.getElementById("modal-mark-missing"); },
  get modalConfirmVerification() { return document.getElementById("modal-confirm-verification"); },

  get toastContainer() { return document.getElementById("toast-container"); }
};

// ==========================================================================
// 4. NAVIGATION & VIEWS
// ==========================================================================
function updateDashboardMetrics() {
  const tools = state.returns;
  const comps = state.componentReturns;
  
  // Tool metrics
  const toolPending = tools.filter(r => r.status === "Pending").length;
  const toolCompleted = tools.filter(r => r.status === "Completed").length;
  let toolOutstanding = 0;
  tools.forEach(r => {
    r.items.forEach(item => {
      toolOutstanding += (item.issued - item.alreadyReturned);
    });
  });
  
  // Component metrics
  const compPending = comps.filter(r => r.status === "Pending").length;
  const compCompleted = comps.filter(r => r.status === "Completed").length;
  let compOutstanding = 0;
  comps.forEach(r => {
    r.items.forEach(item => {
      compOutstanding += (item.issued - item.alreadyReturned);
    });
  });

  // Exceptions count
  let toolExceptions = 0;
  tools.forEach(r => {
    if (r.status === "Completed") {
      r.items.forEach(item => {
        if (item.damaged > 0 || item.missing > 0) {
          toolExceptions += (item.damaged + item.missing);
        }
      });
    }
  });
  let compExceptions = 0;
  comps.forEach(r => {
    if (r.status === "Completed") {
      r.items.forEach(item => {
        if (item.damaged > 0 || item.missing > 0) {
          compExceptions += (item.damaged + item.missing);
        }
      });
    }
  });

  // Set tool metrics
  const elToolPending = document.getElementById("kpi-tool-pending");
  const elToolOutstanding = document.getElementById("kpi-tool-outstanding");
  const elToolCompleted = document.getElementById("kpi-tool-completed");
  
  if (elToolPending) elToolPending.textContent = toolPending;
  if (elToolOutstanding) elToolOutstanding.textContent = toolOutstanding;
  if (elToolCompleted) elToolCompleted.textContent = toolCompleted;
  
  // Set comp metrics
  const elCompPending = document.getElementById("kpi-comp-pending");
  const elCompOutstanding = document.getElementById("kpi-comp-outstanding");
  const elCompCompleted = document.getElementById("kpi-comp-completed");
  
  if (elCompPending) elCompPending.textContent = compPending;
  if (elCompOutstanding) elCompOutstanding.textContent = compOutstanding;
  if (elCompCompleted) elCompCompleted.textContent = compCompleted;
  
  // Today's summary
  const elSummaryTotal = document.getElementById("summary-total");
  const elSummaryComponents = document.getElementById("summary-components");
  const elSummaryHandedToday = document.getElementById("summary-handed-today");
  const elSummaryPending = document.getElementById("summary-pending");
  
  // Materials returned today
  let returnedToday = 0;
  tools.forEach(r => {
    r.items.forEach(item => {
      returnedToday += item.returnedToday || 0;
    });
  });
  comps.forEach(r => {
    r.items.forEach(item => {
      returnedToday += item.returnedToday || 0;
    });
  });
  
  if (elSummaryTotal) elSummaryTotal.textContent = tools.length;
  if (elSummaryComponents) elSummaryComponents.textContent = comps.length;
  if (elSummaryHandedToday) elSummaryHandedToday.textContent = returnedToday;
  if (elSummaryPending) elSummaryPending.textContent = (toolExceptions + compExceptions);
}

function showPage(pageId) {
  state.currentPage = pageId;
  
  if (DOM.pageDashboard) DOM.pageDashboard.classList.add("hidden");
  if (DOM.pageToolReturns) DOM.pageToolReturns.classList.add("hidden");
  if (DOM.pageVerifyReturn) DOM.pageVerifyReturn.classList.add("hidden");
  if (DOM.pageSuccessReturn) DOM.pageSuccessReturn.classList.add("hidden");
  if (DOM.pageDummy) DOM.pageDummy.classList.add("hidden");
  
  if (DOM.sidebarMenuItems) {
    DOM.sidebarMenuItems.forEach(item => item.classList.remove("active"));
  }
  
  if (pageId === "page-dashboard") {
    if (DOM.pageDashboard) DOM.pageDashboard.classList.remove("hidden");
    if (DOM.pageTitle) DOM.pageTitle.textContent = "Dashboard";
    
    const returnsTrigger = document.getElementById("nav-return-status");
    if (returnsTrigger) {
      document.querySelectorAll(".sidebar-nav .nav-link").forEach(el => el.classList.remove("active"));
      returnsTrigger.classList.add("active");
    }
    
    updateDashboardMetrics();
  }
  else if (pageId === "page-tool-returns") {
    if (DOM.pageToolReturns) DOM.pageToolReturns.classList.remove("hidden");
    if (DOM.pageTitle) {
      DOM.pageTitle.textContent = state.activeCategory === "tool" ? "Return Status - Tools" : "Return Status - Components";
    }
    
    const returnsTrigger = document.getElementById("nav-return-status");
    if (returnsTrigger) {
      document.querySelectorAll(".sidebar-nav .nav-link").forEach(el => el.classList.remove("active"));
      returnsTrigger.classList.add("active");
    }
    
    // Highlight correct sub-menu link
    const activeSubTarget = state.activeCategory === "tool" ? "tool-returns" : "component-returns";
    const subMenuLink = document.querySelector(`.submenu-item[data-target="${activeSubTarget}"]`);
    if (subMenuLink) {
      document.querySelectorAll(".submenu-item").forEach(el => el.classList.remove("active"));
      subMenuLink.classList.add("active");
    }
    
    if (DOM.returnsDropdownParent) {
      DOM.returnsDropdownParent.classList.add("expanded");
    }
    
    state.lastActivePage = pageId;
    renderReturnsQueueTable();
  }
  else if (pageId === "page-verify-return") {
    if (DOM.pageVerifyReturn) DOM.pageVerifyReturn.classList.remove("hidden");
    if (DOM.pageTitle) DOM.pageTitle.textContent = "Verify Return Details";
    
    const returnsTrigger = document.querySelector('[data-target="returns-status"]');
    if (returnsTrigger) returnsTrigger.classList.add("active");
    
    renderVerifyReturnTable();
  }

  else if (pageId.startsWith("dummy-")) {
    const sectionName = pageId.replace("dummy-", "");
    if (DOM.pageDummy) DOM.pageDummy.classList.remove("hidden");
    
    const titleFormatted = sectionName.split("-").map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(" ");
    if (DOM.pageTitle) DOM.pageTitle.textContent = titleFormatted;
    if (DOM.dummyTitle) DOM.dummyTitle.textContent = `${titleFormatted} Module`;
    if (DOM.dummyDesc) DOM.dummyDesc.textContent = `The "${titleFormatted}" lab module is currently under layout design for the Prototrack Lab Portal. Switch to the active "Tool Returns" screen to interact with the mock workspace.`;
    
    const targetMenu = document.querySelector(`[data-target="${sectionName}"]`);
    if (targetMenu) targetMenu.classList.add("active");
  }
}

// ==========================================================================
// 5. TOAST NOTIFICATION UTILITY
// ==========================================================================
function showToast(message, type = "success") {
  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  
  let iconSVG = "";
  if (type === "success") {
    iconSVG = `<svg class="toast-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>`;
  } else {
    iconSVG = `<svg class="toast-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;
  }

  toast.innerHTML = `
    ${iconSVG}
    <span>${message}</span>
  `;
  
  if (DOM.toastContainer) DOM.toastContainer.appendChild(toast);
  setTimeout(() => toast.classList.add("show"), 10);
  
  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// ==========================================================================
// 6. BUSINESS LOGIC & DATA HELPERS
// ==========================================================================
function getActiveDataset() {
  return state.activeCategory === "tool" ? state.returns : state.componentReturns;
}

function getActiveReturn() {
  const dataset = getActiveDataset();
  return dataset.find(r => r.id === state.activeReturnId);
}

function getFilteredReturns() {
  const dataset = getActiveDataset();
  return dataset.filter(ret => {
    const query = state.returnFilters.search.toLowerCase();
    const matchesSearch = !query || 
      ret.id.toLowerCase().includes(query) ||
      ret.team.toLowerCase().includes(query) ||
      ret.project.toLowerCase().includes(query) ||
      ret.leader.toLowerCase().includes(query) ||
      ret.items.some(item => item.name.toLowerCase().includes(query));

    const matchesFaculty = state.returnFilters.faculty === "All" || ret.faculty === state.returnFilters.faculty;
    const matchesStatus = state.returnFilters.status === "All" || ret.status === state.returnFilters.status;

    let matchesDate = true;
    if (state.activeCategory === "tool" && state.returnFilters.date && ret.expectedReturn) {
      const filterDateStr = state.returnFilters.date;
      const months = { "Jan":"01", "Feb":"02", "Mar":"03", "Apr":"04", "May":"05", "Jun":"06", "Jul":"07", "Aug":"08", "Sep":"09", "Oct":"10", "Nov":"11", "Dec":"12" };
      const parts = ret.expectedReturn.split(" ");
      if (parts.length >= 3) {
        const day = parts[0].padStart(2, "0");
        const month = months[parts[1]] || "01";
        const year = parts[2];
        const formattedExpected = `${year}-${month}-${day}`;
        matchesDate = (formattedExpected === filterDateStr);
      }
    }

    return matchesSearch && matchesFaculty && matchesStatus && matchesDate;
  });
}

function renderReturnsQueueTable() {
  const filtered = getFilteredReturns();
  if (!DOM.returnsQueueBody) return;
  DOM.returnsQueueBody.innerHTML = "";

  const dataset = getActiveDataset();
  const pendingCount = dataset.filter(r => r.status === "Pending").length;
  const completedCount = dataset.filter(r => r.status === "Completed").length;
  
  const kpiPending = document.getElementById("kpi-returns-pending");
  const kpiCompleted = document.getElementById("kpi-returns-completed");
  const kpiOutstanding = document.getElementById("kpi-returns-outstanding");
  const kpiExceptions = document.getElementById("kpi-returns-exceptions");

  if (kpiPending) kpiPending.textContent = pendingCount;
  if (kpiCompleted) kpiCompleted.textContent = completedCount;
  
  let totalOutstanding = 0;
  dataset.forEach(r => {
    r.items.forEach(item => {
      totalOutstanding += (item.issued - item.alreadyReturned);
    });
  });
  if (kpiOutstanding) kpiOutstanding.textContent = totalOutstanding;
  
  let totalExceptions = 0;
  dataset.forEach(r => {
    if (r.status === "Completed") {
      r.items.forEach(item => {
        if (item.damaged > 0 || item.missing > 0) {
          totalExceptions += (item.damaged + item.missing);
        }
      });
    }
  });
  if (kpiExceptions) kpiExceptions.textContent = totalExceptions;

  if (filtered.length === 0) {
    DOM.returnsQueueBody.innerHTML = `
      <tr>
        <td colspan="8" class="text-center text-muted" style="padding: 30px;">
          No ${state.activeCategory === "tool" ? "tool" : "component"} returns found matching filters.
        </td>
      </tr>
    `;
    const pagInfo = document.getElementById("returns-pagination-info");
    if (pagInfo) pagInfo.textContent = "Showing 0 to 0 of 0 entries";
    return;
  }

function getTeamId(teamName) {
  if (!teamName) return "—";
  const parts = teamName.split(" ");
  const initials = parts.map(p => p[0]).join("").toUpperCase();
  return `${initials}-001`;
}

function extractTime(dateTimeStr) {
  if (!dateTimeStr) return "—";
  const parts = dateTimeStr.split(" ");
  if (parts.length >= 5) {
    return `${parts[3]} ${parts[4]}`;
  }
  if (dateTimeStr.includes("AM") || dateTimeStr.includes("PM")) {
    const timeMatch = dateTimeStr.match(/\d{2}:\d{2}\s*(AM|PM)/i);
    if (timeMatch) return timeMatch[0];
  }
  return "—";
}

function extractDate(dateTimeStr) {
  if (!dateTimeStr) return "—";
  if (dateTimeStr === "Project Completion") return "Project Completion";
  const parts = dateTimeStr.split(" ");
  if (parts.length >= 3) {
    return `${parts[0]} ${parts[1]} ${parts[2]}`;
  }
  return dateTimeStr;
}

  const term = state.returnFilters.search;
  const h = (text) => {
    if (!term || !text) return text;
    const safeTerm = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const regex = new RegExp(`(${safeTerm})`, 'gi');
    return String(text).replace(regex, '<mark>$1</mark>');
  };

  filtered.forEach(ret => {
    const tr = document.createElement("tr");
    const teamId = ret.teamId || getTeamId(ret.team);
    const returnTime = ret.expectedReturn === "Project Completion" ? "—" : extractTime(ret.expectedReturn);
    const returnDate = extractDate(ret.expectedReturn);

    const statusBadgeClass = ret.status === "Pending" ? "status-badge-pending" : "status-badge-completed";
    
    let actionBtnHTML = "";
    if (ret.status === "Pending") {
      actionBtnHTML = `<button class="btn btn-primary btn-sm btn-verify-ret" data-id="${ret.id}">Verify Return</button>`;
    } else {
      actionBtnHTML = `<button class="btn btn-outline btn-sm btn-view-success" data-id="${ret.id}">View Details</button>`;
    }

    tr.innerHTML = `
      <td><strong>${h(ret.id)}</strong></td>
      <td>${h(teamId)}</td>
      <td>${h(ret.team)}</td>
      <td>${h(ret.faculty)}</td>
      <td>${returnTime}</td>
      <td>${returnDate}</td>
      <td><span class="${statusBadgeClass}">${ret.status}</span></td>
      <td class="text-center">${actionBtnHTML}</td>
    `;

    const verifyBtn = tr.querySelector(".btn-verify-ret");
    if (verifyBtn) {
      verifyBtn.addEventListener("click", () => {
        state.activeReturnId = ret.id;
        showPage("page-verify-return");
      });
    }

    const viewBtn = tr.querySelector(".btn-view-success");
    if (viewBtn) {
      viewBtn.addEventListener("click", () => {
        state.activeReturnId = ret.id;
        showPage("page-success-return");
      });
    }

    DOM.returnsQueueBody.appendChild(tr);
  });

  const pagInfo = document.getElementById("returns-pagination-info");
  if (pagInfo) pagInfo.textContent = `Showing 1 to ${filtered.length} of ${filtered.length} entries`;
}

function renderVerifyReturnTable() {
  const ret = getActiveReturn();
  if (!ret) return;

  // Update breadcrumb and header text labels dynamically based on category
  const bCategory = document.getElementById("breadcrumb-category");
  const tHeader = document.getElementById("verify-table-item-header");
  const dModalLabel = document.getElementById("damaged-modal-item-label");
  const mModalLabel = document.getElementById("missing-modal-item-label");

  if (state.activeCategory === "tool") {
    if (bCategory) bCategory.textContent = "Tool Returns";
    if (tHeader) tHeader.textContent = "Tool";
    if (dModalLabel) dModalLabel.textContent = "Tool";
    if (mModalLabel) mModalLabel.textContent = "Tool";
  } else {
    if (bCategory) bCategory.textContent = "Component Returns";
    if (tHeader) tHeader.textContent = "Component";
    if (dModalLabel) dModalLabel.textContent = "Component";
    if (mModalLabel) mModalLabel.textContent = "Component";
  }

  const tTeam = document.getElementById("verify-meta-team");
  const tProj = document.getElementById("verify-meta-project");
  const tLead = document.getElementById("verify-meta-leader");
  const tFac = document.getElementById("verify-meta-faculty");
  const tIssue = document.getElementById("verify-meta-issuedate");
  const tExp = document.getElementById("verify-meta-expectdate");

  if (tTeam) tTeam.textContent = ret.team;
  if (tProj) tProj.textContent = ret.project;
  if (tLead) tLead.textContent = ret.leader;
  if (tFac) tFac.textContent = ret.faculty;
  if (tIssue) tIssue.textContent = ret.issuedDate;
  if (tExp) tExp.textContent = ret.expectedReturn;

  if (!DOM.verifyToolsBody) return;
  DOM.verifyToolsBody.innerHTML = "";

  ret.items.forEach((item, index) => {
    const tr = document.createElement("tr");
    const outstanding = item.issued - item.alreadyReturned - item.returnedToday;
    
    let detailsHTML = "-";
    if (item.damaged > 0) {
      const iconColor = item.remarks ? "color: var(--status-green);" : "color: var(--status-red);";
      detailsHTML = `
        <span class="exception-label-badge damaged">Damaged: ${item.damaged}</span>
        <button class="btn-edit-exception" data-index="${index}" data-type="damaged">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 14px; height: 14px; margin-left: 4px; ${iconColor}"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
        </button>
      `;
    } else if (item.missing > 0) {
      const iconColor = item.remarks ? "color: var(--status-green);" : "color: var(--status-orange);";
      detailsHTML = `
        <span class="exception-label-badge missing">Missing: ${item.missing}</span>
        <button class="btn-edit-exception" data-index="${index}" data-type="missing">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 14px; height: 14px; margin-left: 4px; ${iconColor}"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
        </button>
      `;
    }

    const maxReturnedToday = item.issued - item.alreadyReturned;

    tr.innerHTML = `
      <td><strong>${item.name}</strong></td>
      <td class="text-right font-medium">${item.issued}</td>
      <td class="text-right text-secondary">${item.alreadyReturned}</td>
      <td class="text-center col-verify-qty"><input type="number" class="input-returned-today" min="0" max="${maxReturnedToday}" value="${item.returnedToday}"></td>
      <td class="text-center col-verify-qty"><input type="number" class="input-good" min="0" max="${item.returnedToday}" value="${item.good}"></td>
      <td class="text-center col-verify-qty"><input type="number" class="input-damaged" min="0" max="${item.returnedToday}" value="${item.damaged}"></td>
      <td class="text-center col-verify-qty"><input type="number" class="input-missing" min="0" max="${item.returnedToday}" value="${item.missing}"></td>
      <td class="text-right font-medium" id="outstanding-cell-${index}">${outstanding}</td>
      <td id="details-cell-${index}">${detailsHTML}</td>
    `;

    const inputRet = tr.querySelector(".input-returned-today");
    const inputGood = tr.querySelector(".input-good");
    const inputDamaged = tr.querySelector(".input-damaged");
    const inputMissing = tr.querySelector(".input-missing");

    inputRet.addEventListener("change", (e) => {
      let val = parseInt(e.target.value);
      const maxRet = item.issued - item.alreadyReturned;
      if (isNaN(val) || val < 0) val = 0;
      if (val > maxRet) val = maxRet;
      
      e.target.value = val;
      item.returnedToday = val;
      item.good = val;
      item.damaged = 0;
      item.missing = 0;
      item.remarks = "";

      renderVerifyReturnTable();
    });

    inputGood.addEventListener("change", (e) => {
      let val = parseInt(e.target.value);
      if (isNaN(val) || val < 0) val = 0;
      if (val > item.returnedToday) val = item.returnedToday;
      
      e.target.value = val;
      item.good = val;
      
      const diff = item.returnedToday - item.good;
      if (item.damaged + item.missing !== diff) {
        item.missing = diff;
        item.damaged = 0;
      }
      
      renderVerifyReturnTable();
    });

    inputDamaged.addEventListener("change", (e) => {
      let val = parseInt(e.target.value);
      const maxDamaged = item.returnedToday - item.good;
      if (isNaN(val) || val < 0) val = 0;
      if (val > maxDamaged) val = maxDamaged;
      
      e.target.value = val;
      item.damaged = val;
      item.missing = item.returnedToday - item.good - val;

      if (val > 0) {
        openRemarksModal(index, "damaged");
      }
      renderVerifyReturnTable();
    });

    inputMissing.addEventListener("change", (e) => {
      let val = parseInt(e.target.value);
      const maxMissing = item.returnedToday - item.good;
      if (isNaN(val) || val < 0) val = 0;
      if (val > maxMissing) val = maxMissing;
      
      e.target.value = val;
      item.missing = val;
      item.damaged = item.returnedToday - item.good - val;

      if (val > 0) {
        openRemarksModal(index, "missing");
      }
      renderVerifyReturnTable();
    });

    const editBtn = tr.querySelector(".btn-edit-exception");
    if (editBtn) {
      editBtn.addEventListener("click", () => {
        const type = editBtn.getAttribute("data-type");
        openRemarksModal(index, type);
      });
    }

    DOM.verifyToolsBody.appendChild(tr);
  });

  updateVerificationSummaryMetrics(ret);
}

function updateVerificationSummaryMetrics(ret) {
  let returnedToday = 0;
  let good = 0;
  let damaged = 0;
  let missing = 0;
  let outstanding = 0;
  let exceptions = 0;

  ret.items.forEach(item => {
    returnedToday += item.returnedToday;
    good += item.good;
    damaged += item.damaged;
    missing += item.missing;
    outstanding += (item.issued - item.alreadyReturned - item.returnedToday);
  });

  exceptions = damaged + missing;

  const sRet = document.getElementById("sum-returned-today");
  const sGood = document.getElementById("sum-good");
  const sDamaged = document.getElementById("sum-damaged");
  const sMissing = document.getElementById("sum-missing");
  const sOut = document.getElementById("sum-outstanding");
  const sExc = document.getElementById("sum-exceptions");

  if (sRet) sRet.textContent = returnedToday;
  if (sGood) sGood.textContent = good;
  if (sDamaged) sDamaged.textContent = damaged;
  if (sMissing) sMissing.textContent = missing;
  if (sOut) sOut.textContent = outstanding;
  if (sExc) sExc.textContent = exceptions;

  let allRemarksAdded = true;
  ret.items.forEach(item => {
    if ((item.damaged > 0 || item.missing > 0) && !item.remarks) {
      allRemarksAdded = false;
    }
  });

  if (DOM.btnCompleteVerification) {
    DOM.btnCompleteVerification.disabled = (returnedToday === 0) || !allRemarksAdded;
  }
}

function openRemarksModal(index, type) {
  const ret = getActiveReturn();
  if (!ret) return;
  
  const item = ret.items[index];
  state.activeExceptionTarget = { index, type };

  if (type === "damaged") {
    const mTool = document.getElementById("damaged-modal-tool");
    const mQty = document.getElementById("damaged-modal-qty");
    const mRemarks = document.getElementById("damaged-modal-remarks");
    if (mTool) mTool.value = item.name;
    if (mQty) mQty.value = item.damaged;
    if (mRemarks) mRemarks.value = item.remarks || "";
    if (DOM.modalMarkDamaged) DOM.modalMarkDamaged.classList.remove("hidden");
  } else {
    const mTool = document.getElementById("missing-modal-tool");
    const mQty = document.getElementById("missing-modal-qty");
    const mRemarks = document.getElementById("missing-modal-remarks");
    if (mTool) mTool.value = item.name;
    if (mQty) mQty.value = item.missing;
    if (mRemarks) mRemarks.value = item.remarks || "";
    if (DOM.modalMarkMissing) DOM.modalMarkMissing.classList.remove("hidden");
  }
}

function saveRemarks(type) {
  const ret = getActiveReturn();
  if (!ret || !state.activeExceptionTarget) return;

  const { index } = state.activeExceptionTarget;
  const item = ret.items[index];
  
  let remarksVal = "";
  if (type === "damaged") {
    const mRemarks = document.getElementById("damaged-modal-remarks");
    remarksVal = mRemarks ? mRemarks.value.trim() : "";
    if (!remarksVal) {
      showToast("Please enter remarks explaining the damage.", "error");
      return;
    }
    item.remarks = remarksVal;
    if (DOM.modalMarkDamaged) DOM.modalMarkDamaged.classList.add("hidden");
  } else {
    const mRemarks = document.getElementById("missing-modal-remarks");
    remarksVal = mRemarks ? mRemarks.value.trim() : "";
    if (!remarksVal) {
      showToast("Please enter remarks explaining the missing status.", "error");
      return;
    }
    item.remarks = remarksVal;
    if (DOM.modalMarkMissing) DOM.modalMarkMissing.classList.add("hidden");
  }

  // Save updated state to localStorage
  saveReturnsState();

  showToast(`Saved remarks for ${item.name}!`);
  state.activeExceptionTarget = null;
  renderVerifyReturnTable();
}

function openConfirmVerificationModal() {
  const ret = getActiveReturn();
  if (!ret) return;

  let good = 0;
  let damaged = 0;
  let missing = 0;
  let outstanding = 0;
  
  ret.items.forEach(item => {
    good += item.good;
    damaged += item.damaged;
    missing += item.missing;
    outstanding += (item.issued - item.alreadyReturned - item.returnedToday);
  });

  const exceptions = damaged + missing;

  const cGood = document.getElementById("confirm-good-qty");
  const cDamaged = document.getElementById("confirm-damaged-qty");
  const cMissing = document.getElementById("confirm-missing-qty");
  const cOut = document.getElementById("confirm-outstanding-qty");
  const cExc = document.getElementById("confirm-exceptions-qty");

  if (cGood) cGood.textContent = good;
  if (cDamaged) cDamaged.textContent = damaged;
  if (cMissing) cMissing.textContent = missing;
  if (cOut) cOut.textContent = outstanding;
  if (cExc) cExc.textContent = exceptions;

  if (DOM.modalConfirmVerification) DOM.modalConfirmVerification.classList.remove("hidden");
}

function completeVerificationAndSave() {
  const ret = getActiveReturn();
  if (!ret) return;

  ret.status = "Completed";
  ret.items.forEach(item => {
    item.alreadyReturned += item.returnedToday;
  });

  // Save updated state to localStorage
  saveReturnsState();

  if (DOM.modalConfirmVerification) DOM.modalConfirmVerification.classList.add("hidden");
  showToast(`Successfully verified and recorded return ${ret.id}!`);
  
  // Show queue view, then open the success modal popup
  showPage("page-tool-returns");
  renderSuccessReturnSummary();
  if (DOM.pageSuccessReturn) DOM.pageSuccessReturn.classList.remove("hidden");
}

function renderSuccessReturnSummary() {
  const ret = getActiveReturn();
  if (!ret) return;

  const sTeam = document.getElementById("succ-meta-team");
  const sProj = document.getElementById("succ-meta-project");
  const sLead = document.getElementById("succ-meta-leader");
  const sRetId = document.getElementById("succ-meta-returnid");
  const sVerOn = document.getElementById("succ-meta-verifiedon");

  if (sTeam) sTeam.textContent = ret.team;
  if (sProj) sProj.textContent = ret.project;
  if (sLead) sLead.textContent = ret.leader;
  if (sRetId) sRetId.textContent = ret.id;
  
  const now = new Date();
  const formatTime = now.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) + " " + 
                     now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  if (sVerOn) sVerOn.textContent = formatTime;

  let issued = 0;
  let already = 0;
  let today = 0;
  let good = 0;
  let damaged = 0;
  let missing = 0;
  let outstanding = 0;

  ret.items.forEach(item => {
    issued += item.issued;
    already += item.alreadyReturned - item.returnedToday;
    today += item.returnedToday;
    good += item.good;
    damaged += item.damaged;
    missing += item.missing;
    outstanding += (item.issued - item.alreadyReturned);
  });

  const exceptionsCount = damaged + missing;

  const scIssued = document.getElementById("succ-sum-issued");
  const scAlready = document.getElementById("succ-sum-already");
  const scToday = document.getElementById("succ-sum-today");
  const scGood = document.getElementById("succ-sum-good");
  const scDamaged = document.getElementById("succ-sum-damaged");
  const scMissing = document.getElementById("succ-sum-missing");
  const scOut = document.getElementById("succ-sum-outstanding");
  const scExc = document.getElementById("succ-sum-exceptions");

  if (scIssued) scIssued.textContent = issued;
  if (scAlready) scAlready.textContent = already;
  if (scToday) scToday.textContent = today;
  if (scGood) scGood.textContent = good;
  if (scDamaged) scDamaged.textContent = damaged;
  if (scMissing) scMissing.textContent = missing;
  if (scOut) scOut.textContent = outstanding;
  if (scExc) scExc.textContent = exceptionsCount;

  if (!DOM.successExceptionsList) return;
  DOM.successExceptionsList.innerHTML = "";
  let exIndex = 46;
  
  ret.items.forEach(item => {
    if (item.damaged > 0) {
      const card = document.createElement("div");
      card.className = "exception-mini-card";
      card.innerHTML = `
        <div class="exception-header-mini">
          <span>EX-2025-00${exIndex++}</span>
          <span class="exception-label-badge damaged">Damaged</span>
        </div>
        <div class="exception-meta-mini">${item.name} (Qty: ${item.damaged})</div>
        <div class="exception-remarks-mini">"${item.remarks}"</div>
      `;
      DOM.successExceptionsList.appendChild(card);
    }
    if (item.missing > 0) {
      const card = document.createElement("div");
      card.className = "exception-mini-card missing";
      card.innerHTML = `
        <div class="exception-header-mini">
          <span>EX-2025-00${exIndex++}</span>
          <span class="exception-label-badge missing">Missing</span>
        </div>
        <div class="exception-meta-mini">${item.name} (Qty: ${item.missing})</div>
        <div class="exception-remarks-mini">"${item.remarks}"</div>
      `;
      DOM.successExceptionsList.appendChild(card);
    }
  });

  if (exceptionsCount === 0) {
    DOM.successExceptionsList.innerHTML = `
      <div class="text-center text-muted" style="padding: 20px;">
        No exceptions created for this return.
      </div>
    `;
  }
}

// ==========================================================================
// 7. EVENT BINDINGS
// ==========================================================================
function switchTab(category) {
  state.activeCategory = category;
  
  // Update tab buttons
  const tabToolBtn = document.getElementById("tab-tool-returns");
  const tabCompBtn = document.getElementById("tab-component-returns");
  if (category === "tool") {
    if (tabToolBtn) tabToolBtn.classList.add("active");
    if (tabCompBtn) tabCompBtn.classList.remove("active");
  } else {
    if (tabToolBtn) tabToolBtn.classList.remove("active");
    if (tabCompBtn) tabCompBtn.classList.add("active");
  }
  
  // Update sidebar submenu active states
  const submenuItems = document.querySelectorAll(".submenu-item");
  submenuItems.forEach(item => {
    const target = item.getAttribute("data-target");
    if ((category === "tool" && target === "tool-returns") || 
        (category === "component" && target === "component-returns")) {
      item.classList.add("active");
    } else {
      item.classList.remove("active");
    }
  });

  showPage("page-tool-returns");
}

function bindEvents() {
  if (DOM.sidebarMenuItems) {
    DOM.sidebarMenuItems.forEach(item => {
      item.addEventListener("click", (e) => {
        const target = item.getAttribute("data-target");
        if (target === "returns-status") {
          e.preventDefault();
          if (DOM.returnsDropdownParent) {
            DOM.returnsDropdownParent.classList.toggle("expanded");
          }
        }
      });
    });
  }

  // Sidebar Return Status Link click handler
  const navReturnStatus = document.getElementById("nav-return-status");
  if (navReturnStatus) {
    navReturnStatus.addEventListener("click", (e) => {
      e.preventDefault();
      showPage("page-dashboard");
    });
  }

  // Dashboard Open Queue Buttons click handlers
  const btnOpenToolQueue = document.getElementById("btn-open-tool-queue");
  if (btnOpenToolQueue) {
    btnOpenToolQueue.addEventListener("click", () => {
      switchTab("tool");
    });
  }

  const btnOpenComponentQueue = document.getElementById("btn-open-component-queue");
  if (btnOpenComponentQueue) {
    btnOpenComponentQueue.addEventListener("click", () => {
      switchTab("component");
    });
  }

  const btnBackToDashboard = document.getElementById("btn-back-to-dashboard");
  if (btnBackToDashboard) {
    btnBackToDashboard.addEventListener("click", () => {
      showPage("page-dashboard");
    });
  }

  // Submenu switches inside returns folder
  const submenuItems = document.querySelectorAll(".submenu-item");
  submenuItems.forEach(item => {
    item.addEventListener("click", (e) => {
      const target = item.getAttribute("data-target");
      if (target === "tool-returns") {
        e.preventDefault();
        switchTab("tool");
      } else if (target === "component-returns") {
        e.preventDefault();
        switchTab("component");
      }
    });
  });

  // Tab button bindings
  const tabToolBtn = document.getElementById("tab-tool-returns");
  const tabCompBtn = document.getElementById("tab-component-returns");
  if (tabToolBtn) {
    tabToolBtn.addEventListener("click", () => switchTab("tool"));
  }
  if (tabCompBtn) {
    tabCompBtn.addEventListener("click", () => switchTab("component"));
  }

  const applyReturnFilters = () => {
    state.returnFilters.search = DOM.returnSearchInput ? DOM.returnSearchInput.value : "";
    state.returnFilters.faculty = DOM.returnFacultySelect ? DOM.returnFacultySelect.value : "All";
    state.returnFilters.status = DOM.returnStatusSelect ? DOM.returnStatusSelect.value : "All";
    state.returnFilters.date = DOM.returnDateInput ? DOM.returnDateInput.value : "";
    renderReturnsQueueTable();
  };

  if (DOM.returnSearchInput) DOM.returnSearchInput.addEventListener("input", applyReturnFilters);
  if (DOM.returnFacultySelect) DOM.returnFacultySelect.addEventListener("change", applyReturnFilters);
  if (DOM.returnStatusSelect) DOM.returnStatusSelect.addEventListener("change", applyReturnFilters);
  if (DOM.returnDateInput) DOM.returnDateInput.addEventListener("change", applyReturnFilters);

  if (DOM.btnClearReturnFilters) {
    DOM.btnClearReturnFilters.addEventListener("click", () => {
      if (DOM.returnSearchInput) DOM.returnSearchInput.value = "";
      if (DOM.returnFacultySelect) DOM.returnFacultySelect.value = "All";
      if (DOM.returnStatusSelect) DOM.returnStatusSelect.value = "All";
      if (DOM.returnDateInput) DOM.returnDateInput.value = "2025-05-15";
      
      state.returnFilters.search = "";
      state.returnFilters.faculty = "All";
      state.returnFilters.status = "All";
      state.returnFilters.date = "2025-05-15";
      
      renderReturnsQueueTable();
      showToast("Return filters cleared.");
    });
  }

  if (DOM.btnBackToQueueHeader) {
    DOM.btnBackToQueueHeader.addEventListener("click", () => showPage("page-tool-returns"));
  }
  
  if (DOM.btnCancelVerification) {
    DOM.btnCancelVerification.addEventListener("click", () => {
      showPage("page-tool-returns");
      showToast("Verification cancelled.");
    });
  }

  if (DOM.btnCompleteVerification) {
    DOM.btnCompleteVerification.addEventListener("click", () => openConfirmVerificationModal());
  }

  document.querySelectorAll(".modal-close-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      if (DOM.modalMarkDamaged) DOM.modalMarkDamaged.classList.add("hidden");
      if (DOM.modalMarkMissing) DOM.modalMarkMissing.classList.add("hidden");
      if (DOM.modalConfirmVerification) DOM.modalConfirmVerification.classList.add("hidden");
      state.activeExceptionTarget = null;
    });
  });

  const btnCancelDamaged = document.getElementById("btn-cancel-damaged-modal");
  if (btnCancelDamaged) {
    btnCancelDamaged.addEventListener("click", () => cancelRemarksModal("damaged"));
  }

  const btnCancelMissing = document.getElementById("btn-cancel-missing-modal");
  if (btnCancelMissing) {
    btnCancelMissing.addEventListener("click", () => cancelRemarksModal("missing"));
  }

  const btnCancelConfirm = document.getElementById("btn-cancel-confirm-modal");
  if (btnCancelConfirm) {
    btnCancelConfirm.addEventListener("click", () => {
      if (DOM.modalConfirmVerification) DOM.modalConfirmVerification.classList.add("hidden");
    });
  }

  const btnSaveDamaged = document.getElementById("btn-save-damaged-modal");
  if (btnSaveDamaged) {
    btnSaveDamaged.addEventListener("click", () => saveRemarks("damaged"));
  }

  const btnSaveMissing = document.getElementById("btn-save-missing-modal");
  if (btnSaveMissing) {
    btnSaveMissing.addEventListener("click", () => saveRemarks("missing"));
  }

  const btnSaveConfirm = document.getElementById("btn-save-confirm-modal");
  if (btnSaveConfirm) {
    btnSaveConfirm.addEventListener("click", () => completeVerificationAndSave());
  }

  if (DOM.btnSuccessBackQueue) {
    DOM.btnSuccessBackQueue.addEventListener("click", () => {
      if (DOM.pageSuccessReturn) DOM.pageSuccessReturn.classList.add("hidden");
    });
  }
  
  const btnSuccessCloseModal = document.getElementById("btn-success-close-modal");
  if (btnSuccessCloseModal) {
    btnSuccessCloseModal.addEventListener("click", () => {
      if (DOM.pageSuccessReturn) DOM.pageSuccessReturn.classList.add("hidden");
    });
  }
  
  if (DOM.btnSuccessViewDetails) {
    DOM.btnSuccessViewDetails.addEventListener("click", () => showToast("Already showing verification receipt details."));
  }

  // Logout / Sign Out toast hook
  const logoutBtn = document.querySelector(".logout-btn");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", (e) => {
      e.preventDefault();
      showToast("Sign Out triggered. In a live system, this terminates the user session.", "error");
    });
  }

  function cancelRemarksModal(type) {
    if (state.activeExceptionTarget) {
      const { index } = state.activeExceptionTarget;
      const ret = getActiveReturn();
      if (ret) {
        const item = ret.items[index];
        if (type === "damaged") {
          item.damaged = 0;
        } else {
          item.missing = 0;
        }
        item.good = item.returnedToday - item.damaged - item.missing;
      }
    }
    if (DOM.modalMarkDamaged) DOM.modalMarkDamaged.classList.add("hidden");
    if (DOM.modalMarkMissing) DOM.modalMarkMissing.classList.add("hidden");
    state.activeExceptionTarget = null;
    renderVerifyReturnTable();
  }
}

// ==========================================================================
// 8. APP INITIALIZATION
// ==========================================================================
function initializeApp() {
  bindEvents();
  
  // Update timestamp to current local time dynamically
  const tStamp = document.getElementById("return-timestamp-val");
  if (tStamp) {
    const now = new Date();
    const options = { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' };
    tStamp.textContent = now.toLocaleDateString('en-GB', options).replace(/,/g, ' -');
  }

  // Route to correct view or tab based on query parameters
  const urlParams = new URLSearchParams(window.location.search);
  const tabParam = urlParams.get('tab');
  if (tabParam === 'component') {
    switchTab("component");
  } else if (tabParam === 'tool') {
    switchTab("tool");
  } else {
    showPage("page-dashboard");
  }
  // Mobile Sidebar Toggle
  const sidebarToggleBtn = document.getElementById('sidebarToggleBtn');
  const appSidebar = document.querySelector('.sidebar');
  if (sidebarToggleBtn && appSidebar) {
    sidebarToggleBtn.addEventListener('click', () => {
      appSidebar.classList.toggle('show');
    });
  }

  // Notifications Dropdown Toggle
  const notifBtn = document.querySelector('.notif-wrapper .header-icon-btn');
  const notifDropdown = document.querySelector('.notifications-dropdown');
  if (notifBtn && notifDropdown) {
    notifBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      notifDropdown.classList.toggle('open');
    });
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.notif-wrapper')) {
        notifDropdown.classList.remove('open');
      }
    });
  }
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initializeApp);
} else {
  initializeApp();
}




/* Auto-initialize layout on page load */
document.addEventListener('DOMContentLoaded', () => {
    renderBaseLayout('material-returns');
});

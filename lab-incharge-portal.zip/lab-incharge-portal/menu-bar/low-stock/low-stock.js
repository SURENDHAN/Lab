// Shared Front-end controller, Navigation systems, and database initialization

// Define default database structure
const DEFAULT_DATABASE = {
    currentUser: {
        username: "priya.sharma@rplms.com",
        name: "Priya Sharma",
        role: "Lab Incharge",
        avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150",
        status: "Online",
        location: "Main Lab Complex",
        timezone: "IST (UTC+5:30)",
        email: "priya.sharma@rplms.com",
        phone: "+91 98765 43210"
    },

    notifications: [
        { id: "NTF-001", icon: "📦", iconClass: "notif-icon-request", body: "TEAM-001 has submitted a new component request for Arduino Mega boards.", time: "2 min ago", unread: true },
        { id: "NTF-002", icon: "⏰", iconClass: "notif-icon-overdue", body: "TEAM-006 has 1 overdue equipment return — Raspberry Pi 4 (EQ-011).", time: "18 min ago", unread: true },
        { id: "NTF-003", icon: "🎫", iconClass: "notif-icon-ticket", body: "New damage ticket TKT-007 raised by TEAM-002 for Digital Oscilloscope.", time: "1 hr ago", unread: true },
        { id: "NTF-004", icon: "✅", iconClass: "notif-icon-info", body: "Component request REQ-012 for resistors was approved and marked fulfilled.", time: "3 hrs ago", unread: false },
        { id: "NTF-005", icon: "📋", iconClass: "notif-icon-request", body: "TEAM-005 submitted a material return for Soldering Station (EQ-012).", time: "5 hrs ago", unread: false },
        { id: "NTF-006", icon: "⚠️", iconClass: "notif-icon-overdue", body: "Inventory alert: 3D Printer (EQ-001) maintenance is due this week.", time: "Yesterday", unread: false }
    ],

    teams: [
        { id: "TEAM-001", name: "Solar Car Project", leader: "Anil Mehta", membersCount: 8, activeProjects: 2, status: "Active" },
        { id: "TEAM-002", name: "Drone Flight Tech", leader: "Vikas Pillai", membersCount: 5, activeProjects: 1, status: "Active" },
        { id: "TEAM-003", name: "Bio-Sensor Systems", leader: "Sarah Khan", membersCount: 6, activeProjects: 2, status: "Active" },
        { id: "TEAM-004", name: "Haptic Arm Development", leader: "John Doe", membersCount: 4, activeProjects: 1, status: "Suspended" },
        { id: "TEAM-005", name: "Smart Irrigation System", leader: "Rajesh Kumar", membersCount: 7, activeProjects: 2, status: "Active" },
        { id: "TEAM-006", name: "Eco Waste sorter", leader: "Deepa Nair", membersCount: 6, activeProjects: 1, status: "Active" },
        { id: "TEAM-007", name: "VTOL UAV Propulsion", leader: "Karan Johar", membersCount: 9, activeProjects: 3, status: "Active" },
        { id: "TEAM-008", name: "3D Prosthetic Hand", leader: "Aditi Rao", membersCount: 5, activeProjects: 1, status: "Active" },
        { id: "TEAM-009", name: "Autonomous AGV", leader: "Sanjay Dutt", membersCount: 6, activeProjects: 2, status: "Active" },
        { id: "TEAM-010", name: "Water Purifier IoT", leader: "Rita Sen", membersCount: 4, activeProjects: 1, status: "Active" },
        { id: "TEAM-011", name: "Robotics Arm Team", leader: "Preeti Zinta", membersCount: 7, activeProjects: 2, status: "Active" },
        { id: "TEAM-012", name: "Smart Traffic Guard", leader: "Amir Khan", membersCount: 5, activeProjects: 1, status: "Active" },
        { id: "TEAM-013", name: "Ocean Cleaner Probe", leader: "Shruti Roy", membersCount: 8, activeProjects: 2, status: "Active" },
        { id: "TEAM-014", name: "RFID Warehouse Robot", leader: "Abhay Singh", membersCount: 6, activeProjects: 1, status: "Active" },
        { id: "TEAM-015", name: "Waste Management", leader: "Nikhil Joshi", membersCount: 7, activeProjects: 1, status: "Active" },
        { id: "TEAM-016", name: "Exoskeleton Suit", leader: "Meera Iyer", membersCount: 6, activeProjects: 2, status: "Active" },
        { id: "TEAM-017", name: "Nano Filtration Unit", leader: "Arjun Verma", membersCount: 5, activeProjects: 1, status: "Active" },
        { id: "TEAM-018", name: "AI Crop Monitor", leader: "Pooja Reddy", membersCount: 7, activeProjects: 2, status: "Active" },
        { id: "TEAM-019", name: "Swarm Robotics Lab", leader: "Farhan Qureshi", membersCount: 8, activeProjects: 3, status: "Active" },
        { id: "TEAM-020", name: "EV Charging Station", leader: "Kavya Menon", membersCount: 6, activeProjects: 1, status: "Active" },
        { id: "TEAM-021", name: "Underwater ROV", leader: "Rohan Desai", membersCount: 5, activeProjects: 2, status: "Active" }
    ],
    equipment: [
        {
            sno: 1,
            eqpid: "EQP001",
            componentName: "3D Printer",
            make: "Creality",
            specification: "Ender 3 V2",
            totalCount: 3,
            componentType: "Manufacturing Equipment",
            lab: "Mechanical Lab",
            remarks: "Working Fine"
        },
        {
            sno: 2,
            eqpid: "EQP002",
            componentName: "Laser Cutter",
            make: "Ortur",
            specification: "Laser Master 2",
            totalCount: 10,
            componentType: "Manufacturing Equipment",
            lab: "Mechanical Lab",
            remarks: "Service Due"
        },
        {
            sno: 3,
            eqpid: "EQP003",
            componentName: "CNC Machine",
            make: "Genmitsu",
            specification: "3018-PRO",
            totalCount: 5,
            componentType: "Manufacturing Equipment",
            lab: "Manufacturing Lab",
            remarks: "Operational"
        }
    ],

    components: [
        {
            sno: 1,
            cid: "CID001",
            componentName: "Arduino Uno",
            make: "Arduino",
            specification: "ATmega328P",
            cost: 850,
            returnTimeline: "Project Completion",
            totalCount: 40,
            componentType: "Electronics",
            lab: "Embedded Lab",
            cupboard: "CUP-1",
            shelf1: "A1",
            count1: 20,
            shelf2: "A2",
            count2: 20,
            purpose: "Student Projects",
            comments: "Available"
        },
        {
            sno: 2,
            cid: "CID002",
            componentName: "Raspberry Pi 4",
            make: "Raspberry",
            specification: "8GB RAM",
            cost: 7000,
            returnTimeline: "Project Completion",
            totalCount: 15,
            componentType: "Embedded",
            lab: "IoT Lab",
            cupboard: "CUP-2",
            shelf1: "B1",
            count1: 8,
            shelf2: "B2",
            count2: 7,
            purpose: "Research",
            comments: "Limited"
        }
    ],

    tools: [
        {
            sno: 1,
            toolid: "T001",
            componentName: "Screw Driver Set",
            make: "Bosch",
            specification: "Professional Kit",
            cost: 2500,
            returnTimeline: "Daily",
            totalCount: 10,
            componentType: "Hand Tool",
            lab: "Mechanical Lab",
            cupboard: "CUP-5",
            shelf1: "A1",
            count1: 5,
            shelf2: "A2",
            count2: 5,
            purpose: "Maintenance",
            comments: "Good Condition"
        },
        {
            sno: 2,
            toolid: "T002",
            componentName: "Soldering Iron",
            make: "Hakko",
            specification: "60W",
            cost: 3200,
            returnTimeline: "Daily",
            totalCount: 12,
            componentType: "Electronic Tool",
            lab: "Embedded Lab",
            cupboard: "CUP-6",
            shelf1: "B1",
            count1: 6,
            shelf2: "B2",
            count2: 6,
            purpose: "PCB Assembly",
            comments: "Available"
        }
    ],

    inventory: [
        { id: "EQ-001", name: "3D Printer", type: "Equipment", manufacturer: "Creality", model: "Ender-3 V2", serial: "CRL-3DV2-2024-1125", location: "Mechanical Lab", status: "Available", dateAdded: "2025-06-15", description: "FDM 3D printer used for rapid prototyping and model making." },
        { id: "EQ-002", name: "Arduino Uno R3", type: "Component", manufacturer: "Arduino", model: "Uno Rev 3", serial: "ARD-UNO-99382", location: "Electronics Lab", status: "Available", dateAdded: "2025-01-10", description: "Microcontroller board based on the ATmega328P." },
        { id: "EQ-003", name: "Ultrasonic Sensor", type: "Component", manufacturer: "Elegoo", model: "HC-SR04", serial: "EL-HC-2092", location: "Electronics Lab", status: "Available", dateAdded: "2025-02-14", description: "Ultrasonic distance sensor module." },
        { id: "EQ-004", name: "Soil Moisture Sensor", type: "Component", manufacturer: "Generic", model: "YL-69", serial: "GEN-YL-77291", location: "Bio Lab", status: "Available", dateAdded: "2025-03-01", description: "Resistance-based soil moisture measurement probe." },
        { id: "EQ-005", name: "CNC Milling Machine", type: "Equipment", manufacturer: "SainSmart", model: "Genmitsu 3018-PRO", serial: "CNC-GEN-8827", location: "Mechanical Lab", status: "Maintenance", dateAdded: "2025-04-18", description: "Desktop CNC router for wood, acrylic, and PCB engraving." },
        { id: "EQ-006", name: "Digital Oscilloscope", type: "Equipment", manufacturer: "Rigol", model: "DS1202Z-E", serial: "RIG-DS-44932", location: "Electronics Lab", status: "Available", dateAdded: "2025-02-28", description: "200 MHz, 2-channel digital storage oscilloscope." },
        { id: "EQ-007", name: "DC Motor 12V", type: "Component", manufacturer: "Generic", model: "RS-555", serial: "GEN-DC-38291", location: "Mechanical Lab", status: "Available", dateAdded: "2025-05-02", description: "High torque 12V DC motor." },
        { id: "EQ-008", name: "16x2 LCD Display", type: "Component", manufacturer: "Generic", model: "HD44780", serial: "GEN-LCD-10293", location: "Electronics Lab", status: "Available", dateAdded: "2025-03-12", description: "Alpha-numeric display module with purple backlight." },
        { id: "EQ-009", name: "Li-ion Battery 18650", type: "Component", manufacturer: "Samsung", model: "25R 2500mAh", serial: "SAM-186-8291", location: "Electronics Lab", status: "Available", dateAdded: "2025-04-05", description: "High-discharge rechargeable lithium-ion cell." },
        { id: "EQ-010", name: "Laser Cutter", type: "Equipment", manufacturer: "Ortur", model: "Laser Master 2 Pro", serial: "ORT-LM2-88271", location: "Mechanical Lab", status: "Available", dateAdded: "2025-05-20", description: "Diode laser engraving and cutting machine." },
        { id: "EQ-011", name: "Raspberry Pi 4", type: "Component", manufacturer: "Raspberry Pi", model: "Model B 8GB", serial: "RPi4-8G-0029", location: "Electronics Lab", status: "Available", dateAdded: "2025-01-16", description: "Single board computer with 8GB RAM." },
        { id: "EQ-012", name: "Soldering Station", type: "Equipment", manufacturer: "Hakko", model: "FX-888D", serial: "HAK-FX-2023", location: "Electronics Lab", status: "Available", dateAdded: "2025-02-05", description: "Digital soldering station with temperature control." },
        { id: "EQ-013", name: "Bench Multimeter", type: "Equipment", manufacturer: "Fluke", model: "8808A", serial: "FLU-88-82910", location: "Electronics Lab", status: "Available", dateAdded: "2025-03-24", description: "5.5 digit precision benchtop digital multimeter." },
        { id: "EQ-014", name: "Bipolar NEMA 17", type: "Component", manufacturer: "Stepperonline", model: "17HS19", serial: "STEP-N17-3829", location: "Mechanical Lab", status: "Available", dateAdded: "2025-04-11", description: "High-torque stepper motor for CNC/3D Printers." },
        { id: "EQ-015", name: "LiPo Battery 11.1V", type: "Component", manufacturer: "Tattu", model: "2200mAh 3S 45C", serial: "TAT-LIPO-223", location: "Electronics Lab", status: "Available", dateAdded: "2025-05-30", description: "Lithium polymer pack for drones and RC vehicles." },
        { id: "EQ-016", name: "Hot Air Rework Station", type: "Equipment", manufacturer: "Quick", model: "861DW", serial: "QUI-861-9021", location: "Electronics Lab", status: "Available", dateAdded: "2025-02-12", description: "1000W professional lead-free hot air rework station." },
        { id: "EQ-017", name: "PIR Motion Sensor", type: "Component", manufacturer: "Adafruit", model: "HC-SR501", serial: "ADA-PIR-3329", location: "Electronics Lab", status: "Available", dateAdded: "2025-03-10", description: "Pyroelectric infrared motion detection module." },
        { id: "EQ-018", name: "Variable DC Power Supply", type: "Equipment", manufacturer: "Korado", model: "KA3005D", serial: "KOR-PWR-3829", location: "Electronics Lab", status: "Available", dateAdded: "2025-02-22", description: "Precision programmable DC linear power supply, 30V/5A." },
        { id: "EQ-019", name: "3D Scanner", type: "Equipment", manufacturer: "EinScan", model: "SE V2", serial: "EIN-SCAN-4822", location: "Mechanical Lab", status: "Available", dateAdded: "2025-06-02", description: "Desktop white light 3D scanner for modeling." },
        { id: "EQ-020", name: "Co2 Laser Tube", type: "Component", manufacturer: "RECI", model: "W2 90W", serial: "REC-CO2-9902", location: "Mechanical Lab", status: "Repairing", dateAdded: "2025-05-15", description: "CO2 glass laser tube replacement part." }
    ],

    materialRequests: [
        { id: "REQ-001", teamId: "TEAM-001", teamName: "Solar Car Project", item: "Li-ion Battery 18650", avail: 30, qty: 24, status: "Fully Issued", date: "2025-07-02", slot: "2.00-3.00" },
        { id: "REQ-002", teamId: "TEAM-005", teamName: "Smart Irrigation System", item: "Soil Moisture Sensor", avail: 30, qty: 5, status: "Pending", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-003", teamId: "TEAM-003", teamName: "Bio-Sensor Systems", item: "Arduino Uno R3", avail: 30, qty: 3, status: "Fully Issued", date: "2025-07-01", slot: "2.00-3.00" },
        { id: "REQ-004", teamId: "TEAM-011", teamName: "Robotics Arm Team", item: "DC Motor 12V", avail: 30, qty: 6, status: "Rejected", date: "2025-06-30", slot: "2.00-3.00" },
        { id: "REQ-005", teamId: "TEAM-002", teamName: "Drone Flight Tech", item: "LiPo Battery 11.1V", avail: 30, qty: 4, status: "Pending", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-006", teamId: "TEAM-008", teamName: "3D Prosthetic Hand", item: "Bipolar NEMA 17", avail: 30, qty: 10, status: "Fully Issued", date: "2025-06-28", slot: "2.00-3.00" },
        { id: "REQ-007", teamId: "TEAM-009", teamName: "Autonomous AGV", item: "Arduino Uno R3", avail: 30, qty: 2, status: "Pending", date: "2025-07-04", slot: "2.00-3.00" },
        { id: "REQ-008", teamId: "TEAM-015", teamName: "Waste Management", item: "Ultrasonic Sensor", avail: 30, qty: 4, status: "Fully Issued", date: "2025-06-27", slot: "2.00-3.00" },
        { id: "REQ-009", teamId: "TEAM-001", teamName: "Solar Car Project", item: "Raspberry Pi 4", avail: 30, qty: 2, status: "Pending", date: "2025-07-05", slot: "2.00-3.00" },
        { id: "REQ-010", teamId: "TEAM-002", teamName: "Drone Flight Tech", item: "PIR Motion Sensor", avail: 30, qty: 6, status: "Fully Issued", date: "2025-06-29", slot: "2.00-3.00" },
        { id: "REQ-011", teamId: "TEAM-003", teamName: "Bio-Sensor Systems", item: "16x2 LCD Display", avail: 30, qty: 4, status: "Pending", date: "2025-07-05", slot: "2.00-3.00" },
        { id: "REQ-012", teamId: "TEAM-004", teamName: "Haptic Arm Development", item: "Bipolar NEMA 17", avail: 30, qty: 3, status: "Rejected", date: "2025-06-26", slot: "2.00-3.00" },
        { id: "REQ-013", teamId: "TEAM-005", teamName: "Smart Irrigation System", item: "Arduino Uno R3", avail: 30, qty: 5, status: "Fully Issued", date: "2025-07-01", slot: "2.00-3.00" },
        { id: "REQ-014", teamId: "TEAM-006", teamName: "Eco Waste Sorter", item: "Raspberry Pi 4", avail: 30, qty: 1, status: "Pending", date: "2025-07-04", slot: "2.00-3.00" },
        { id: "REQ-015", teamId: "TEAM-006", teamName: "Eco Waste Sorter", item: "Ultrasonic Sensor", avail: 30, qty: 8, status: "Fully Issued", date: "2025-06-30", slot: "2.00-3.00" },
        { id: "REQ-016", teamId: "TEAM-007", teamName: "VTOL UAV Propulsion", item: "LiPo Battery 11.1V", avail: 30, qty: 6, status: "Fully Issued", date: "2025-07-02", slot: "2.00-3.00" },
        { id: "REQ-017", teamId: "TEAM-007", teamName: "VTOL UAV Propulsion", item: "DC Motor 12V", avail: 30, qty: 4, status: "Pending", date: "2025-07-05", slot: "2.00-3.00" },
        { id: "REQ-018", teamId: "TEAM-008", teamName: "3D Prosthetic Hand", item: "Li-ion Battery 18650", avail: 30, qty: 8, status: "Pending", date: "2025-07-04", slot: "2.00-3.00" },
        { id: "REQ-019", teamId: "TEAM-009", teamName: "Autonomous AGV", item: "PIR Motion Sensor", avail: 30, qty: 5, status: "Fully Issued", date: "2025-06-28", slot: "2.00-3.00" },
        { id: "REQ-020", teamId: "TEAM-010", teamName: "Water Purifier IoT", item: "Soil Moisture Sensor", avail: 30, qty: 6, status: "Fully Issued", date: "2025-07-01", slot: "2.00-3.00" },
        { id: "REQ-021", teamId: "TEAM-010", teamName: "Water Purifier IoT", item: "Arduino Uno R3", avail: 30, qty: 2, status: "Pending", date: "2025-07-05", slot: "2.00-3.00" },
        { id: "REQ-022", teamId: "TEAM-011", teamName: "Robotics Arm Team", item: "Bipolar NEMA 17", avail: 30, qty: 8, status: "Fully Issued", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-023", teamId: "TEAM-012", teamName: "Smart Traffic Guard", item: "Raspberry Pi 4", avail: 30, qty: 2, status: "Fully Issued", date: "2025-06-29", slot: "2.00-3.00" },
        { id: "REQ-024", teamId: "TEAM-012", teamName: "Smart Traffic Guard", item: "PIR Motion Sensor", avail: 30, qty: 10, status: "Pending", date: "2025-07-04", slot: "2.00-3.00" },
        { id: "REQ-025", teamId: "TEAM-013", teamName: "Ocean Cleaner Probe", item: "DC Motor 12V", avail: 30, qty: 3, status: "Fully Issued", date: "2025-07-02", slot: "2.00-3.00" },
        { id: "REQ-026", teamId: "TEAM-013", teamName: "Ocean Cleaner Probe", item: "Li-ion Battery 18650", avail: 30, qty: 12, status: "Pending", date: "2025-07-05", slot: "2.00-3.00" },
        { id: "REQ-027", teamId: "TEAM-014", teamName: "RFID Warehouse Robot", item: "Arduino Uno R3", avail: 30, qty: 4, status: "Fully Issued", date: "2025-06-30", slot: "2.00-3.00" },
        { id: "REQ-028", teamId: "TEAM-014", teamName: "RFID Warehouse Robot", item: "16x2 LCD Display", avail: 30, qty: 6, status: "Rejected", date: "2025-06-27", slot: "2.00-3.00" },
        { id: "REQ-029", teamId: "TEAM-015", teamName: "Waste Management", item: "Soil Moisture Sensor", avail: 30, qty: 5, status: "Pending", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-030", teamId: "TEAM-004", teamName: "Haptic Arm Development", item: "16x2 LCD Display", avail: 30, qty: 2, status: "Pending", date: "2025-07-05", slot: "2.00-3.00" },
        { id: "REQ-031", teamId: "TEAM-016", teamName: "Exoskeleton Suit", item: "Bipolar NEMA 17", avail: 30, qty: 6, status: "Fully Issued", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-032", teamId: "TEAM-016", teamName: "Exoskeleton Suit", item: "Arduino Uno R3", avail: 30, qty: 3, status: "Pending", date: "2025-07-06", slot: "2.00-3.00" },
        { id: "REQ-033", teamId: "TEAM-017", teamName: "Nano Filtration Unit", item: "Soil Moisture Sensor", avail: 30, qty: 8, status: "Fully Issued", date: "2025-07-02", slot: "2.00-3.00" },
        { id: "REQ-034", teamId: "TEAM-017", teamName: "Nano Filtration Unit", item: "DC Motor 12V", avail: 30, qty: 2, status: "Pending", date: "2025-07-06", slot: "2.00-3.00" },
        { id: "REQ-035", teamId: "TEAM-018", teamName: "AI Crop Monitor", item: "Raspberry Pi 4", avail: 30, qty: 3, status: "Fully Issued", date: "2025-07-04", slot: "2.00-3.00" },
        { id: "REQ-036", teamId: "TEAM-018", teamName: "AI Crop Monitor", item: "PIR Motion Sensor", avail: 30, qty: 6, status: "Pending", date: "2025-07-06", slot: "2.00-3.00" },
        { id: "REQ-037", teamId: "TEAM-019", teamName: "Swarm Robotics Lab", item: "Arduino Uno R3", avail: 30, qty: 8, status: "Fully Issued", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-038", teamId: "TEAM-019", teamName: "Swarm Robotics Lab", item: "LiPo Battery 11.1V", avail: 30, qty: 5, status: "Pending", date: "2025-07-06", slot: "2.00-3.00" },
        { id: "REQ-039", teamId: "TEAM-020", teamName: "EV Charging Station", item: "Li-ion Battery 18650", avail: 30, qty: 20, status: "Fully Issued", date: "2025-07-04", slot: "2.00-3.00" },
        { id: "REQ-040", teamId: "TEAM-020", teamName: "EV Charging Station", item: "Variable DC Power Supply", avail: 30, qty: 1, status: "Pending", date: "2025-07-06", slot: "2.00-3.00" },
        { id: "REQ-041", teamId: "TEAM-021", teamName: "Underwater ROV", item: "DC Motor 12V", avail: 30, qty: 4, status: "Fully Issued", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-042", teamId: "TEAM-021", teamName: "Underwater ROV", item: "Raspberry Pi 4", avail: 30, qty: 2, status: "Pending", date: "2025-07-06", slot: "2.00-3.00" }
    ],

    materialReturns: (function () {
        // Helper: offset days from today
        function daysFromToday(n) {
            const d = new Date();
            d.setDate(d.getDate() + n);
            return d.toISOString().slice(0, 10);
        }
        return [
            { id: "RET-001", teamId: "TEAM-001", teamName: "Solar Car Project", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(-4) },
            { id: "RET-002", teamId: "TEAM-003", teamName: "Bio-Sensor Systems", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(-10) },
            { id: "RET-003", teamId: "TEAM-005", teamName: "Smart Irrigation System", item: "Soldering Station", qty: 2, status: "Pending", date: daysFromToday(10) },
            { id: "RET-004", teamId: "TEAM-011", teamName: "Robotics Arm Team", item: "Variable DC Power Supply", qty: 1, status: "Pending", date: daysFromToday(7) },
            { id: "RET-005", teamId: "TEAM-002", teamName: "Drone Flight Tech", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(-3) },
            { id: "RET-006", teamId: "TEAM-013", teamName: "Ocean Cleaner Probe", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(9) },
            { id: "RET-007", teamId: "TEAM-001", teamName: "Solar Car Project", item: "Laser Cutter", qty: 1, status: "Pending", date: daysFromToday(8) },
            { id: "RET-008", teamId: "TEAM-001", teamName: "Solar Car Project", item: "3D Printer", qty: 1, status: "Pending", date: daysFromToday(-7) },
            { id: "RET-009", teamId: "TEAM-002", teamName: "Drone Flight Tech", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(6) },
            { id: "RET-010", teamId: "TEAM-002", teamName: "Drone Flight Tech", item: "Hot Air Rework Station", qty: 1, status: "Pending", date: daysFromToday(-11) },
            { id: "RET-011", teamId: "TEAM-003", teamName: "Bio-Sensor Systems", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(5) },
            { id: "RET-012", teamId: "TEAM-003", teamName: "Bio-Sensor Systems", item: "Variable DC Power Supply", qty: 1, status: "Pending", date: daysFromToday(-2) },
            { id: "RET-013", teamId: "TEAM-004", teamName: "Haptic Arm Development", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(-13) },
            { id: "RET-014", teamId: "TEAM-005", teamName: "Smart Irrigation System", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(-1) },
            { id: "RET-015", teamId: "TEAM-005", teamName: "Smart Irrigation System", item: "3D Printer", qty: 1, status: "Pending", date: daysFromToday(11) },
            { id: "RET-016", teamId: "TEAM-006", teamName: "Eco Waste Sorter", item: "Laser Cutter", qty: 1, status: "Pending", date: daysFromToday(4) },
            { id: "RET-017", teamId: "TEAM-006", teamName: "Eco Waste Sorter", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(-9) },
            { id: "RET-018", teamId: "TEAM-007", teamName: "VTOL UAV Propulsion", item: "CNC Milling Machine", qty: 1, status: "Pending", date: daysFromToday(13) },
            { id: "RET-019", teamId: "TEAM-007", teamName: "VTOL UAV Propulsion", item: "3D Scanner", qty: 1, status: "Pending", date: daysFromToday(-5) },
            { id: "RET-020", teamId: "TEAM-007", teamName: "VTOL UAV Propulsion", item: "Hot Air Rework Station", qty: 1, status: "Pending", date: daysFromToday(-12) },
            { id: "RET-021", teamId: "TEAM-008", teamName: "3D Prosthetic Hand", item: "3D Printer", qty: 1, status: "Pending", date: daysFromToday(5) },
            { id: "RET-022", teamId: "TEAM-008", teamName: "3D Prosthetic Hand", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(-4) },
            { id: "RET-023", teamId: "TEAM-009", teamName: "Autonomous AGV", item: "Laser Cutter", qty: 1, status: "Pending", date: daysFromToday(7) },
            { id: "RET-024", teamId: "TEAM-009", teamName: "Autonomous AGV", item: "Variable DC Power Supply", qty: 1, status: "Pending", date: daysFromToday(-8) },
            { id: "RET-025", teamId: "TEAM-010", teamName: "Water Purifier IoT", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(6) },
            { id: "RET-026", teamId: "TEAM-010", teamName: "Water Purifier IoT", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(-3) },
            { id: "RET-027", teamId: "TEAM-011", teamName: "Robotics Arm Team", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(-6) },
            { id: "RET-028", teamId: "TEAM-012", teamName: "Smart Traffic Guard", item: "3D Printer", qty: 1, status: "Pending", date: daysFromToday(9) },
            { id: "RET-029", teamId: "TEAM-012", teamName: "Smart Traffic Guard", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(-2) },
            { id: "RET-030", teamId: "TEAM-013", teamName: "Ocean Cleaner Probe", item: "Laser Cutter", qty: 1, status: "Pending", date: daysFromToday(-5) },
            { id: "RET-031", teamId: "TEAM-014", teamName: "RFID Warehouse Robot", item: "Variable DC Power Supply", qty: 1, status: "Pending", date: daysFromToday(8) },
            { id: "RET-032", teamId: "TEAM-014", teamName: "RFID Warehouse Robot", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(-1) },
            { id: "RET-033", teamId: "TEAM-015", teamName: "Waste Management", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(10) },
            { id: "RET-034", teamId: "TEAM-015", teamName: "Waste Management", item: "Hot Air Rework Station", qty: 1, status: "Pending", date: daysFromToday(-10) },
            { id: "RET-035", teamId: "TEAM-016", teamName: "Exoskeleton Suit", item: "Variable DC Power Supply", qty: 1, status: "Pending", date: daysFromToday(11) },
            { id: "RET-036", teamId: "TEAM-016", teamName: "Exoskeleton Suit", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(-7) },
            { id: "RET-037", teamId: "TEAM-017", teamName: "Nano Filtration Unit", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(9) },
            { id: "RET-038", teamId: "TEAM-017", teamName: "Nano Filtration Unit", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(-2) },
            { id: "RET-039", teamId: "TEAM-018", teamName: "AI Crop Monitor", item: "3D Printer", qty: 1, status: "Pending", date: daysFromToday(12) },
            { id: "RET-040", teamId: "TEAM-018", teamName: "AI Crop Monitor", item: "Laser Cutter", qty: 1, status: "Pending", date: daysFromToday(-8) },
            { id: "RET-041", teamId: "TEAM-019", teamName: "Swarm Robotics Lab", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(10) },
            { id: "RET-042", teamId: "TEAM-019", teamName: "Swarm Robotics Lab", item: "Hot Air Rework Station", qty: 1, status: "Pending", date: daysFromToday(-9) },
            { id: "RET-043", teamId: "TEAM-020", teamName: "EV Charging Station", item: "Variable DC Power Supply", qty: 1, status: "Pending", date: daysFromToday(8) },
            { id: "RET-044", teamId: "TEAM-020", teamName: "EV Charging Station", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(-1) },
            { id: "RET-045", teamId: "TEAM-021", teamName: "Underwater ROV", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(11) },
            { id: "RET-046", teamId: "TEAM-021", teamName: "Underwater ROV", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(-6) }
        ];
    })(),

    tickets: [
        {
            id: "TKT-001", type: "Procurement", assignedTo: "Administrator", subject: "Low Stock Components", priority: "High", date: "04 Jul 2025", status: "Open", assigneeRole: "System Admin", raisedBy: "Priya Sharma", time: "10:15 AM", reason: "Multiple inventory components have reached the minimum stock level. Procurement approval is requested to maintain smooth lab operations.", items: [
                { name: "Arduino Uno R3", qty: "05", min: "10" },
                { name: "Soil Moisture Sensor", qty: "02", min: "05" },
                { name: "16x2 LCD Display", qty: "03", min: "05" },
                { name: "DC Motor 12V", qty: "01", min: "03" },
                { name: "Li-ion Battery 18650", qty: "04", min: "10" }
            ], adminResponse: ""
        },

        { id: "TKT-002", type: "Damage", assignedTo: "TEAM-005", subject: "Arduino Uno R3 Damaged", priority: "Medium", date: "03 Jul 2025", status: "Pending", teamName: "Smart Irrigation System", equipmentName: "Arduino Uno R3", raisedBy: "Lab Incharge", time: "02:15 PM", damageDescription: "USB port is physically damaged during project testing.", fineAmount: "500", dueDate: "10 Jul 2025", remarks: "Fine to be paid by the team before next material issue.", teamResponse: "", lastUpdated: "03 Jul 2025, 02:15 PM" },

        { id: "TKT-003", type: "Damage", assignedTo: "TEAM-011", subject: "DC Motor 12V Broken", priority: "High", date: "02 Jul 2025", status: "In Progress", teamName: "Robotics Arm", equipmentName: "DC Motor 12V", raisedBy: "Lab Incharge", time: "11:30 AM", damageDescription: "Motor coil burned out due to overloading.", fineAmount: "300", dueDate: "09 Jul 2025", remarks: "Replacement motor cost.", teamResponse: "We have received the notice. Discussing with team leader.", lastUpdated: "02 Jul 2025, 03:00 PM" },

        {
            id: "TKT-004", type: "Procurement", assignedTo: "Administrator", subject: "Request for Additional Sensors", priority: "Medium", date: "01 Jul 2025", status: "In Progress", assigneeRole: "System Admin", raisedBy: "Priya Sharma", time: "09:45 AM", reason: "Additional sensors needed for upcoming workshop.", items: [
                { name: "Ultrasonic Sensor", qty: "15", min: "05" },
                { name: "PIR Motion Sensor", qty: "20", min: "05" }
            ], adminResponse: "Quotation requested from vendor."
        },

        { id: "TKT-005", type: "Damage", assignedTo: "TEAM-008", subject: "16x2 LCD Display Cracked", priority: "Low", date: "30 Jun 2025", status: "Resolved", teamName: "3D Prosthetic Hand", equipmentName: "16x2 LCD Display", raisedBy: "Lab Incharge", time: "04:00 PM", damageDescription: "Screen cracked during mechanical assembly mounting.", fineAmount: "150", dueDate: "07 Jul 2025", remarks: "Standard replacement fine.", teamResponse: "Fine paid. Receipt number #88271.", lastUpdated: "01 Jul 2025, 10:20 AM" },

        {
            id: "TKT-006", type: "Procurement", assignedTo: "Administrator", subject: "Low Stock - Batteries", priority: "High", date: "29 Jun 2025", status: "Resolved", assigneeRole: "System Admin", raisedBy: "Priya Sharma", time: "11:20 AM", reason: "Li-ion Battery stock critically low.", items: [
                { name: "Li-ion Battery 18650", qty: "02", min: "10" }
            ], adminResponse: "PO Issued. Delivery expected by next week."
        },

        { id: "TKT-007", type: "Damage", assignedTo: "TEAM-015", subject: "Soil Moisture Sensor Damaged", priority: "Medium", date: "28 Jun 2025", status: "Open", teamName: "Waste Management", equipmentName: "Soil Moisture Sensor", raisedBy: "Lab Incharge", time: "10:00 AM", damageDescription: "Corrosion due to extended water immersion test without waterproofing cover.", fineAmount: "200", dueDate: "05 Jul 2025", remarks: "Cost of sensor replacement.", teamResponse: "", lastUpdated: "28 Jun 2025, 10:00 AM" }
    ],
    bookedEquipment: [],
    equipmentRequests: [
        {
            teamId: "TEAM-001",
            teamName: "Solar Car Project",
            requests: [
                { id: "ER-101", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "10:00 AM - 12:00 PM", status: "Rejected", rejectionReason: "Sent for Repair" },
                { id: "ER-102", equipmentType: "Manufacturing", equipmentId: "EQ-005", equipmentName: "CNC Milling Machine", timeSlot: "02:00 PM - 04:00 PM", status: "Approved", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-002",
            teamName: "Drone Flight Tech",
            requests: [
                { id: "ER-201", equipmentType: "Manufacturing", equipmentId: "EQ-010", equipmentName: "Laser Cutter", timeSlot: "11:00 AM - 01:00 PM", status: "Rejected", rejectionReason: "It is damaged and it will available from tomorrow" }
            ]
        },
        {
            teamId: "TEAM-003",
            teamName: "Bio-Sensor Systems",
            requests: [
                { id: "ER-301", equipmentType: "Electronics", equipmentId: "EQ-006", equipmentName: "Digital Oscilloscope", timeSlot: "09:00 AM - 11:00 AM", status: "Approved", rejectionReason: "" },
                { id: "ER-302", equipmentType: "Electronics", equipmentId: "EQ-018", equipmentName: "Variable DC Power Supply", timeSlot: "01:00 PM - 03:00 PM", status: "Approved", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-005",
            teamName: "Smart Irrigation System",
            requests: [
                { id: "ER-501", equipmentType: "Electronics", equipmentId: "EQ-012", equipmentName: "Soldering Station", timeSlot: "02:00 PM - 04:00 PM", status: "Rejected", rejectionReason: "Sent for Repair" }
            ]
        },
        {
            teamId: "TEAM-004",
            teamName: "Haptic Arm Development",
            requests: [
                { id: "ER-401", equipmentType: "Electronics", equipmentId: "EQ-013", equipmentName: "Bench Multimeter", timeSlot: "03:00 PM - 05:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-402", equipmentType: "Manufacturing", equipmentId: "EQ-016", equipmentName: "Hot Air Rework Station", timeSlot: "10:00 AM - 12:00 PM", status: "Pending", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-006",
            teamName: "Eco Waste Sorter",
            requests: [
                { id: "ER-601", equipmentType: "Manufacturing", equipmentId: "EQ-010", equipmentName: "Laser Cutter", timeSlot: "02:00 PM - 04:00 PM", status: "Rejected", rejectionReason: "Slot not available, try next week" },
                { id: "ER-602", equipmentType: "Electronics", equipmentId: "EQ-011", equipmentName: "Raspberry Pi 4", timeSlot: "11:00 AM - 01:00 PM", status: "Approved", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-007",
            teamName: "VTOL UAV Propulsion",
            requests: [
                { id: "ER-701", equipmentType: "Manufacturing", equipmentId: "EQ-005", equipmentName: "CNC Milling Machine", timeSlot: "09:00 AM - 12:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-702", equipmentType: "Manufacturing", equipmentId: "EQ-019", equipmentName: "3D Scanner", timeSlot: "01:00 PM - 02:00 PM", status: "Pending", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-008",
            teamName: "3D Prosthetic Hand",
            requests: [
                { id: "ER-801", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "01:00 PM - 03:00 PM", status: "Rejected", rejectionReason: "Maintenance scheduled on this date" }
            ]
        },
        {
            teamId: "TEAM-009",
            teamName: "Autonomous AGV",
            requests: [
                { id: "ER-901", equipmentType: "Manufacturing", equipmentId: "EQ-010", equipmentName: "Laser Cutter", timeSlot: "10:00 AM - 12:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-902", equipmentType: "Electronics", equipmentId: "EQ-006", equipmentName: "Digital Oscilloscope", timeSlot: "02:00 PM - 04:00 PM", status: "Pending", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-010",
            teamName: "Water Purifier IoT",
            requests: [
                { id: "ER-1001", equipmentType: "Electronics", equipmentId: "EQ-012", equipmentName: "Soldering Station", timeSlot: "09:00 AM - 11:00 AM", status: "Approved", rejectionReason: "" },
                { id: "ER-1002", equipmentType: "Electronics", equipmentId: "EQ-013", equipmentName: "Bench Multimeter", timeSlot: "11:00 AM - 12:00 PM", status: "Rejected", rejectionReason: "Currently in use by another team" }
            ]
        },
        {
            teamId: "TEAM-011",
            teamName: "Robotics Arm Team",
            requests: [
                { id: "ER-1101", equipmentType: "Electronics", equipmentId: "EQ-018", equipmentName: "Variable DC Power Supply", timeSlot: "02:00 PM - 04:00 PM", status: "Pending", rejectionReason: "" },
                { id: "ER-1102", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "03:00 PM - 05:00 PM", status: "Approved", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-012",
            teamName: "Smart Traffic Guard",
            requests: [
                { id: "ER-1201", equipmentType: "Electronics", equipmentId: "EQ-011", equipmentName: "Raspberry Pi 4", timeSlot: "10:00 AM - 12:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-1202", equipmentType: "Electronics", equipmentId: "EQ-017", equipmentName: "PIR Motion Sensor", timeSlot: "01:00 PM - 03:00 PM", status: "Rejected", rejectionReason: "Out of stock" }
            ]
        },
        {
            teamId: "TEAM-013",
            teamName: "Ocean Cleaner Probe",
            requests: [
                { id: "ER-1301", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "09:00 AM - 11:00 AM", status: "Approved", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-014",
            teamName: "RFID Warehouse Robot",
            requests: [
                { id: "ER-1401", equipmentType: "Electronics", equipmentId: "EQ-013", equipmentName: "Bench Multimeter", timeSlot: "11:00 AM - 12:00 PM", status: "Rejected", rejectionReason: "Sent for calibration" },
                { id: "ER-1402", equipmentType: "Electronics", equipmentId: "EQ-006", equipmentName: "Digital Oscilloscope", timeSlot: "02:00 PM - 04:00 PM", status: "Pending", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-015",
            teamName: "Waste Management",
            requests: [
                { id: "ER-1501", equipmentType: "Electronics", equipmentId: "EQ-012", equipmentName: "Soldering Station", timeSlot: "01:00 PM - 03:00 PM", status: "Approved", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-016",
            teamName: "Exoskeleton Suit",
            requests: [
                { id: "ER-1601", equipmentType: "Electronics", equipmentId: "EQ-018", equipmentName: "Variable DC Power Supply", timeSlot: "09:00 AM - 11:00 AM", status: "Approved", rejectionReason: "" },
                { id: "ER-1602", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "01:00 PM - 03:00 PM", status: "Rejected", rejectionReason: "Nozzle replacement in progress" }
            ]
        },
        {
            teamId: "TEAM-017",
            teamName: "Nano Filtration Unit",
            requests: [
                { id: "ER-1701", equipmentType: "Electronics", equipmentId: "EQ-013", equipmentName: "Bench Multimeter", timeSlot: "10:00 AM - 12:00 PM", status: "Pending", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-018",
            teamName: "AI Crop Monitor",
            requests: [
                { id: "ER-1801", equipmentType: "Electronics", equipmentId: "EQ-011", equipmentName: "Raspberry Pi 4", timeSlot: "02:00 PM - 04:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-1802", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "09:00 AM - 11:00 AM", status: "Rejected", rejectionReason: "Filament depleted" }
            ]
        },
        {
            teamId: "TEAM-019",
            teamName: "Swarm Robotics Lab",
            requests: [
                { id: "ER-1901", equipmentType: "Electronics", equipmentId: "EQ-012", equipmentName: "Soldering Station", timeSlot: "10:00 AM - 12:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-1902", equipmentType: "Manufacturing", equipmentId: "EQ-010", equipmentName: "Laser Cutter", timeSlot: "02:00 PM - 04:00 PM", status: "Pending", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-020",
            teamName: "EV Charging Station",
            requests: [
                { id: "ER-2001", equipmentType: "Electronics", equipmentId: "EQ-018", equipmentName: "Variable DC Power Supply", timeSlot: "09:00 AM - 11:00 AM", status: "Rejected", rejectionReason: "Overbooked for this time slot" }
            ]
        },
        {
            teamId: "TEAM-021",
            teamName: "Underwater ROV",
            requests: [
                { id: "ER-2101", equipmentType: "Electronics", equipmentId: "EQ-006", equipmentName: "Digital Oscilloscope", timeSlot: "01:00 PM - 03:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-2102", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "10:00 AM - 12:00 PM", status: "Pending", rejectionReason: "" }
            ]
        }
    ]
};

// Generate dummy data up to 32 items for tickets
function fillRemainingTickets() {
    const types = ["Procurement", "Damage"];
    const priorities = ["High", "Medium", "Low"];
    const statuses = ["Open", "Pending", "In Progress", "Resolved"];
    const asignees = [
        { name: "TEAM-006", desc: "Eco Waste sorter" },
        { name: "TEAM-001", desc: "Solar Car Project" },
        { name: "Administrator", desc: "System Admin" },
        { name: "TEAM-002", desc: "Drone Flight Tech" },
        { name: "TEAM-003", desc: "Bio-Sensor Systems" }
    ];
    const equipment = ["Arduino Uno R3", "3D Printer", "CNC Milling Machine", "Digital Oscilloscope", "Raspberry Pi 4"];
    const dates = ["27 Jun 2025", "26 Jun 2025", "25 Jun 2025", "24 Jun 2025", "23 Jun 2025", "22 Jun 2025", "21 Jun 2025", "20 Jun 2025"];

    let baseId = 8;
    while (DEFAULT_DATABASE.tickets.length < 32) {
        const type = types[Math.floor(Math.random() * types.length)];
        const priority = priorities[Math.floor(Math.random() * priorities.length)];
        const status = statuses[Math.floor(Math.random() * statuses.length)];
        const date = dates[Math.floor(Math.random() * dates.length)];
        const id = `TKT-${String(baseId).padStart(3, '0')}`;
        baseId++;

        if (type === "Procurement") {
            DEFAULT_DATABASE.tickets.push({
                id,
                type,
                assignedTo: "Administrator",
                subject: `Refocking ${equipment[Math.floor(Math.random() * equipment.length)]}s`,
                priority,
                date,
                status,
                assigneeRole: "System Admin",
                raisedBy: "Priya Sharma",
                time: "02:00 PM",
                reason: "Stock replenishment request.",
                items: [
                    { name: "Item Replacements", qty: "02", min: "05" }
                ],
                adminResponse: status === "Resolved" ? "Request processed." : ""
            });
        } else {
            const teamIdx = Math.floor(Math.random() * asignees.length);
            DEFAULT_DATABASE.tickets.push({
                id,
                type,
                assignedTo: asignees[teamIdx].name,
                subject: `${equipment[Math.floor(Math.random() * equipment.length)]} Damaged`,
                priority,
                date,
                status,
                teamName: asignees[teamIdx].desc,
                equipmentName: equipment[Math.floor(Math.random() * equipment.length)],
                raisedBy: "Lab Incharge",
                time: "11:00 AM",
                damageDescription: "Physical structural damage observed post usage.",
                fineAmount: "450",
                dueDate: "12 Jul 2025",
                remarks: "Please deposit the replacement fine.",
                teamResponse: status === "Resolved" ? "Fine cleared." : "",
                lastUpdated: `${date}, 11:30 AM`
            });
        }
    }
}
fillRemainingTickets();


// Initialize LocalStorage database
const DB_VERSION = 12;
let MEMORY_DB = null;

function initLocalStorageDB() {
    try {
        const storedVersion = parseInt(localStorage.getItem("rplms_db_version") || "0");
        if (storedVersion < DB_VERSION) {
            localStorage.setItem("rplms_db", JSON.stringify(DEFAULT_DATABASE));
            localStorage.setItem("rplms_db_version", String(DB_VERSION));
        }
    } catch (e) {
        console.warn("LocalStorage access blocked. Falling back to in-memory database.", e);
        MEMORY_DB = DEFAULT_DATABASE;
    }
}
initLocalStorageDB();

// Read DB helper
function getDB() {
    try {
        return JSON.parse(localStorage.getItem("rplms_db")) || DEFAULT_DATABASE;
    } catch (e) {
        if (!MEMORY_DB) MEMORY_DB = DEFAULT_DATABASE;
        return MEMORY_DB;
    }
}

// Write DB helper
function setDB(db) {
    try {
        localStorage.setItem("rplms_db", JSON.stringify(db));
    } catch (e) {
        MEMORY_DB = db;
    }
}

// // Check logged in state (Bypassed to keep user auto-logged in)
// function checkAuth() {
//     const isLoggedIn = localStorage.getItem("rplms_logged_in");
//     const currentPage = window.location.pathname.split("/").pop();
//     if (!isLoggedIn && currentPage !== "login.html" && currentPage !== "") {
//         window.location.href = "login.html";
//     } else if (isLoggedIn && currentPage === "login.html") {
//         window.location.href = "index.html";
//     }
// }
// checkAuth();

// --- Sidebar & Layout Builder ---

function renderBaseLayout(activeMenu) {
    const db = getDB();
    const user = db.currentUser;

    // Calculate user initials dynamically
    const nameWithoutTitle = user.name.replace(/^(Dr\.|Mr\.|Ms\.|Mrs\.)\s+/i, '');
    const nameParts = nameWithoutTitle.split(/\s+/).filter(Boolean);
    let userInitials = 'F';
    if (nameParts.length > 0) {
        userInitials = nameParts.map(p => p[0]).join('').substring(0, 2).toUpperCase();
    }

    // Update avatar and username if elements exist
    const avatarEl = document.querySelector(".header-avatar");
    if (avatarEl) avatarEl.textContent = userInitials;

    const nameEl = document.querySelector(".header-user-name");
    if (nameEl) nameEl.textContent = user.name;

    // Set active class on sidebar items
    const navItems = document.querySelectorAll(".nav-links .nav-item");
    navItems.forEach(item => {
        item.classList.remove("active");
    });
    
    // Find the item corresponding to activeMenu
    const activeItem = document.querySelector(`.nav-links a[href*="/${activeMenu}/"], .nav-links a[href="${activeMenu}.html"], .nav-links a[href*="${activeMenu}"]`);
    if (activeItem) {
        const parentLi = activeItem.closest(".nav-item");
        if (parentLi) parentLi.classList.add("active");
    }

    // Attach logout click listener
    const logoutBtn = document.querySelector("#logoutBtn");
    if (logoutBtn) {
        logoutBtn.addEventListener("click", () => {
            localStorage.removeItem("rplms_logged_in");
        });
    }

    // Notifications Dropdown dynamic build
    function buildNotificationsDropdown() {
        const dbNow = getDB();
        const notifs = dbNow.notifications || [];
        const unreadCount = notifs.filter(n => n.unread).length;

        // Update the bell badge
        const badge = document.querySelector(".notif-wrapper .icon-badge");
        if (badge) {
            badge.textContent = unreadCount;
            badge.style.display = unreadCount > 0 ? "" : "none";
        }

        const dropdown = document.querySelector(".notifications-dropdown");
        if (!dropdown) return;

        const listHtml = notifs.length === 0
            ? `<div class="notif-empty"><span class="notif-empty-icon">🔔</span>No notifications yet</div>`
            : notifs.map(n => `
                <div class="notif-item ${n.unread ? 'unread' : ''}" data-notif-id="${n.id}">
                    <div class="notif-icon-wrapper ${n.iconClass}">${n.icon}</div>
                    <div class="notif-content">
                        <div class="notif-body">${n.body}</div>
                        <div class="notif-time">${n.time}</div>
                    </div>
                </div>`).join("");

        dropdown.innerHTML = `
            <div class="notif-header">
                <div class="notif-header-title">
                    Notifications
                    ${unreadCount > 0 ? `<span class="notif-count-badge">${unreadCount}</span>` : ''}
                </div>
                ${unreadCount > 0 ? '<button class="notif-header-action" id="markAllReadBtn">Mark all read</button>' : ''}
            </div>
            <div class="notif-list">${listHtml}</div>
        `;

        // Mark all read
        const markAllBtn = dropdown.querySelector("#markAllReadBtn");
        if (markAllBtn) {
            markAllBtn.addEventListener("click", (e) => {
                e.stopPropagation();
                const db2 = getDB();
                db2.notifications.forEach(n => n.unread = false);
                setDB(db2);
                buildNotificationsDropdown();
            });
        }

        // Mark individual as read on click
        dropdown.querySelectorAll(".notif-item").forEach(el => {
            el.addEventListener("click", () => {
                const id = el.dataset.notifId;
                const db2 = getDB();
                const notif = db2.notifications.find(n => n.id === id);
                if (notif) { notif.unread = false; setDB(db2); }
                buildNotificationsDropdown();
            });
        });
    }

    // Toggle dropdown open/close
    const bellBtn = document.querySelector(".notif-wrapper .header-icon-btn");
    const notifDropdown = document.querySelector(".notifications-dropdown");
    if (bellBtn && notifDropdown) {
        // Remove old listeners to avoid stacking
        const newBellBtn = bellBtn.cloneNode(true);
        bellBtn.parentNode.replaceChild(newBellBtn, bellBtn);

        newBellBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            const isOpen = notifDropdown.classList.toggle("open");
            if (isOpen) buildNotificationsDropdown();
        });

        // Close on outside click
        document.addEventListener("click", (e) => {
            if (!e.target.closest(".notif-wrapper")) {
                notifDropdown.classList.remove("open");
            }
        });

        // Initialize badge on page load
        buildNotificationsDropdown();
    }
}

// Custom Toast notification loader
function showToast(message, type = "success") {
    let container = document.querySelector(".toast-container");
    if (!container) {
        container = document.createElement("div");
        container.className = "toast-container";
        document.body.appendChild(container);
    }

    const toast = document.createElement("div");
    toast.className = `toast ${type}`;

    let icon = "&#10003;";
    if (type === "error") icon = "&#9888;";
    if (type === "warn") icon = "&#9757;";
    if (type === "info") icon = "&#8505;";

    toast.innerHTML = `
    <div class="toast-content">
      <span class="toast-icon">${icon}</span>
      <span class="toast-message">${message}</span>
    </div>
    <button class="toast-close">&times;</button>
  `;

    container.appendChild(toast);

    // Trigger show layout
    setTimeout(() => toast.classList.add("show"), 10);

    // Auto remove after 4 seconds
    const autoClose = setTimeout(() => {
        toast.classList.remove("show");
        setTimeout(() => toast.remove(), 300);
    }, 4000);

    // Close button trigger
    toast.querySelector(".toast-close").addEventListener("click", () => {
        clearTimeout(autoClose);
        toast.classList.remove("show");
        setTimeout(() => toast.remove(), 300);
    });
}

// Confirmation Popups Setup
function createConfirmationModal(title, bodyText, confirmCallback, confirmText = "Confirm", isDanger = false) {
    // Check if confirmation modal backdrop already exists
    let backdrop = document.getElementById("confirmModalBackdrop");
    if (!backdrop) {
        backdrop = document.createElement("div");
        backdrop.id = "confirmModalBackdrop";
        backdrop.className = "modal-backdrop";
        document.body.appendChild(backdrop);
    }

    backdrop.innerHTML = `
    <div class="modal-container" style="max-width: 420px;">
      <div class="modal-header" style="padding: 20px 24px;">
        <div class="modal-header-left">
          <div class="circle-icon-wrapper ${isDanger ? 'red-alert' : 'blue-info'}" style="width: 40px; height: 40px; font-size: 16px;">
            ${isDanger ? '&#9888;' : '&#8505;'}
          </div>
          <div class="card-header-text">
            <span class="card-title">${title}</span>
          </div>
        </div>
        <button class="modal-close-btn" id="confirmModalClose">&times;</button>
      </div>
      <div class="modal-body" style="padding: 20px 24px; font-size: 13px; color: var(--text-secondary); line-height: 1.5;">
        ${bodyText}
      </div>
      <div class="modal-footer" style="padding: 12px 24px;">
        <button class="btn btn-secondary" id="confirmCancelBtn" style="padding: 8px 16px; font-size: 12px;">Cancel</button>
        <button class="btn ${isDanger ? 'btn-danger' : 'btn-primary'}" id="confirmConfirmBtn" style="padding: 8px 16px; font-size: 12px;">${confirmText}</button>
      </div>
    </div>
  `;

    // Escape key handler
    const escapeHandler = function (e) {
        if (e.key === "Escape") {
            closeConfirm();
        }
    };

    function openConfirm() {
        backdrop.classList.add("show");
        document.addEventListener("keydown", escapeHandler);
    }

    function closeConfirm() {
        backdrop.classList.remove("show");
        document.removeEventListener("keydown", escapeHandler);
        setTimeout(() => backdrop.remove(), 300);
    }

    // Bind cancel actions
    backdrop.querySelector("#confirmModalClose").addEventListener("click", closeConfirm);
    backdrop.querySelector("#confirmCancelBtn").addEventListener("click", closeConfirm);
    backdrop.addEventListener("click", (e) => {
        if (e.target === backdrop) closeConfirm();
    });

    // Bind confirm action
    backdrop.querySelector("#confirmConfirmBtn").addEventListener("click", () => {
        confirmCallback();
        closeConfirm();
    });

    openConfirm();
}



// Debounce search inputs helper
function debounce(func, delay = 300) {
    let timer;
    return function (...args) {
        clearTimeout(timer);
        timer = setTimeout(() => {
            func.apply(this, args);
        }, delay);
    };
}

// Escape inputs to prevent XSS
function escapeHtml(str) {
    if (typeof str !== 'string') return str;
    return str.replace(/[&<>"']/g, function (match) {
        switch (match) {
            case '&': return '&amp;';
            case '<': return '&lt;';
            case '>': return '&gt;';
            case '"': return '&quot;';
            case "'": return '&#39;';
        }
    });
}

// Basic SQL injection keyword check
function hasSqlInfectionRisk(str) {
    if (typeof str !== 'string') return false;
    const sqlRegex = /\b(select|insert|update|delete|drop|alter|union|where|exec|truncate)\b/gi;
    return sqlRegex.test(str);
}
//common.js

/* === js/low-stock.js === */
/**
 * Prototrack Dashboard - Interactive Client-Side Engine
 * Handles State, Searching, Filtering, Multi-Selection, 
 * Dynamic KPI Updating, Page Switches, and CSV Exporting.
 * Restored sidebar and navbar element bindings, and removed help card toggles.
 */

// ==========================================================================
// 1. INITIAL MOCK DATASET
// ==========================================================================
const initialLowStockItems = [
  { id: "CMP-001", name: "Arduino Uno R3", category: "Component", specification: "Original", availableQty: 2, minQty: 10, unit: "Nos" },
  { id: "CMP-003", name: "Servo Motor SG90", category: "Component", specification: "Tower Pro", availableQty: 1, minQty: 10, unit: "Nos" },
  { id: "CMP-007", name: "Breadboard 830 Points", category: "Component", specification: "Solderless", availableQty: 3, minQty: 10, unit: "Nos" },
  { id: "TOL-015", name: "Wire Cutter", category: "Tool", specification: "6 inch", availableQty: 1, minQty: 5, unit: "Nos" },
  { id: "TOL-022", name: "Screwdriver Set", category: "Tool", specification: "Phillips & Flat", availableQty: 2, minQty: 5, unit: "Set" },
  { id: "TOL-030", name: "Heat Gun", category: "Tool", specification: "2000W", availableQty: 0, minQty: 2, unit: "Nos" },
  { id: "CMP-002", name: "Raspberry Pi 4", category: "Component", specification: "4GB RAM", availableQty: 1, minQty: 5, unit: "Nos" },
  { id: "CMP-004", name: "Ultrasonic Sensor", category: "Component", specification: "HC-SR04", availableQty: 3, minQty: 15, unit: "Nos" },
  { id: "TOL-016", name: "Soldering Iron", category: "Tool", specification: "60W Adjustable", availableQty: 1, minQty: 4, unit: "Nos" },
  { id: "TOL-025", name: "Digital Multimeter", category: "Tool", specification: "Auto-ranging", availableQty: 2, minQty: 6, unit: "Nos" },
  { id: "CMP-009", name: "Lithium Ion Battery", category: "Component", specification: "3.7V 2200mAh", availableQty: 4, minQty: 20, unit: "Nos" },
  { id: "TOL-008", name: "Mini Rotary Tool", category: "Tool", specification: "12V Cordless", availableQty: 0, minQty: 3, unit: "Set" }
];

// ==========================================================================
// 2. STATE OBJECT
// ==========================================================================
const state = {
  items: JSON.parse(JSON.stringify(initialLowStockItems)), // Deep clone data
  selectedIds: new Set(["CMP-001", "CMP-003", "CMP-007", "TOL-015", "TOL-022", "TOL-030"]), // Default selected items
  requiredQuantities: {}, // Map of id -> quantity
  filters: {
    search: "",
    category: "All",
    sortBy: "lowest-qty"
  },
  currentPage: "page-low-stock-list",
  lastActivePage: "page-low-stock-list" // Tracks which page to go back to from dummy views
};

// ==========================================================================
// 3. DOM ELEMENTS (LAZY GETTERS TO PREVENT NULL QUERY CRASHES)
// ==========================================================================
const DOM = {
  // Sidebar & Navigation
  get sidebarMenuItems() { return document.querySelectorAll(".menu-item"); },
  get dropdownChevron() { return document.querySelector(".dropdown-chevron"); },
  get returnsDropdownParent() { return document.querySelector(".menu-item-dropdown"); },
  get logoutBtn() { return document.querySelector(".logout-btn"); },
  get pageTitle() { return document.getElementById("navbar-page-title"); },
  
  // Page Views
  get pageLowStockList() { return document.getElementById("page-low-stock-list"); },
  get pageReviewQuantities() { return document.getElementById("page-review-quantities"); },
  get pageDummy() { return document.getElementById("page-dummy"); },
  get dummyTitle() { return document.getElementById("dummy-title"); },
  get dummyDesc() { return document.getElementById("dummy-desc"); },
  get btnBackToActive() { return document.getElementById("btn-back-to-active"); },
  
  // KPI Metrics (Low Stock)
  get kpiTotalItems() { return document.getElementById("kpi-total-items"); },
  get kpiComponentsCount() { return document.getElementById("kpi-components-count"); },
  get kpiToolsCount() { return document.getElementById("kpi-tools-count"); },
  get kpiUpdateTime() { return document.getElementById("kpi-update-time"); },
  get timestampVal() { return document.getElementById("timestamp-val"); },
  get refreshDataBtn() { return document.getElementById("refresh-data-btn"); },
  
  // Filters Panel (Low Stock)
  get searchInput() { return document.getElementById("search-input"); },
  get categorySelect() { return document.getElementById("category-select"); },
  get sortSelect() { return document.getElementById("sort-select"); },
  get btnClearFilters() { return document.getElementById("btn-clear-filters"); },
  
  // Tables (Low Stock)
  get tableLowStockBody() { return document.getElementById("low-stock-table-body"); },
  get tableReviewBody() { return document.getElementById("review-table-body"); },
  get selectAllCheckbox() { return document.getElementById("select-all-checkbox"); },
  get tableEmptyState() { return document.getElementById("table-empty-state"); },
  
  // Footer Selection Bar Page 1 (Low Stock)
  get selectedCountBadge() { return document.getElementById("selected-count-badge"); },
  get visibleCountBadge() { return document.getElementById("visible-count-badge"); },
  get btnClearSelection() { return document.getElementById("btn-clear-selection"); },
  get btnNextStep() { return document.getElementById("btn-next-step"); },
  
  // Header / Footer Buttons Page 2 (Low Stock)
  get reviewSelectedCountBadge() { return document.getElementById("review-selected-count-badge"); },
  get btnBackHeader() { return document.getElementById("btn-back-header"); },
  get btnBackFooter() { return document.getElementById("btn-back-footer"); },
  get btnClearAllReview() { return document.getElementById("btn-clear-all-review"); },
  get btnDownloadReport() { return document.getElementById("btn-download-report"); },
  
  // Toast notifications
  get toastContainer() { return document.getElementById("toast-container"); }
};

// ==========================================================================
// 4. BUSINESS LOGIC & STATE MUTATORS
// ==========================================================================

/**
 * Initialize default required quantities for items based on available and minimum stock
 */
function initRequiredQuantities() {
  state.items.forEach(item => {
    if (!state.requiredQuantities[item.id]) {
      if (item.id === "CMP-001") state.requiredQuantities[item.id] = 20;
      else if (item.id === "CMP-003") state.requiredQuantities[item.id] = 15;
      else if (item.id === "CMP-007") state.requiredQuantities[item.id] = 10;
      else if (item.id === "TOL-015") state.requiredQuantities[item.id] = 8;
      else if (item.id === "TOL-022") state.requiredQuantities[item.id] = 8;
      else if (item.id === "TOL-030") state.requiredQuantities[item.id] = 3;
      else {
        const diff = item.minQty - item.availableQty;
        state.requiredQuantities[item.id] = Math.max(item.minQty, diff * 2);
      }
    }
  });
}

/**
 * Retrieve items matching the current filters and sort parameters
 */
function getFilteredItems() {
  let filtered = state.items.filter(item => {
    // 1. Search Query Match
    const matchesSearch = item.name.toLowerCase().includes(state.filters.search.toLowerCase()) || 
                          item.id.toLowerCase().includes(state.filters.search.toLowerCase());
    
    // 2. Category Match
    const matchesCategory = state.filters.category === "All" || item.category === state.filters.category;
    
    return matchesSearch && matchesCategory;
  });

  // 3. Sorting
  filtered.sort((a, b) => {
    switch (state.filters.sortBy) {
      case "lowest-qty":
        return a.availableQty - b.availableQty;
      case "highest-qty":
        return b.availableQty - a.availableQty;
      case "asset-id":
        return a.id.localeCompare(b.id);
      case "asset-name":
        return a.name.localeCompare(b.name);
      default:
        return 0;
    }
  });

  return filtered;
}

/**
 * Update the top metrics blocks (KPIs) dynamically
 */
function updateKPICards() {
  const total = state.items.length;
  const components = state.items.filter(i => i.category === "Component").length;
  const tools = state.items.filter(i => i.category === "Tool").length;
  
  if (DOM.kpiTotalItems) DOM.kpiTotalItems.textContent = total;
  if (DOM.kpiComponentsCount) DOM.kpiComponentsCount.textContent = components;
  if (DOM.kpiToolsCount) DOM.kpiToolsCount.textContent = tools;
}

/**
 * Toggle Page switches and Sidebar highlights
 */
function showPage(pageId) {
  state.currentPage = pageId;
  
  // Hide all views
  if (DOM.pageLowStockList) DOM.pageLowStockList.classList.add("hidden");
  if (DOM.pageReviewQuantities) DOM.pageReviewQuantities.classList.add("hidden");
  if (DOM.pageDummy) DOM.pageDummy.classList.add("hidden");
  
  // Reset active state for sidebar links
  if (DOM.sidebarMenuItems) {
    DOM.sidebarMenuItems.forEach(item => item.classList.remove("active"));
  }
  
  if (pageId === "page-low-stock-list") {
    if (DOM.pageLowStockList) DOM.pageLowStockList.classList.remove("hidden");
    if (DOM.pageTitle) DOM.pageTitle.textContent = "Low Stock Alerts";
    
    // Highlight "Low Stock Alerts" in sidebar
    const lowStockMenu = document.querySelector('[data-target="low-stock"]');
    if (lowStockMenu) lowStockMenu.classList.add("active");
    
    state.lastActivePage = pageId;
    renderLowStockTable();
    updateSelectionState();
  } 
  else if (pageId === "page-review-quantities") {
    if (DOM.pageReviewQuantities) DOM.pageReviewQuantities.classList.remove("hidden");
    if (DOM.pageTitle) DOM.pageTitle.textContent = "Low Stock Alerts";
    
    // Highlight "Low Stock Alerts" in sidebar
    const lowStockMenu = document.querySelector('[data-target="low-stock"]');
    if (lowStockMenu) lowStockMenu.classList.add("active");
    
    state.lastActivePage = pageId;
    renderReviewTable();
  } 
  else if (pageId.startsWith("dummy-")) {
    const sectionName = pageId.replace("dummy-", "");
    if (DOM.pageDummy) DOM.pageDummy.classList.remove("hidden");
    
    // Customize dummy text
    const titleFormatted = sectionName.split("-").map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(" ");
    if (DOM.pageTitle) DOM.pageTitle.textContent = titleFormatted;
    if (DOM.dummyTitle) DOM.dummyTitle.textContent = `${titleFormatted} Module`;
    if (DOM.dummyDesc) DOM.dummyDesc.textContent = `The "${titleFormatted}" lab module is currently under layout design for the Prototrack Lab Portal. Switch to the active "Low Stock Alerts" screen to interact with the mock workspace.`;
    
    // Highlight corresponding sidebar link
    const targetMenu = document.querySelector(`[data-target="${sectionName}"]`);
    if (targetMenu) targetMenu.classList.add("active");
  }
}

/**
 * Update selection elements (badge values, button disabled toggles)
 */
function updateSelectionState() {
  const selectedCount = state.selectedIds.size;
  if (DOM.selectedCountBadge) DOM.selectedCountBadge.textContent = selectedCount;
  if (DOM.reviewSelectedCountBadge) DOM.reviewSelectedCountBadge.textContent = selectedCount;
  
  const filtered = getFilteredItems();
  const visibleSelected = filtered.filter(item => state.selectedIds.has(item.id)).length;
  
  if (DOM.selectAllCheckbox) {
    if (filtered.length > 0 && visibleSelected === filtered.length) {
      DOM.selectAllCheckbox.checked = true;
      DOM.selectAllCheckbox.indeterminate = false;
    } else if (visibleSelected > 0) {
      DOM.selectAllCheckbox.checked = false;
      DOM.selectAllCheckbox.indeterminate = true;
    } else {
      DOM.selectAllCheckbox.checked = false;
      DOM.selectAllCheckbox.indeterminate = false;
    }
  }

  if (DOM.btnClearSelection) DOM.btnClearSelection.disabled = selectedCount === 0;
  if (DOM.btnNextStep) DOM.btnNextStep.disabled = selectedCount === 0;
}

// ==========================================================================
// 5. TOAST NOTIFICATION UTILITY
// ==========================================================================
function showToast(message, type = "success") {
  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  
  let iconSVG = "";
  if (type === "success") {
    iconSVG = `<svg class="toast-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>`;
  } else {
    iconSVG = `<svg class="toast-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;
  }

  toast.innerHTML = `
    ${iconSVG}
    <span>${message}</span>
  `;
  
  if (DOM.toastContainer) DOM.toastContainer.appendChild(toast);
  
  setTimeout(() => toast.classList.add("show"), 10);
  
  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => {
      toast.remove();
    }, 300);
  }, 3500);
}

// ==========================================================================
// 6. RENDER DATA TABLES
// ==========================================================================

/**
 * Populate main table (Page 1)
 */
function renderLowStockTable() {
  const filtered = getFilteredItems();
  if (!DOM.tableLowStockBody) return;
  DOM.tableLowStockBody.innerHTML = "";
  if (DOM.visibleCountBadge) DOM.visibleCountBadge.textContent = `${filtered.length} items visible`;

  if (filtered.length === 0) {
    if (DOM.tableEmptyState) DOM.tableEmptyState.classList.remove("hidden");
    return;
  }
  if (DOM.tableEmptyState) DOM.tableEmptyState.classList.add("hidden");

  filtered.forEach(item => {
    const isSelected = state.selectedIds.has(item.id);
    const tr = document.createElement("tr");
    if (isSelected) tr.classList.add("row-selected");

    tr.innerHTML = `
      <td class="col-checkbox text-center">
        <label class="custom-checkbox">
          <input type="checkbox" data-id="${item.id}" ${isSelected ? "checked" : ""}>
          <span class="checkmark"></span>
        </label>
      </td>
      <td class="font-semibold text-secondary">${item.id}</td>
      <td class="font-medium">${item.name}</td>
      <td>${item.category}</td>
      <td>${item.specification}</td>
      <td class="text-right"><span class="qty-badge-red">${item.availableQty}</span></td>
      <td class="text-right font-medium">${item.minQty}</td>
      <td class="text-right text-muted">-</td>
      <td class="text-secondary">${item.unit}</td>
    `;

    // Row Click Trigger
    tr.addEventListener("click", (e) => {
      if (e.target.closest("label")) return;
      const checkbox = tr.querySelector('input[type="checkbox"]');
      checkbox.checked = !checkbox.checked;
      handleRowSelectChange(item.id, checkbox.checked, tr);
    });

    // Checkbox State Change Trigger
    const checkbox = tr.querySelector('input[type="checkbox"]');
    checkbox.addEventListener("change", (e) => {
      handleRowSelectChange(item.id, e.target.checked, tr);
    });

    DOM.tableLowStockBody.appendChild(tr);
  });
}

/**
 * Selection Mutator
 */
function handleRowSelectChange(id, isChecked, trElement) {
  if (isChecked) {
    state.selectedIds.add(id);
    trElement.classList.add("row-selected");
  } else {
    state.selectedIds.delete(id);
    trElement.classList.remove("row-selected");
  }
  updateSelectionState();
}

/**
 * Populate review table (Page 2)
 */
function renderReviewTable() {
  DOM.tableReviewBody.innerHTML = "";
  const selectedItems = state.items.filter(item => state.selectedIds.has(item.id));
  
  if (selectedItems.length === 0) {
    showToast("No items selected. Returning to list.", "error");
    showPage("page-low-stock-list");
    return;
  }

  selectedItems.forEach(item => {
    const tr = document.createElement("tr");
    const reqQty = state.requiredQuantities[item.id] || item.minQty;

    tr.innerHTML = `
      <td class="col-remove text-center">
        <button class="btn-row-action btn-row-action-danger" data-id="${item.id}" aria-label="Remove item">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
        </button>
      </td>
      <td class="font-semibold text-secondary">${item.id}</td>
      <td class="font-medium">${item.name}</td>
      <td>${item.category}</td>
      <td>${item.specification}</td>
      <td class="text-right"><span class="qty-badge-red">${item.availableQty}</span></td>
      <td class="text-right font-medium">${item.minQty}</td>
      <td class="text-center col-required-qty">
        <div class="qty-input-wrapper">
          <button class="qty-spin-btn btn-minus" data-id="${item.id}">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="5" y1="12" x2="19" y2="12"/></svg>
          </button>
          <input type="number" value="${reqQty}" min="1" max="999" data-id="${item.id}">
          <button class="qty-spin-btn btn-plus" data-id="${item.id}">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          </button>
        </div>
      </td>
      <td class="text-secondary">${item.unit}</td>
    `;

    // 1. Remove Item listener
    tr.querySelector(".btn-row-action-danger").addEventListener("click", () => {
      state.selectedIds.delete(item.id);
      showToast(`Removed "${item.name}" from report selection.`);
      
      renderReviewTable();
      updateSelectionState();
    });

    // 2. Quantity input value sync
    const input = tr.querySelector('input[type="number"]');
    
    input.addEventListener("change", (e) => {
      let value = parseInt(e.target.value);
      if (isNaN(value) || value < 1) value = 1;
      if (value > 999) value = 999;
      
      e.target.value = value;
      state.requiredQuantities[item.id] = value;
    });

    // Plus & Minus spinner controls
    tr.querySelector(".btn-minus").addEventListener("click", () => {
      let currentVal = parseInt(input.value);
      if (currentVal > 1) {
        input.value = currentVal - 1;
        state.requiredQuantities[item.id] = currentVal - 1;
      }
    });

    tr.querySelector(".btn-plus").addEventListener("click", () => {
      let currentVal = parseInt(input.value);
      if (currentVal < 999) {
        input.value = currentVal + 1;
        state.requiredQuantities[item.id] = currentVal + 1;
      }
    });

    DOM.tableReviewBody.appendChild(tr);
  });

  DOM.reviewSelectedCountBadge.textContent = selectedItems.length;
}

// ==========================================================================
// 7. CSV EXPORTER (REPORTS COMPILER)
// ==========================================================================
function downloadReport() {
  const selectedItems = state.items.filter(item => state.selectedIds.has(item.id));
  
  if (selectedItems.length === 0) {
    showToast("No items selected to compile report.", "error");
    return;
  }

  let csvContent = "Asset ID,Asset Name,Category,Specification / Model,Available Quantity,Minimum Quantity,Required Quantity,Unit\n";
  
  selectedItems.forEach(item => {
    const required = state.requiredQuantities[item.id] || item.minQty;
    const nameEscaped = item.name.replace(/"/g, '""');
    const specEscaped = item.specification.replace(/"/g, '""');
    
    csvContent += `"${item.id}","${nameEscaped}","${item.category}","${specEscaped}",${item.availableQty},${item.minQty},${required},"${item.unit}"\n`;
  });

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", `Prototrack_Low_Stock_Report_${new Date().toISOString().slice(0,10)}.csv`);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  showToast(`Successfully downloaded Low Stock Report (${selectedItems.length} items included)!`);
}

function bindEvents() {
  
  // 1. Sidebar switches
  if (DOM.sidebarMenuItems) {
    DOM.sidebarMenuItems.forEach(item => {
      item.addEventListener("click", (e) => {
        const target = item.getAttribute("data-target");
        
        if (target === "returns-status") {
          e.preventDefault();
          if (DOM.returnsDropdownParent) {
            DOM.returnsDropdownParent.classList.toggle("expanded");
          }
        } else if (target === "low-stock") {
          e.preventDefault();
          showPage("page-low-stock-list");
        } else {
          e.preventDefault();
          showPage(`dummy-${target}`);
        }
      });
    });
  }

  // Back to Active portal button from dummy panels
  if (DOM.btnBackToActive) {
    DOM.btnBackToActive.addEventListener("click", () => {
      showPage("page-low-stock-list");
    });
  }

  // Logout banner simulated trigger
  if (DOM.logoutBtn) {
    DOM.logoutBtn.addEventListener("click", (e) => {
      e.preventDefault();
      showToast("Logout triggered. In a live system, this terminates the user session.", "error");
    });
  }

  // 2. Select All Checkbox logic
  if (DOM.selectAllCheckbox) {
    DOM.selectAllCheckbox.addEventListener("change", (e) => {
      const filtered = getFilteredItems();
      filtered.forEach(item => {
        if (e.target.checked) {
          state.selectedIds.add(item.id);
        } else {
          state.selectedIds.delete(item.id);
        }
      });
      
      renderLowStockTable();
      updateSelectionState();
    });
  }

  // 3. KPI / Header Refresh Action
  if (DOM.refreshDataBtn) {
    DOM.refreshDataBtn.addEventListener("click", () => {
      DOM.refreshDataBtn.classList.add("spinning");
      showToast("Fetching live storage inventory data...");
      
      setTimeout(() => {
        const now = new Date();
        const options = { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' };
        const newTimestamp = now.toLocaleDateString('en-GB', options).replace(/,/g, ' -') + " (Updated)";
        
        if (DOM.timestampVal) DOM.timestampVal.textContent = newTimestamp;
        if (DOM.kpiUpdateTime) DOM.kpiUpdateTime.textContent = newTimestamp;
        
        state.items.forEach(item => {
          if (item.availableQty < item.minQty && Math.random() > 0.7) {
            item.availableQty = Math.max(0, item.availableQty + (Math.random() > 0.5 ? 1 : -1));
          }
        });

        if (DOM.refreshDataBtn) DOM.refreshDataBtn.classList.remove("spinning");
        initRequiredQuantities();
        renderLowStockTable();
        updateKPICards();
        updateSelectionState();
        
        showToast("Inventory database synced successfully.");
      }, 1200);
    });
  }

  // 4. Filters & Searches (Real-time Auto-filtering)
  const applyFilters = () => {
    state.filters.search = DOM.searchInput ? DOM.searchInput.value : "";
    state.filters.category = DOM.categorySelect ? DOM.categorySelect.value : "All";
    state.filters.sortBy = DOM.sortSelect ? DOM.sortSelect.value : "lowest-qty";
    
    renderLowStockTable();
    updateSelectionState();
  };

  if (DOM.searchInput) DOM.searchInput.addEventListener("input", applyFilters);
  if (DOM.categorySelect) DOM.categorySelect.addEventListener("change", applyFilters);
  if (DOM.sortSelect) DOM.sortSelect.addEventListener("change", applyFilters);

  if (DOM.btnClearFilters) {
    DOM.btnClearFilters.addEventListener("click", () => {
      if (DOM.searchInput) DOM.searchInput.value = "";
      if (DOM.categorySelect) DOM.categorySelect.value = "All";
      if (DOM.sortSelect) DOM.sortSelect.value = "lowest-qty";
      
      state.filters.search = "";
      state.filters.category = "All";
      state.filters.sortBy = "lowest-qty";
      
      renderLowStockTable();
      updateSelectionState();
      showToast("Filters cleared.");
    });
  }

  // 5. Page 1 Footer Buttons
  if (DOM.btnClearSelection) {
    DOM.btnClearSelection.addEventListener("click", () => {
      state.selectedIds.clear();
      renderLowStockTable();
      updateSelectionState();
      showToast("Selection cleared.");
    });
  }

  if (DOM.btnNextStep) {
    DOM.btnNextStep.addEventListener("click", () => {
      showPage("page-review-quantities");
    });
  }

  // 6. Page 2 Navigation Links & Actions
  if (DOM.btnBackHeader) DOM.btnBackHeader.addEventListener("click", () => showPage("page-low-stock-list"));
  if (DOM.btnBackFooter) DOM.btnBackFooter.addEventListener("click", () => showPage("page-low-stock-list"));

  if (DOM.btnClearAllReview) {
    DOM.btnClearAllReview.addEventListener("click", () => {
      state.selectedIds.clear();
      showToast("Cleared report list. Returning to low stock view.");
      showPage("page-low-stock-list");
    });
  }

  if (DOM.btnDownloadReport) {
    DOM.btnDownloadReport.addEventListener("click", () => {
      downloadReport();
    });
  }
}

// ==========================================================================
// 9. APP INITIALIZATION ENTRYPOINT
// ==========================================================================
function initializeApp() {
  initRequiredQuantities();
  updateKPICards();
  bindEvents();
  
  // Set initial page
  showPage("page-low-stock-list");
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initializeApp);
} else {
  initializeApp();
}




/* Auto-initialize layout on page load */
document.addEventListener('DOMContentLoaded', () => {
    renderBaseLayout('low-stock');
});

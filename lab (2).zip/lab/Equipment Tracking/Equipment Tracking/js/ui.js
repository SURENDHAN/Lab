'use strict';

/**
 * ui.js – Reusable UI utility functions.
 * All functions accept parameters; none reference page-specific DOM IDs.
 * Exported as the `UI` namespace object.
 */

const UI = (function () {

  /* ────────────────────────────────────────────────────────── *
   * SVG ICON LIBRARY
   * All icons are Lucide-compatible line-icon SVGs.
   * ────────────────────────────────────────────────────────── */

  const ICONS = {
    // Stats
    layers:      `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.75" stroke="currentColor"><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>`,
    box:         `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.75" stroke="currentColor"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/></svg>`,
    'check-circle': `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.75" stroke="currentColor"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>`,
    activity:    `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.75" stroke="currentColor"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>`,
    tool:        `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.75" stroke="currentColor"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>`,
    clock:       `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.75" stroke="currentColor"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`,
    // Equipment type icons
    'printer-3d': `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.75" stroke="currentColor"><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><path d="M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6"/><rect x="6" y="14" width="12" height="8" rx="1"/></svg>`,
    laser:        `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.75" stroke="currentColor"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>`,
    cnc:          `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.75" stroke="currentColor"><circle cx="12" cy="12" r="3"/><path d="M6.3 6.3a8.1 8.1 0 0 0 0 11.4m11.4 0a8.1 8.1 0 0 0 0-11.4M3.5 3.5a14 14 0 0 0 0 17m17-17a14 14 0 0 1 0 17"/></svg>`,
    milling:      `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.75" stroke="currentColor"><rect x="4" y="4" width="16" height="16" rx="2"/><rect x="9" y="9" width="6" height="6" rx="1"/><path d="M15 2v2M9 2v2M15 20v2M9 20v2M2 15h2M2 9h2M20 15h2M20 9h2"/></svg>`,
    vinyl:        `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.75" stroke="currentColor"><circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/><line x1="12" y1="2" x2="12" y2="9"/></svg>`,
    solder:       `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.75" stroke="currentColor"><path d="M9 3H5a2 2 0 0 0-2 2v4m6-6h10a2 2 0 0 1 2 2v4M9 3v18m0 0h10a2 2 0 0 0 2-2V9M9 21H5a2 2 0 0 1-2-2V9m0 0h18"/></svg>`,
    bench:        `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.75" stroke="currentColor"><rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/></svg>`,
    vacuum:       `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.75" stroke="currentColor"><path d="M3 9h18v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9Z"/><path d="m3 9 2.45-4.9A2 2 0 0 1 7.24 3h9.52a2 2 0 0 1 1.8 1.1L21 9"/><line x1="12" y1="3" x2="12" y2="9"/></svg>`,
    // Navigation / UI
    chevronLeft:  `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><polyline points="15 18 9 12 15 6"/></svg>`,
    chevronRight: `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><polyline points="9 18 15 12 9 6"/></svg>`,
    arrowLeft:    `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/></svg>`,
    eye:          `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>`,
    edit:         `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>`,
    trash:        `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/></svg>`,
    plus:         `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>`,
    x:            `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
    calendar:     `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.75" stroke="currentColor"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>`,
    check:        `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2.5" stroke="currentColor"><polyline points="20 6 9 17 4 12"/></svg>`,
    info:         `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`,
    wrench:       `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.75" stroke="currentColor"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>`,
    'book-open':  `<svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.75" stroke="currentColor"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>`,
  };

  /** Return SVG markup string for a named icon. Returns '' if not found. */
  function icon(name) {
    return ICONS[name] || '';
  }

  /* ────────────────────────────────────────────────────────── *
   * BADGE
   * ────────────────────────────────────────────────────────── */

  const BADGE_MAP = {
    available:     { cls: 'badge--available',    label: 'Available' },
    'in-use':      { cls: 'badge--in-use',        label: 'In Use' },
    maintenance:   { cls: 'badge--maintenance',   label: 'Maintenance' },
    pending:       { cls: 'badge--pending',       label: 'Pending Booking' },
    confirmed:     { cls: 'badge--confirmed',     label: 'Confirmed' },
    cancelled:     { cls: 'badge--cancelled',     label: 'Cancelled' },
    'in-progress': { cls: 'badge--in-use',        label: 'In Progress' },
    scheduled:     { cls: 'badge--pending',       label: 'Scheduled' },
    completed:     { cls: 'badge--confirmed',     label: 'Completed' },
  };

  /** Return a badge HTML string for a given status key. */
  function badge(status) {
    const cfg = BADGE_MAP[status] || { cls: '', label: status };
    return `<span class="badge ${cfg.cls}">${cfg.label}</span>`;
  }

  /* ────────────────────────────────────────────────────────── *
   * STATS
   * ────────────────────────────────────────────────────────── */

  const STAT_CONFIG = [
    { key: 'totalTypes',      cls: 'stat-card--types',       iconKey: 'layers',       label: 'Total Types' },
    { key: 'totalMachines',   cls: 'stat-card--machines',    iconKey: 'box',          label: 'Total Machines' },
    { key: 'available',       cls: 'stat-card--available',   iconKey: 'check-circle', label: 'Available' },
    { key: 'inUse',           cls: 'stat-card--in-use',      iconKey: 'activity',     label: 'In Use' },
    { key: 'maintenance',     cls: 'stat-card--maintenance', iconKey: 'tool',         label: 'Maintenance' },
    { key: 'pendingBookings', cls: 'stat-card--pending',     iconKey: 'clock',        label: 'Pending Booking' },
  ];

  /** Aggregate stats from a categories array. */
  function computeStats(categories) {
    return categories.reduce(
      (acc, c) => {
        acc.totalMachines   += c.total;
        acc.available       += c.available;
        acc.inUse           += c.inUse;
        acc.maintenance     += c.maintenance;
        acc.pendingBookings += c.pendingBookings;
        return acc;
      },
      { totalTypes: categories.length, totalMachines: 0, available: 0, inUse: 0, maintenance: 0, pendingBookings: 0 }
    );
  }

  /** Render stat cards into a container element using STAT_CONFIG. */
  function renderStats(container, stats) {
    container.innerHTML = STAT_CONFIG.map(cfg => `
      <article class="card stat-card ${cfg.cls}" aria-label="${cfg.label}: ${stats[cfg.key]}">
        <div class="stat-card__icon" aria-hidden="true">${icon(cfg.iconKey)}</div>
        <div class="stat-card__body">
          <p class="stat-card__value">${stats[cfg.key]}</p>
          <p class="stat-card__label">${cfg.label}</p>
        </div>
      </article>
    `).join('');
  }

  /** Render a 4-item stat strip from a custom config array. */
  function renderCustomStats(container, items) {
    container.innerHTML = items.map(item => `
      <article class="card stat-card ${item.cls}" aria-label="${item.label}: ${item.value}">
        <div class="stat-card__icon" aria-hidden="true">${icon(item.iconKey)}</div>
        <div class="stat-card__body">
          <p class="stat-card__value">${item.value}</p>
          <p class="stat-card__label">${item.label}</p>
        </div>
      </article>
    `).join('');
  }

  /* ────────────────────────────────────────────────────────── *
   * PAGINATION
   * ────────────────────────────────────────────────────────── */

  /**
   * Render pagination controls into a wrapper element.
   * @param {HTMLElement} wrapper
   * @param {number}   current    – 1-indexed current page
   * @param {number}   total      – total item count
   * @param {number}   perPage    – items per page
   * @param {Function} onPageChange – callback(pageNumber)
   */
  function renderPagination(wrapper, current, total, perPage, onPageChange) {
    const totalPages = Math.max(1, Math.ceil(total / perPage));
    const start      = total === 0 ? 0 : (current - 1) * perPage + 1;
    const end        = Math.min(current * perPage, total);

    const pageButtons = Array.from({ length: totalPages }, (_, i) => i + 1)
      .map(p => {
        const active = p === current ? ' pagination__btn--active' : '';
        const current_ = p === current ? ' aria-current="page"' : '';
        return `<button class="pagination__btn${active}" data-page="${p}" aria-label="Page ${p}"${current_}>${p}</button>`;
      })
      .join('');

    wrapper.innerHTML = `
      <span class="pagination__info">Showing ${start}–${end} of ${total}</span>
      <nav class="pagination" aria-label="Table pagination">
        <button class="pagination__btn" data-page="${current - 1}"${current === 1 ? ' disabled' : ''} aria-label="Previous page">${icon('chevronLeft')}</button>
        ${pageButtons}
        <button class="pagination__btn" data-page="${current + 1}"${current === totalPages ? ' disabled' : ''} aria-label="Next page">${icon('chevronRight')}</button>
      </nav>
    `;

    wrapper.querySelectorAll('.pagination__btn:not([disabled])').forEach(btn => {
      btn.addEventListener('click', () => onPageChange(Number(btn.dataset.page)));
    });
  }

  /* ────────────────────────────────────────────────────────── *
   * DRAWER
   * ────────────────────────────────────────────────────────── */

  /**
   * Open a drawer + its overlay. Traps the close button.
   * @param {HTMLElement} drawer
   * @param {HTMLElement} overlay
   */
  function openDrawer(drawer, overlay) {
    drawer.classList.add('is-open');
    overlay.classList.add('is-open');
    document.body.style.overflow = 'hidden';
  }

  /**
   * Close a drawer + its overlay.
   * @param {HTMLElement} drawer
   * @param {HTMLElement} overlay
   */
  function closeDrawer(drawer, overlay) {
    drawer.classList.remove('is-open');
    overlay.classList.remove('is-open');
    document.body.style.overflow = '';
  }

  /* ────────────────────────────────────────────────────────── *
   * EXPORT
   * ────────────────────────────────────────────────────────── */

  return {
    icon,
    badge,
    computeStats,
    renderStats,
    renderCustomStats,
    renderPagination,
    openDrawer,
    closeDrawer,
  };
})();

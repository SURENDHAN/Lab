'use strict';

/**
 * data.js – Mock data for Equipment Tracking Dashboard.
 * All data is static – no network requests. Organised by domain.
 * Each domain is a plain array or object of plain JS objects.
 */

const DATA = (function () {

  /* ── Equipment Categories ──────────────────────────────── */
  // total must equal available + inUse + maintenance

  const categories = [
    {
      id: 'cat-01', icon: 'printer-3d',
      name: '3D Printers',       type: 'FDM / Resin',
      locations: ['Lab A1', 'Lab A2', 'Lab B1', 'Lab B2'],
      total: 5,  available: 3, inUse: 1, maintenance: 1, pendingBookings: 2,
    },
    {
      id: 'cat-02', icon: 'laser',
      name: 'Laser Cutters',     type: 'CO₂ Laser',
      locations: ['Lab C1', 'Lab C2'],
      total: 3,  available: 2, inUse: 1, maintenance: 0, pendingBookings: 0,
    },
    {
      id: 'cat-03', icon: 'cnc',
      name: 'CNC Machines',      type: 'Milling / Routing',
      locations: ['Lab D1'],
      total: 2,  available: 1, inUse: 1, maintenance: 0, pendingBookings: 3,
    },
    {
      id: 'cat-04', icon: 'milling',
      name: 'Milling Machines',  type: 'PCB Prototype',
      locations: ['Lab D2'],
      total: 2,  available: 1, inUse: 0, maintenance: 1, pendingBookings: 0,
    },
    {
      id: 'cat-05', icon: 'vinyl',
      name: 'Vinyl Cutters',     type: 'Adhesive / Sticker',
      locations: ['Lab E1'],
      total: 2,  available: 2, inUse: 0, maintenance: 0, pendingBookings: 2,
    },
    {
      id: 'cat-06', icon: 'solder',
      name: 'Soldering Stations', type: 'Electronic Assembly',
      locations: ['Lab F1'],
      total: 2,  available: 1, inUse: 1, maintenance: 0, pendingBookings: 0,
    },
    {
      id: 'cat-07', icon: 'bench',
      name: 'Electronics Bench', type: 'Test & Measurement',
      locations: ['Lab F2'],
      total: 1,  available: 1, inUse: 0, maintenance: 0, pendingBookings: 2,
    },
    {
      id: 'cat-08', icon: 'vacuum',
      name: 'Vacuum Forming',    type: 'Thermoforming',
      locations: ['Lab G1'],
      total: 1,  available: 1, inUse: 0, maintenance: 0, pendingBookings: 0,
    },
    // Totals: 18 machines | 12 available | 4 in-use | 2 maintenance | 9 pending
  ];

  /* ── Individual Machines ───────────────────────────────── */

  const machines = [
    { id: '3DP-01', categoryId: 'cat-01', name: '3D Printer Alpha',      location: 'Lab A1', type: 'FDM 3D Printer',    status: 'in-use',      currentBooking: { team: 'Team Alpha',   slot: '09:00 – 11:00 AM' }, nextBooking: { team: 'Team Beta',    slot: '11:00 AM – 01:00 PM' }, lastUpdated: '16 Jul 2025, 09:05 AM' },
    { id: '3DP-02', categoryId: 'cat-01', name: '3D Printer Beta',       location: 'Lab A2', type: 'FDM 3D Printer',    status: 'available',   currentBooking: null, nextBooking: { team: 'Team Gamma',  slot: '02:00 – 04:00 PM' },    lastUpdated: '16 Jul 2025, 08:00 AM' },
    { id: '3DP-03', categoryId: 'cat-01', name: '3D Printer Gamma',      location: 'Lab A2', type: 'Resin 3D Printer',  status: 'maintenance', currentBooking: null, nextBooking: null,                                                     lastUpdated: '16 Jul 2025, 07:30 AM' },
    { id: '3DP-04', categoryId: 'cat-01', name: '3D Printer Delta',      location: 'Lab B1', type: 'FDM 3D Printer',    status: 'available',   currentBooking: null, nextBooking: { team: 'Team Delta',  slot: '03:00 – 05:00 PM' },    lastUpdated: '15 Jul 2025, 05:00 PM' },
    { id: '3DP-05', categoryId: 'cat-01', name: '3D Printer Epsilon',    location: 'Lab B2', type: 'FDM 3D Printer',    status: 'available',   currentBooking: null, nextBooking: null,                                                     lastUpdated: '15 Jul 2025, 05:00 PM' },
    { id: 'LC-01',  categoryId: 'cat-02', name: 'Laser Cutter 01',       location: 'Lab C1', type: 'CO₂ Laser 60W',     status: 'in-use',      currentBooking: { team: 'Team Epsilon', slot: '10:00 AM – 12:00 PM' }, nextBooking: null,  lastUpdated: '16 Jul 2025, 10:00 AM' },
    { id: 'LC-02',  categoryId: 'cat-02', name: 'Laser Cutter 02',       location: 'Lab C1', type: 'CO₂ Laser 80W',     status: 'available',   currentBooking: null, nextBooking: null,                                                     lastUpdated: '15 Jul 2025, 06:00 PM' },
    { id: 'LC-03',  categoryId: 'cat-02', name: 'Laser Cutter 03',       location: 'Lab C2', type: 'CO₂ Laser 60W',     status: 'available',   currentBooking: null, nextBooking: null,                                                     lastUpdated: '15 Jul 2025, 06:00 PM' },
    { id: 'CNC-01', categoryId: 'cat-03', name: 'CNC Router 01',         location: 'Lab D1', type: 'CNC Router',        status: 'available',   currentBooking: null, nextBooking: { team: 'Team Zeta',   slot: '01:00 – 03:00 PM' },    lastUpdated: '16 Jul 2025, 08:00 AM' },
    { id: 'CNC-02', categoryId: 'cat-03', name: 'CNC Router 02',         location: 'Lab D1', type: 'CNC Mill',          status: 'in-use',      currentBooking: { team: 'Team Eta',    slot: '08:00 – 10:00 AM' }, nextBooking: null,  lastUpdated: '16 Jul 2025, 08:00 AM' },
    { id: 'MM-01',  categoryId: 'cat-04', name: 'Milling Machine 01',    location: 'Lab D2', type: 'PCB Mill',          status: 'available',   currentBooking: null, nextBooking: null,                                                     lastUpdated: '15 Jul 2025, 04:00 PM' },
    { id: 'MM-02',  categoryId: 'cat-04', name: 'Milling Machine 02',    location: 'Lab D2', type: 'PCB Mill',          status: 'maintenance', currentBooking: null, nextBooking: null,                                                     lastUpdated: '14 Jul 2025, 03:00 PM' },
    { id: 'VC-01',  categoryId: 'cat-05', name: 'Vinyl Cutter 01',       location: 'Lab E1', type: 'Desktop Vinyl',     status: 'available',   currentBooking: null, nextBooking: null,                                                     lastUpdated: '15 Jul 2025, 05:00 PM' },
    { id: 'VC-02',  categoryId: 'cat-05', name: 'Vinyl Cutter 02',       location: 'Lab E1', type: 'Desktop Vinyl',     status: 'available',   currentBooking: null, nextBooking: null,                                                     lastUpdated: '15 Jul 2025, 05:00 PM' },
    { id: 'SS-01',  categoryId: 'cat-06', name: 'Soldering Station 01',  location: 'Lab F1', type: 'Hakko FX-888D',    status: 'available',   currentBooking: null, nextBooking: null,                                                     lastUpdated: '15 Jul 2025, 05:30 PM' },
    { id: 'SS-02',  categoryId: 'cat-06', name: 'Soldering Station 02',  location: 'Lab F1', type: 'Hakko FX-888D',    status: 'in-use',      currentBooking: { team: 'Team Theta',  slot: '09:00 – 11:00 AM' }, nextBooking: null,  lastUpdated: '16 Jul 2025, 09:00 AM' },
    { id: 'EB-01',  categoryId: 'cat-07', name: 'Electronics Bench 01',  location: 'Lab F2', type: 'Test Bench',        status: 'available',   currentBooking: null, nextBooking: null,                                                     lastUpdated: '15 Jul 2025, 05:00 PM' },
    { id: 'VF-01',  categoryId: 'cat-08', name: 'Vacuum Former 01',      location: 'Lab G1', type: 'Formech 300XQ',    status: 'available',   currentBooking: null, nextBooking: null,                                                     lastUpdated: '15 Jul 2025, 04:30 PM' },
  ];

  /* ── Bookings ───────────────────────────────────────────── */

  const bookings = [
    { id: 'BK-1001', machineId: '3DP-01', machine: '3D Printer Alpha',     team: 'Team Alpha',   project: 'Solar Car',           date: '16 Jul 2025', slot: '09:00 AM – 11:00 AM', status: 'confirmed' },
    { id: 'BK-1002', machineId: 'LC-01',  machine: 'Laser Cutter 01',      team: 'Team Beta',    project: 'Solar Car',           date: '16 Jul 2025', slot: '10:00 AM – 01:00 PM', status: 'pending' },
    { id: 'BK-1003', machineId: '3DP-01', machine: '3D Printer Alpha',     team: 'Team Delta',   project: 'Prototype Model',     date: '17 Jul 2025', slot: '09:00 AM – 12:30 PM', status: 'pending' },
    { id: 'BK-1004', machineId: 'CNC-01', machine: 'CNC Router 01',        team: 'Team Epsilon', project: 'Irrigation System',   date: '17 Jul 2025', slot: '01:00 PM – 03:00 PM', status: 'pending' },
    { id: 'BK-1005', machineId: '3DP-03', machine: '3D Printer Gamma',     team: 'Team Theta',   project: 'Mechanical Part',     date: '17 Jul 2025', slot: '11:00 AM – 01:30 PM', status: 'confirmed' },
    { id: 'BK-1006', machineId: 'MM-01',  machine: 'Milling Machine 01',   team: 'Team Iota',    project: 'Drone Frame',         date: '18 Jul 2025', slot: '10:00 AM – 12:00 PM', status: 'confirmed' },
    { id: 'BK-1007', machineId: 'VC-01',  machine: 'Vinyl Cutter 01',      team: 'Team Kappa',   project: 'Signage Project',     date: '18 Jul 2025', slot: '02:00 PM – 04:00 PM', status: 'cancelled' },
    { id: 'BK-1008', machineId: 'EB-01',  machine: 'Electronics Bench 01', team: 'Team Lambda',  project: 'Robot Controller',    date: '19 Jul 2025', slot: '09:00 AM – 11:00 AM', status: 'confirmed' },
  ];

  /* ── Maintenance Records ───────────────────────────────── */

  const maintenance = [
    { id: 'MT-001', machineId: '3DP-03', machine: '3D Printer',      type: 'Nozzle Replacement',          startDate: '16 Jul 2025', endDate: '16 Jul 2025', status: 'in-progress', assignee: 'Lab Tech' },
    { id: 'MT-002', machineId: 'LC-03',  machine: 'Laser Cutter',    type: 'Lens Cleaning',               startDate: '16 Jul 2025', endDate: '16 Jul 2025', status: 'in-progress', assignee: 'Lab Tech' },
    { id: 'MT-003', machineId: 'CNC-01', machine: 'CNC Machine',     type: 'Spindle Alignment',           startDate: '20 Jul 2025', endDate: '21 Jul 2025', status: 'scheduled',   assignee: 'Vendor' },
    { id: 'MT-004', machineId: '3DP-02', machine: '3D Printer',      type: 'Bed Leveling',                startDate: '22 Jul 2025', endDate: '22 Jul 2025', status: 'scheduled',   assignee: 'Lab Tech' },
    { id: 'MT-005', machineId: 'VF-01',  machine: 'Vacuum Former',   type: 'Heating Element Check',       startDate: '23 Jul 2025', endDate: '23 Jul 2025', status: 'scheduled',   assignee: 'Vendor' },
    { id: 'MT-006', machineId: 'LC-01',  machine: 'Laser Cutter',    type: 'Mirror Alignment',            startDate: '24 Jul 2025', endDate: '24 Jul 2025', status: 'scheduled',   assignee: 'Lab Tech' },
    { id: 'MT-007', machineId: 'MM-02',  machine: 'Milling Machine', type: 'Spindle Bearing Replacement', startDate: '14 Jul 2025', endDate: '15 Jul 2025', status: 'completed',   assignee: 'Vendor' },
    { id: 'MT-008', machineId: 'VC-02',  machine: 'Vinyl Cutter',    type: 'Blade Replacement',           startDate: '13 Jul 2025', endDate: '13 Jul 2025', status: 'completed',   assignee: 'Lab Tech' },
    { id: 'MT-009', machineId: 'SS-01',  machine: 'Soldering Station', type: 'Tip & Grip Replacement',   startDate: '12 Jul 2025', endDate: '12 Jul 2025', status: 'completed',   assignee: 'Lab Tech' },
    { id: 'MT-010', machineId: 'EB-01',  machine: 'Electronics Bench', type: 'Oscilloscope Calibration', startDate: '11 Jul 2025', endDate: '11 Jul 2025', status: 'completed',   assignee: 'Vendor' },
  ];

  /* ── Equipment Schedule (for 3DP-01) ──────────────────── */

  const schedule = {
    machineId:   '3DP-01',
    machineName: '3D Printer Alpha',
    date:        '16 Jul 2025',
    timeSlots: [
      { hour: '09:00', end: '11:00', team: 'Team Alpha',  project: 'Smart Irrigation System', status: 'confirmed' },
      { hour: '11:00', end: '13:00', team: 'Team Beta',   project: 'Solar Car',               status: 'confirmed' },
      { hour: '13:00', end: '14:00', team: null,           project: null,                      status: 'available' },
      { hour: '14:00', end: '16:00', team: 'Team Gamma',  project: 'Line Follower Robot',     status: 'confirmed' },
      { hour: '16:00', end: '17:00', team: null,           project: null,                      status: 'available' },
      { hour: '17:00', end: '18:30', team: 'Team Delta',  project: 'Prototype Model',         status: 'upcoming' },
      { hour: '18:30', end: '19:00', team: null,           project: null,                      status: 'available' },
    ],
  };

  return { categories, machines, bookings, maintenance, schedule };
})();

'use strict';

/**
 * app.js – Page-specific initialization.
 * Reads body[data-page] and dispatches to the correct init function.
 * Each init function is self-contained and under 30 lines of logic.
 * Depends on: DATA (data.js), UI (ui.js).
 */

(function () {

  /* ──────────────────────────────────────────────────────────────
   * SHARED: Tab-filter strip helper
   * Renders pill-chip quick-filters above the toolbar.
   * @param {HTMLElement} container – the .tab-filter-strip element
   * @param {Array<{label, value, count}>} tabs
   * @param {string} activeValue – currently selected value
   * @param {Function} onChange – callback(value)
   * ────────────────────────────────────────────────────────────── */

  function renderTabFilter(container, tabs, activeValue, onChange) {
    container.innerHTML = tabs.map(t => {
      const isActive = t.value === activeValue;
      return `<button
        class="tab-filter__btn${isActive ? ' tab-filter__btn--active' : ''}"
        data-tab-value="${t.value}"
        aria-pressed="${isActive}"
        type="button"
      >${t.label}<span class="tab-filter__count">${t.count}</span></button>`;
    }).join('');

    container.querySelectorAll('.tab-filter__btn').forEach(btn => {
      btn.addEventListener('click', () => {
        onChange(btn.dataset.tabValue);
      });
    });
  }

  /* ──────────────────────────────────────────────────────────
   * PAGE: Equipment Categories Overview (index.html)
   * ────────────────────────────────────────────────────────── */


  function initCategoriesPage() {
    const ROWS_PER_PAGE = 10;
    let filteredData    = [...DATA.categories];
    let currentPage     = 1;

    const statsEl    = document.getElementById('stats-strip');
    const tbody      = document.getElementById('categories-tbody');
    const searchEl   = document.getElementById('search-categories');
    const statusEl   = document.getElementById('filter-status');
    const locationEl = document.getElementById('filter-location');
    const refreshEl  = document.getElementById('btn-refresh');
    const paginEl    = document.getElementById('pagination');

    // ── Render ──────────────────────────────────────────────

    function renderPage() {
      const start = (currentPage - 1) * ROWS_PER_PAGE;
      const slice = filteredData.slice(start, start + ROWS_PER_PAGE);

      tbody.innerHTML = slice.length
        ? slice.map(buildRow).join('')
        : `<tr><td class="table__empty" colspan="7">No equipment types match your criteria.</td></tr>`;

      UI.renderPagination(paginEl, currentPage, filteredData.length, ROWS_PER_PAGE, page => {
        currentPage = page;
        renderPage();
      });
    }

    function buildRow(cat) {
      return `
        <tr>
          <td>
            <div class="equip-type">
              <div class="equip-type__icon" aria-hidden="true">${UI.icon(cat.icon)}</div>
              <div>
                <p class="equip-type__name">${cat.name}</p>
                <p class="equip-type__desc">${cat.type}</p>
              </div>
            </div>
          </td>
          <td class="col-center"><span class="num--total">${cat.total}</span></td>
          <td class="col-center"><span class="num--available">${cat.available}</span></td>
          <td class="col-center"><span class="num--in-use">${cat.inUse}</span></td>
          <td class="col-center"><span class="num--maintenance">${cat.maintenance}</span></td>
          <td class="col-center"><span class="num--pending">${cat.pendingBookings}</span></td>
          <td class="col-right">
            <a href="machines.html?cat=${cat.id}" class="btn btn--outline btn--sm">View Machines</a>
          </td>
        </tr>`;
    }

    // ── Filtering ────────────────────────────────────────────

    function searchMatch(row, q) {
      return row.name.toLowerCase().includes(q) || row.type.toLowerCase().includes(q);
    }

    function statusMatch(row, val) {
      const keyMap = { available: 'available', 'in-use': 'inUse', maintenance: 'maintenance', pending: 'pendingBookings' };
      const key = keyMap[val];
      return key ? row[key] > 0 : true;
    }

    function locationMatch(row, val) {
      return row.locations.some(loc => loc.startsWith(val));
    }

    function applyFilters() {
      const q    = searchEl.value.trim().toLowerCase();
      const stat = statusEl.value;
      const loc  = locationEl.value;

      filteredData = DATA.categories.filter(row => {
        const okSearch   = !q    || searchMatch(row, q);
        const okStatus   = !stat || statusMatch(row, stat);
        const okLocation = !loc  || locationMatch(row, loc);
        return okSearch && okStatus && okLocation;
      });

      currentPage = 1;
      renderPage();
    }

    const tabStripEl = document.getElementById('categories-tab-filter');
    let activeTab = '';

    function buildCategoryTabs() {
      const all  = DATA.categories.length;
      const avail = DATA.categories.filter(c => c.available > 0).length;
      const inUse = DATA.categories.filter(c => c.inUse > 0).length;
      const maint = DATA.categories.filter(c => c.maintenance > 0).length;
      const pend  = DATA.categories.filter(c => c.pendingBookings > 0).length;
      return [
        { label: 'All',         value: '',            count: all },
        { label: 'Available',   value: 'available',   count: avail },
        { label: 'In Use',      value: 'in-use',      count: inUse },
        { label: 'Maintenance', value: 'maintenance', count: maint },
        { label: 'Pending',     value: 'pending',     count: pend },
      ];
    }

    function redrawTabFilter() {
      renderTabFilter(tabStripEl, buildCategoryTabs(), activeTab, val => {
        activeTab = val;
        statusEl.value = val;
        applyFilters();
      });
    }

    // ── Interactions ─────────────────────────────────────────

    searchEl.addEventListener('input', applyFilters);
    statusEl.addEventListener('change', e => { activeTab = e.target.value; applyFilters(); });
    locationEl.addEventListener('change', applyFilters);

    refreshEl.addEventListener('click', () => {
      searchEl.value   = '';
      statusEl.value   = '';
      locationEl.value = '';
      activeTab        = '';
      filteredData     = [...DATA.categories];
      currentPage      = 1;
      redrawTabFilter();
      renderPage();
    });

    // ── Init ─────────────────────────────────────────────────

    UI.renderStats(statsEl, UI.computeStats(DATA.categories));
    redrawTabFilter();
    renderPage();
  }

  /* ──────────────────────────────────────────────────────────────
   * PAGE: Individual Machines (machines.html)
   * ────────────────────────────────────────────────────────────── */

  /* Resolve category id from URL query string */
  function getCatId() {
    return new URLSearchParams(window.location.search).get('cat') || 'cat-01';
  }

  /* Collect all DOM references for the machines page into one object */
  function getMachinesDOM() {
    return {
      titleEl:    document.getElementById('page-title'),
      subtitleEl: document.getElementById('page-subtitle'),
      statsEl:    document.getElementById('machine-stats'),
      tbody:      document.getElementById('machines-tbody'),
      searchEl:   document.getElementById('search-machines'),
      statusEl:   document.getElementById('filter-machine-status'),
      locationEl: document.getElementById('filter-machine-location'),
      refreshEl:  document.getElementById('btn-refresh-machines'),
      paginEl:    document.getElementById('machines-pagination'),
      drawer:     document.getElementById('machine-drawer'),
      overlay:    document.getElementById('drawer-overlay'),
      closeBtn:   document.getElementById('btn-close-drawer'),
    };
  }

  /* Populate location <select> with unique machine locations */
  function populateLocations(select, machines) {
    const locs = [...new Set(machines.map(m => m.location))].sort();
    const opts = locs.map(l => `<option value="${l}">${l}</option>`).join('');
    select.innerHTML = `<option value="">All Locations</option>${opts}`;
  }

  /* Compute + render the 4-item stat strip for a machine set */
  function renderMachineStats(container, machines) {
    const s = machines.reduce(
      (a, m) => { a[m.status === 'available' ? 'available' : m.status === 'in-use' ? 'inUse' : 'maintenance']++; return a; },
      { available: 0, inUse: 0, maintenance: 0 }
    );
    const pending = DATA.bookings.filter(b =>
      b.status === 'pending' && machines.some(m => m.id === b.machineId)
    ).length;
    UI.renderCustomStats(container, [
      { cls: 'stat-card--available',   iconKey: 'check-circle', label: 'Available',        value: s.available },
      { cls: 'stat-card--in-use',      iconKey: 'activity',     label: 'In Use',           value: s.inUse },
      { cls: 'stat-card--maintenance', iconKey: 'tool',         label: 'Maintenance',      value: s.maintenance },
      { cls: 'stat-card--pending',     iconKey: 'clock',        label: 'Pending Bookings', value: pending },
    ]);
  }

  /* Render the current page slice of machines into the tbody */
  function renderMachineTable(state, dom) {
    const { page, perPage, data } = state;
    const slice = data.slice((page - 1) * perPage, page * perPage);
    dom.tbody.innerHTML = slice.length
      ? slice.map(buildMachineRow).join('')
      : `<tr><td class="table__empty" colspan="6">No machines match your criteria.</td></tr>`;
    UI.renderPagination(dom.paginEl, page, data.length, perPage, p => {
      state.page = p;
      renderMachineTable(state, dom);
    });
  }

  /* Build one machine table row HTML string */
  function buildMachineRow(m) {
    const fmtSlot = bk => bk
      ? `<p class="table-booking__team">${bk.team}</p><p class="table-booking__slot">${bk.slot}</p>`
      : `<span class="text-muted">—</span>`;
    return `<tr>
      <td><span class="machine-id">${m.id}</span></td>
      <td class="text-sm">${m.location}</td>
      <td>${UI.badge(m.status)}</td>
      <td>${fmtSlot(m.currentBooking)}</td>
      <td>${fmtSlot(m.nextBooking)}</td>
      <td class="col-right">
        <button class="btn btn--secondary btn--sm" data-mid="${m.id}" aria-label="View details for ${m.id}">View</button>
      </td>
    </tr>`;
  }

  /* Apply search + status + location filters and re-render */
  function applyMachineFilters(state, dom, catMachines) {
    const q   = dom.searchEl.value.trim().toLowerCase();
    const st  = dom.statusEl.value;
    const loc = dom.locationEl.value;
    state.data = catMachines.filter(m => {
      const okQ   = !q   || m.id.toLowerCase().includes(q) || m.name.toLowerCase().includes(q) || m.location.toLowerCase().includes(q);
      const okSt  = !st  || m.status === st;
      const okLoc = !loc || m.location === loc;
      return okQ && okSt && okLoc;
    });
    state.page = 1;
    renderMachineTable(state, dom);
  }

  /* Fill drawer header elements for the selected machine */
  function fillDrawerHeader(machine, category) {
    document.getElementById('drawer-machine-id').textContent       = machine.id;
    document.getElementById('drawer-status-badge').innerHTML       = UI.badge(machine.status);
    document.getElementById('drawer-machine-name').textContent     = machine.name;
    document.getElementById('drawer-machine-category').textContent = `${category.name} · ${machine.type}`;
    const bk = machine.currentBooking;
    document.getElementById('drawer-current-booking').textContent  = bk ? `Current Booking: ${bk.slot}` : 'No active booking';
    document.getElementById('drawer-machine-icon').innerHTML       = UI.icon(category.icon);
  }

  /* Fill the Machine Information detail grid */
  function fillDrawerInfo(machine) {
    const rows = [
      ['Machine ID',   `<span class="machine-id">${machine.id}</span>`],
      ['Machine Name', machine.name],
      ['Location',     machine.location],
      ['Type',         machine.type],
      ['Status',       UI.badge(machine.status)],
      ['Last Updated', machine.lastUpdated],
    ];
    document.getElementById('drawer-machine-info').innerHTML = rows
      .map(([label, val]) => `<div class="detail-item"><p class="detail-item__label">${label}</p><p class="detail-item__value">${val}</p></div>`)
      .join('');
  }

  /* Fill the Today's Summary strip with computed mock values */
  function fillDrawerSummary(machine) {
    const bks  = DATA.bookings.filter(b => b.machineId === machine.id && b.status !== 'cancelled');
    const n    = bks.length;
    const bH   = n * 2;
    const aH   = Math.max(0, 9 - bH);
    const cards = [
      { value: `${bH}h 30m`, label: 'Total Booked Time' },
      { value: `${aH}h 30m`, label: 'Available Time' },
      { value: n,             label: 'Bookings Today' },
    ];
    document.getElementById('drawer-summary').innerHTML = cards
      .map(c => `<div class="summary-card"><p class="summary-card__value">${c.value}</p><p class="summary-card__label">${c.label}</p></div>`)
      .join('');
  }

  /* Open drawer and populate with machine data */
  function openMachineDrawer(machineId, category, drawer, overlay) {
    const machine = DATA.machines.find(m => m.id === machineId);
    if (!machine) return;
    fillDrawerHeader(machine, category);
    fillDrawerInfo(machine);
    fillDrawerSummary(machine);
    UI.openDrawer(drawer, overlay);
  }

  /* Coordinator: wire up all machines-page interactions */
  function initMachinesPage() {
    const state    = { page: 1, perPage: 10, data: [] };
    const catId    = getCatId();
    const category = DATA.categories.find(c => c.id === catId) || DATA.categories[0];
    const catMs    = DATA.machines.filter(m => m.categoryId === catId);
    const dom      = getMachinesDOM();

    state.data = [...catMs];
    dom.titleEl.textContent    = category.name;
    dom.subtitleEl.textContent = `${catMs.length} Machine${catMs.length !== 1 ? 's' : ''} · ${category.type}`;

    populateLocations(dom.locationEl, catMs);
    renderMachineStats(dom.statsEl, catMs);

    dom.searchEl.addEventListener('input',  () => applyMachineFilters(state, dom, catMs));
    dom.statusEl.addEventListener('change', () => applyMachineFilters(state, dom, catMs));
    dom.locationEl.addEventListener('change', () => applyMachineFilters(state, dom, catMs));

    dom.refreshEl.addEventListener('click', () => {
      dom.searchEl.value = dom.statusEl.value = dom.locationEl.value = '';
      state.data = [...catMs];
      state.page = 1;
      renderMachineTable(state, dom);
    });

    dom.tbody.addEventListener('click', e => {
      const btn = e.target.closest('[data-mid]');
      if (btn) openMachineDrawer(btn.dataset.mid, category, dom.drawer, dom.overlay);
    });

    dom.closeBtn.addEventListener('click', () => UI.closeDrawer(dom.drawer, dom.overlay));
    dom.overlay.addEventListener('click',  () => UI.closeDrawer(dom.drawer, dom.overlay));
    document.addEventListener('keydown', e => { if (e.key === 'Escape') UI.closeDrawer(dom.drawer, dom.overlay); });

    renderMachineTable(state, dom);
  }

  /* ──────────────────────────────────────────────────────────────
   * PAGE: Booking Management (booking-management.html)
   * ────────────────────────────────────────────────────────────── */

  /* Aggregate booking counts by status */
  function computeBookingStats(bookings) {
    return bookings.reduce(
      (a, b) => { a[b.status] = (a[b.status] || 0) + 1; return a; },
      { total: bookings.length, confirmed: 0, pending: 0, cancelled: 0 }
    );
  }

  /* Render the 4-card booking stat strip */
  function renderBookingStats(container, bookings) {
    const s = computeBookingStats(bookings);
    UI.renderCustomStats(container, [
      { cls: 'stat-card--bookings',   iconKey: 'book-open',   label: 'Total Bookings', value: s.total },
      { cls: 'stat-card--confirmed',  iconKey: 'check-circle', label: 'Confirmed',     value: s.confirmed },
      { cls: 'stat-card--pending',    iconKey: 'clock',        label: 'Pending',       value: s.pending },
      { cls: 'stat-card--cancelled',  iconKey: 'x',            label: 'Cancelled',     value: s.cancelled },
    ]);
  }

  /* Render the current page slice into the bookings tbody */
  function renderBookingTable(state, dom) {
    const { page, perPage, data } = state;
    const slice = data.slice((page - 1) * perPage, page * perPage);
    dom.tbody.innerHTML = slice.length
      ? slice.map(buildBookingRow).join('')
      : `<tr><td class="table__empty" colspan="7">No bookings match your criteria.</td></tr>`;
    UI.renderPagination(dom.paginEl, page, data.length, perPage, p => {
      state.page = p;
      renderBookingTable(state, dom);
    });
  }

  /* Build the action cell HTML based on booking status */
  function buildBookingActions(b) {
    if (b.status === 'cancelled') return `<span class="text-muted">—</span>`;
    const editBtn   = `<button class="btn btn--ghost btn--icon" data-action="edit"    data-bid="${b.id}" aria-label="Edit booking ${b.id}"   title="Edit">${UI.icon('edit')}</button>`;
    const cancelBtn = `<button class="btn btn--ghost btn--icon btn--danger-ghost" data-action="cancel" data-bid="${b.id}" aria-label="Cancel booking ${b.id}" title="Cancel">${UI.icon('trash')}</button>`;
    const confirmBtn = b.status === 'pending'
      ? `<button class="btn btn--outline btn--sm" data-action="confirm" data-bid="${b.id}" aria-label="Confirm booking ${b.id}">Confirm</button>`
      : '';
    return `<div class="action-group">${confirmBtn}${editBtn}${cancelBtn}</div>`;
  }

  /* Build one booking table row HTML string */
  function buildBookingRow(b) {
    return `<tr data-booking-id="${b.id}">
      <td><span class="machine-id">${b.id}</span></td>
      <td class="text-sm">${b.machine}</td>
      <td class="text-sm">${b.team}</td>
      <td class="text-sm">${b.project}</td>
      <td>
        <p class="table-booking__team">${b.date}</p>
        <p class="table-booking__slot">${b.slot}</p>
      </td>
      <td>${UI.badge(b.status)}</td>
      <td class="col-right">${buildBookingActions(b)}</td>
    </tr>`;
  }

  /* Apply search + status + date filters, then re-render */
  function applyBookingFilters(state, dom) {
    const q    = dom.searchEl.value.trim().toLowerCase();
    const st   = dom.statusEl.value;
    const date = dom.dateEl.value;
    state.data = DATA.bookings.filter(b => {
      const okQ  = !q  || b.id.toLowerCase().includes(q) || b.machine.toLowerCase().includes(q)
                       || b.team.toLowerCase().includes(q) || b.project.toLowerCase().includes(q);
      const okSt = !st   || b.status === st;
      const okDt = !date || b.date.toLowerCase().includes(date.toLowerCase());
      return okQ && okSt && okDt;
    });
    state.page = 1;
    renderBookingTable(state, dom);
  }

  /* Handle action button clicks via event delegation */
  function handleBookingAction(e, state, dom) {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const { action, bid } = btn.dataset;
    const idx = DATA.bookings.findIndex(b => b.id === bid);
    if (idx === -1) return;

    if (action === 'confirm') {
      DATA.bookings[idx].status = 'confirmed';
    } else if (action === 'cancel') {
      DATA.bookings[idx].status = 'cancelled';
    }
    // 'edit' is a no-op in this demo (could open a modal)

    // Re-sync filtered data and re-render
    applyBookingFilters(state, dom);
    renderBookingStats(dom.statsEl, DATA.bookings);
  }

  /* Coordinator: wire up all booking-page interactions */
  function initBookingsPage() {
    const state = { page: 1, perPage: 10, data: [...DATA.bookings] };
    let activeTab = '';
    const dom = {
      statsEl:    document.getElementById('booking-stats'),
      tabStripEl: document.getElementById('bookings-tab-filter'),
      tbody:      document.getElementById('bookings-tbody'),
      searchEl:   document.getElementById('search-bookings'),
      statusEl:   document.getElementById('filter-booking-status'),
      equipEl:    document.getElementById('filter-booking-equip'),
      dateEl:     document.getElementById('filter-booking-date'),
      refreshEl:  document.getElementById('btn-refresh-bookings'),
      paginEl:    document.getElementById('bookings-pagination'),
    };

    function buildBookingTabs() {
      const all       = DATA.bookings.length;
      const confirmed = DATA.bookings.filter(b => b.status === 'confirmed').length;
      const pending   = DATA.bookings.filter(b => b.status === 'pending').length;
      const cancelled = DATA.bookings.filter(b => b.status === 'cancelled').length;
      return [
        { label: 'All',             value: '',          count: all },
        { label: 'Pending',         value: 'pending',   count: pending },
        { label: 'Confirmed',       value: 'confirmed', count: confirmed },
        { label: 'Cancelled',       value: 'cancelled', count: cancelled },
      ];
    }

    function redrawBookingTabs() {
      renderTabFilter(dom.tabStripEl, buildBookingTabs(), activeTab, val => {
        activeTab = val;
        dom.statusEl.value = val;
        applyBookingFiltersExt(state, dom);
      });
    }

    renderBookingStats(dom.statsEl, DATA.bookings);
    redrawBookingTabs();

    dom.searchEl.addEventListener('input',  () => applyBookingFiltersExt(state, dom));
    dom.statusEl.addEventListener('change', e => { activeTab = e.target.value; applyBookingFiltersExt(state, dom); });
    dom.equipEl.addEventListener('change',  () => applyBookingFiltersExt(state, dom));
    dom.dateEl.addEventListener('input',    () => applyBookingFiltersExt(state, dom));

    dom.refreshEl.addEventListener('click', () => {
      dom.searchEl.value = dom.statusEl.value = dom.dateEl.value = dom.equipEl.value = '';
      activeTab = '';
      state.data = [...DATA.bookings];
      state.page = 1;
      redrawBookingTabs();
      renderBookingTable(state, dom);
    });

    dom.tbody.addEventListener('click', e => {
      handleBookingAction(e, state, dom);
      redrawBookingTabs();
      renderBookingStats(dom.statsEl, DATA.bookings);
    });

    renderBookingTable(state, dom);
  }

  /* Extended filter that also checks the equipment-type select */
  function applyBookingFiltersExt(state, dom) {
    const q     = dom.searchEl.value.trim().toLowerCase();
    const st    = dom.statusEl.value;
    const equip = dom.equipEl ? dom.equipEl.value.toLowerCase() : '';
    const date  = dom.dateEl.value;
    state.data = DATA.bookings.filter(b => {
      const okQ  = !q  || b.id.toLowerCase().includes(q) || b.machine.toLowerCase().includes(q)
                       || b.team.toLowerCase().includes(q) || b.project.toLowerCase().includes(q);
      const okSt  = !st    || b.status === st;
      const okEq  = !equip || b.machine.toLowerCase().includes(equip);
      const okDt  = !date  || b.date.toLowerCase().includes(date.toLowerCase());
      return okQ && okSt && okEq && okDt;
    });
    state.page = 1;
    renderBookingTable(state, dom);
  }

  /* ──────────────────────────────────────────────────────────────
   * PAGE: Equipment Schedule (schedule.html)
   * ────────────────────────────────────────────────────────────── */

  /* Compute schedule stats from time-slot data */
  function computeScheduleStats(slots) {
    const booked    = slots.filter(s => s.status !== 'available').length;
    const available = slots.filter(s => s.status === 'available').length;
    const totalHrs  = slots.reduce((sum, s) => {
      const h1 = parseInt(s.hour, 10);
      const h2 = parseInt(s.end, 10);
      return sum + (s.status !== 'available' ? h2 - h1 : 0);
    }, 0);
    const totalSlotHrs = slots.reduce((sum, s) => {
      return sum + (parseInt(s.end, 10) - parseInt(s.hour, 10));
    }, 0);
    const utilization = totalSlotHrs > 0 ? Math.round((totalHrs / totalSlotHrs) * 100) : 0;
    return { booked, available, totalHrs, utilization };
  }

  /* Render schedule stat strip */
  function renderScheduleStats(container, slots) {
    const s = computeScheduleStats(slots);
    UI.renderCustomStats(container, [
      { cls: 'stat-card--bookings',   iconKey: 'calendar',     label: 'Booked Slots',      value: s.booked },
      { cls: 'stat-card--available',  iconKey: 'check-circle', label: 'Available Slots',    value: s.available },
      { cls: 'stat-card--in-use',     iconKey: 'clock',        label: 'Total Hours Booked', value: `${s.totalHrs}h` },
      { cls: 'stat-card--confirmed',  iconKey: 'activity',     label: 'Utilization',        value: `${s.utilization}%` },
    ]);
  }

  /* Format 24h time string to 12h display (e.g. "09:00" → "09:00 AM") */
  function formatTime12(t) {
    const h = parseInt(t, 10);
    const m = t.split(':')[1] || '00';
    if (h === 0)  return `12:${m} AM`;
    if (h < 12)   return `${String(h).padStart(2, '0')}:${m} AM`;
    if (h === 12) return `12:${m} PM`;
    return `${String(h - 12).padStart(2, '0')}:${m} PM`;
  }

  /* Build one timeline row HTML */
  function buildTimelineRow(slot) {
    const timeLabel = formatTime12(slot.hour);

    if (slot.status === 'available') {
      return `
        <div class="timeline-row">
          <div class="timeline-time">${timeLabel}</div>
          <div class="timeline-slot timeline-slot--available">
            <span class="timeline-slot__label">Available — ${formatTime12(slot.hour)} to ${formatTime12(slot.end)}</span>
          </div>
        </div>`;
    }

    const variant = slot.status === 'confirmed'
      ? 'timeline-slot--confirmed'
      : 'timeline-slot--upcoming';

    return `
      <div class="timeline-row">
        <div class="timeline-time">${timeLabel}</div>
        <div class="timeline-slot ${variant}">
          <p class="timeline-slot__team">${slot.team}</p>
          <p class="timeline-slot__project">${slot.project}</p>
          <p class="timeline-slot__time">${formatTime12(slot.hour)} – ${formatTime12(slot.end)}</p>
        </div>
      </div>`;
  }

  /* Render the entire timeline from slot data */
  function renderTimeline(container, slots) {
    container.innerHTML = slots.length
      ? slots.map(buildTimelineRow).join('')
      : `<div class="empty-state">
           <div class="empty-state__icon">${UI.icon('calendar')}</div>
           <p class="empty-state__title">No schedule data</p>
           <p class="empty-state__desc">No time slots are configured for this date.</p>
         </div>`;
  }

  /* Coordinator: wire up schedule page interactions */
  function initSchedulePage() {
    const sched     = DATA.schedule;
    const titleEl   = document.getElementById('schedule-title');
    const subEl     = document.getElementById('schedule-subtitle');
    const machIdEl  = document.getElementById('schedule-machine-id');
    const statsEl   = document.getElementById('schedule-stats');
    const dateEl    = document.getElementById('schedule-date');
    const timeline  = document.getElementById('schedule-timeline');
    const prevBtn   = document.getElementById('btn-schedule-prev');
    const nextBtn   = document.getElementById('btn-schedule-next');
    const todayBtn  = document.getElementById('btn-schedule-today');
    const dayBtn    = document.getElementById('btn-view-day');
    const weekBtn   = document.getElementById('btn-view-week');
    const monthBtn  = document.getElementById('btn-view-month');
    const viewBtns  = [dayBtn, weekBtn, monthBtn].filter(Boolean);

    // Populate header
    titleEl.textContent  = `${sched.machineName} — Schedule`;
    subEl.textContent    = `Daily schedule for ${sched.machineName}`;
    machIdEl.textContent = sched.machineId;
    dateEl.textContent   = sched.date;

    // Render stats + timeline
    renderScheduleStats(statsEl, sched.timeSlots);
    renderTimeline(timeline, sched.timeSlots);

    // Date nav (cosmetic — cycles between 3 dates; only 16 Jul has data)
    const dates   = ['15 Jul 2025', '16 Jul 2025', '17 Jul 2025'];
    const liveIdx = 1; // index of the data date
    let dateIdx   = liveIdx;

    function updateDate() {
      dateEl.textContent = dates[dateIdx];
      const hasData = dates[dateIdx] === sched.date;
      renderTimeline(timeline, hasData ? sched.timeSlots : []);
      renderScheduleStats(statsEl, hasData ? sched.timeSlots : []);
    }

    prevBtn.addEventListener('click', () => {
      dateIdx = Math.max(0, dateIdx - 1);
      updateDate();
    });

    nextBtn.addEventListener('click', () => {
      dateIdx = Math.min(dates.length - 1, dateIdx + 1);
      updateDate();
    });

    todayBtn.addEventListener('click', () => {
      dateIdx = liveIdx;
      updateDate();
    });

    // View switcher — cosmetic; sets active button only
    function setActiveView(activeBtn) {
      viewBtns.forEach(btn => {
        const on = btn === activeBtn;
        btn.classList.toggle('view-switcher__btn--active', on);
        btn.setAttribute('aria-pressed', String(on));
      });
    }

    viewBtns.forEach(btn => btn.addEventListener('click', () => setActiveView(btn)));
  }

  /* ──────────────────────────────────────────────────────────────
   * PAGE: Maintenance Management (maintenance.html)
   * ────────────────────────────────────────────────────────────── */

  /* Aggregate maintenance counts by status */
  function computeMaintenanceStats(records) {
    return records.reduce(
      (a, r) => { a[r.status] = (a[r.status] || 0) + 1; return a; },
      { total: records.length, 'in-progress': 0, scheduled: 0, completed: 0 }
    );
  }

  /* Render the 4-card maintenance stat strip */
  function renderMaintenanceStats(container, records) {
    const s = computeMaintenanceStats(records);
    UI.renderCustomStats(container, [
      { cls: 'stat-card--bookings',    iconKey: 'tool',         label: 'Total Tasks',   value: s.total },
      { cls: 'stat-card--in-use',      iconKey: 'activity',     label: 'In Progress',   value: s['in-progress'] },
      { cls: 'stat-card--pending',     iconKey: 'clock',        label: 'Scheduled',     value: s.scheduled },
      { cls: 'stat-card--confirmed',   iconKey: 'check-circle', label: 'Completed',     value: s.completed },
    ]);
  }

  /* Render the current page slice into the maintenance tbody */
  function renderMaintenanceTable(state, dom) {
    const { page, perPage, data } = state;
    const slice = data.slice((page - 1) * perPage, page * perPage);
    dom.tbody.innerHTML = slice.length
      ? slice.map(buildMaintenanceRow).join('')
      : `<tr><td class="table__empty" colspan="8">No maintenance tasks match your criteria.</td></tr>`;
    UI.renderPagination(dom.paginEl, page, data.length, perPage, p => {
      state.page = p;
      renderMaintenanceTable(state, dom);
    });
  }

  /* Build action cell HTML for a maintenance record */
  function buildMaintenanceActions(r) {
    if (r.status === 'completed') return `<span class="text-muted">—</span>`;
    const editBtn   = `<button class="btn btn--ghost btn--icon" data-action="edit-mt"   data-mtid="${r.id}" aria-label="Edit task ${r.id}"   title="Edit">${UI.icon('edit')}</button>`;
    const deleteBtn = `<button class="btn btn--ghost btn--icon btn--danger-ghost" data-action="delete-mt" data-mtid="${r.id}" aria-label="Delete task ${r.id}" title="Delete">${UI.icon('trash')}</button>`;
    const completeBtn = r.status === 'in-progress'
      ? `<button class="btn btn--outline btn--sm" data-action="complete-mt" data-mtid="${r.id}" aria-label="Mark task ${r.id} as complete">Complete</button>`
      : '';
    return `<div class="action-group">${completeBtn}${editBtn}${deleteBtn}</div>`;
  }

  /* Build one maintenance table row HTML string */
  function buildMaintenanceRow(r) {
    return `<tr data-maintenance-id="${r.id}">
      <td><span class="machine-id">${r.id}</span></td>
      <td class="text-sm">${r.machine}</td>
      <td class="text-sm">${r.type}</td>
      <td class="text-sm">${r.startDate}</td>
      <td class="text-sm">${r.endDate}</td>
      <td>${UI.badge(r.status)}</td>
      <td class="text-sm">${r.assignee}</td>
      <td class="col-right">${buildMaintenanceActions(r)}</td>
    </tr>`;
  }

  /* Apply search + status + assignee filters, then re-render */
  function applyMaintenanceFilters(state, dom) {
    const q      = dom.searchEl.value.trim().toLowerCase();
    const st     = dom.statusEl.value;
    const assign = dom.assigneeEl.value;
    state.data = DATA.maintenance.filter(r => {
      const okQ   = !q  || r.id.toLowerCase().includes(q) || r.machine.toLowerCase().includes(q)
                        || r.type.toLowerCase().includes(q);
      const okSt  = !st     || r.status === st;
      const okAs  = !assign || r.assignee === assign;
      return okQ && okSt && okAs;
    });
    state.page = 1;
    renderMaintenanceTable(state, dom);
  }

  /* Handle action button clicks via event delegation */
  function handleMaintenanceAction(e, state, dom) {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const { action, mtid } = btn.dataset;
    const idx = DATA.maintenance.findIndex(r => r.id === mtid);
    if (idx === -1) return;

    if (action === 'complete-mt') {
      DATA.maintenance[idx].status = 'completed';
    } else if (action === 'delete-mt') {
      DATA.maintenance.splice(idx, 1);
    }
    // 'edit-mt' is a no-op in this demo

    applyMaintenanceFilters(state, dom);
    renderMaintenanceStats(dom.statsEl, DATA.maintenance);
  }

  /* Coordinator: wire up all maintenance-page interactions */
  function initMaintenancePage() {
    const state = { page: 1, perPage: 10, data: [...DATA.maintenance] };
    let activeTab = '';
    const dom = {
      statsEl:    document.getElementById('maintenance-stats'),
      tabStripEl: document.getElementById('maintenance-tab-filter'),
      tbody:      document.getElementById('maintenance-tbody'),
      searchEl:   document.getElementById('search-maintenance'),
      statusEl:   document.getElementById('filter-maintenance-status'),
      assigneeEl: document.getElementById('filter-maintenance-assignee'),
      refreshEl:  document.getElementById('btn-refresh-maintenance'),
      paginEl:    document.getElementById('maintenance-pagination'),
    };

    function buildMaintenanceTabs() {
      const all       = DATA.maintenance.length;
      const inProg    = DATA.maintenance.filter(r => r.status === 'in-progress').length;
      const sched     = DATA.maintenance.filter(r => r.status === 'scheduled').length;
      const completed = DATA.maintenance.filter(r => r.status === 'completed').length;
      return [
        { label: 'All',          value: '',            count: all },
        { label: 'Scheduled',    value: 'scheduled',   count: sched },
        { label: 'In Progress',  value: 'in-progress', count: inProg },
        { label: 'Completed',    value: 'completed',   count: completed },
      ];
    }

    function redrawMaintenanceTabs() {
      renderTabFilter(dom.tabStripEl, buildMaintenanceTabs(), activeTab, val => {
        activeTab = val;
        dom.statusEl.value = val;
        applyMaintenanceFilters(state, dom);
      });
    }

    renderMaintenanceStats(dom.statsEl, DATA.maintenance);
    redrawMaintenanceTabs();

    dom.searchEl.addEventListener('input',    () => applyMaintenanceFilters(state, dom));
    dom.statusEl.addEventListener('change',   e => { activeTab = e.target.value; applyMaintenanceFilters(state, dom); });
    dom.assigneeEl.addEventListener('change', () => applyMaintenanceFilters(state, dom));

    dom.refreshEl.addEventListener('click', () => {
      dom.searchEl.value = dom.statusEl.value = dom.assigneeEl.value = '';
      activeTab = '';
      state.data = [...DATA.maintenance];
      state.page = 1;
      redrawMaintenanceTabs();
      renderMaintenanceTable(state, dom);
    });

    dom.tbody.addEventListener('click', e => {
      handleMaintenanceAction(e, state, dom);
      redrawMaintenanceTabs();
    });

    renderMaintenanceTable(state, dom);
  }

  /* ──────────────────────────────────────────────────────────────
   * PAGE DISPATCHER
   * Map body[data-page] → init function
   * ────────────────────────────────────────────────────────────── */

  const PAGE_INITS = {
    categories:  initCategoriesPage,
    machines:    initMachinesPage,
    bookings:    initBookingsPage,
    schedule:    initSchedulePage,
    maintenance: initMaintenancePage,
  };

  const page = document.body.dataset.page;
  if (PAGE_INITS[page]) {
    PAGE_INITS[page]();
  }

})();

// ==========================================================================
// 1. INITIAL RETURNS DATASETS (TOOLS & COMPONENTS)
// ==========================================================================
const initialReturns = [
  {
    id: "TR-2025-0012",
    team: "Team Alpha",
    project: "Smart Irrigation",
    leader: "Surendhan",
    faculty: "Dr. Kumar",
    issuedDate: "14 May 2025 10:00 AM",
    expectedReturn: "15 May 2025 05:00 PM",
    items: [
      { name: "Screwdriver (Phillips)", issued: 5, alreadyReturned: 3, returnedToday: 2, good: 2, damaged: 0, missing: 0, remarks: "" },
      { name: "Plier", issued: 2, alreadyReturned: 1, returnedToday: 1, good: 1, damaged: 0, missing: 0, remarks: "" },
      { name: "Cutter", issued: 1, alreadyReturned: 0, returnedToday: 1, good: 0, damaged: 0, missing: 1, remarks: "Team informed that it is misplaced during testing and not able to locate." },
      { name: "Multimeter", issued: 1, alreadyReturned: 0, returnedToday: 1, good: 1, damaged: 0, missing: 0, remarks: "" }
    ],
    status: "Pending",
    verifiedOn: ""
  },
  {
    id: "TR-2025-0021",
    team: "Team Beta",
    project: "Line Follower Robot",
    leader: "Karthik",
    faculty: "Dr. Priya",
    issuedDate: "14 May 2025 11:00 AM",
    expectedReturn: "15 May 2025 04:00 PM",
    items: [
      { name: "Multimeter", issued: 1, alreadyReturned: 0, returnedToday: 1, good: 1, damaged: 0, missing: 0, remarks: "" }
    ],
    status: "Pending",
    verifiedOn: ""
  },
  {
    id: "TR-2025-0028",
    team: "Team Gamma",
    project: "Home Automation",
    leader: "Lokesh",
    faculty: "Prof. Ramesh",
    issuedDate: "14 May 2025 01:00 PM",
    expectedReturn: "15 May 2025 03:00 PM",
    items: [
      { name: "Screwdriver (Phillips)", issued: 1, alreadyReturned: 0, returnedToday: 1, good: 1, damaged: 0, missing: 0, remarks: "" },
      { name: "Cutter", issued: 1, alreadyReturned: 0, returnedToday: 1, good: 1, damaged: 0, missing: 0, remarks: "" }
    ],
    status: "Pending",
    verifiedOn: ""
  },
  {
    id: "TR-2025-0035",
    team: "Team Delta",
    project: "Weather Station",
    leader: "Vignesh",
    faculty: "Dr. Kumar",
    issuedDate: "14 May 2025 02:00 PM",
    expectedReturn: "15 May 2025 02:00 PM",
    items: [
      { name: "Plier", issued: 1, alreadyReturned: 1, returnedToday: 0, good: 0, damaged: 0, missing: 0, remarks: "" }
    ],
    status: "Completed",
    verifiedOn: "15 May 2025 02:30 PM"
  }
];

const initialComponentReturns = [
  {
    id: "CR-2025-0001",
    team: "Team Alpha",
    project: "Smart Irrigation",
    leader: "Surendhan",
    faculty: "Dr. Kumar",
    issuedDate: "14 May 2025 10:00 AM",
    expectedReturn: "Project Completion",
    items: [
      { name: "Arduino Uno R3", issued: 2, alreadyReturned: 1, returnedToday: 1, good: 1, damaged: 0, missing: 0, remarks: "" },
      { name: "Servo Motor SG90", issued: 4, alreadyReturned: 2, returnedToday: 2, good: 2, damaged: 0, missing: 0, remarks: "" },
      { name: "Breadboard 830 Points", issued: 2, alreadyReturned: 1, returnedToday: 1, good: 1, damaged: 0, missing: 0, remarks: "" }
    ],
    status: "Pending",
    verifiedOn: ""
  },
  {
    id: "CR-2025-0002",
    team: "Team Beta",
    project: "Line Follower Robot",
    leader: "Karthik",
    faculty: "Dr. Priya",
    issuedDate: "14 May 2025 11:00 AM",
    expectedReturn: "Project Completion",
    items: [
      { name: "Ultrasonic Sensor", issued: 3, alreadyReturned: 1, returnedToday: 2, good: 2, damaged: 0, missing: 0, remarks: "" },
      { name: "Lithium Ion Battery", issued: 5, alreadyReturned: 3, returnedToday: 2, good: 1, damaged: 0, missing: 1, remarks: "One battery core swelling exception reported." }
    ],
    status: "Pending",
    verifiedOn: ""
  },
  {
    id: "CR-2025-0003",
    team: "Team Delta",
    project: "Weather Station",
    leader: "Vignesh",
    faculty: "Dr. Kumar",
    issuedDate: "14 May 2025 02:00 PM",
    expectedReturn: "Project Completion",
    items: [
      { name: "Raspberry Pi 4", issued: 1, alreadyReturned: 1, returnedToday: 0, good: 0, damaged: 0, missing: 0, remarks: "" }
    ],
    status: "Completed",
    verifiedOn: "Project Completion"
  }
];

// ==========================================================================
// 2. STATE OBJECT
// ==========================================================================
const state = {
  currentPage: "page-tool-returns",
  lastActivePage: "page-tool-returns",
  activeCategory: "tool", // "tool" or "component"
  returns: JSON.parse(JSON.stringify(initialReturns)),
  componentReturns: JSON.parse(JSON.stringify(initialComponentReturns)),
  activeReturnId: null,
  returnFilters: {
    search: "",
    faculty: "All",
    status: "All",
    date: "2025-05-15"
  },
  activeExceptionTarget: null
};

// ==========================================================================
// 3. DOM ELEMENTS
// ==========================================================================
const DOM = {
  get sidebarMenuItems() { return document.querySelectorAll(".sidebar-menu .menu-item"); },
  get dropdownChevron() { return document.querySelector(".dropdown-chevron"); },
  get returnsDropdownParent() { return document.querySelector(".menu-item-dropdown"); },
  get pageTitle() { return document.getElementById("navbar-page-title"); },
  
  get pageToolReturns() { return document.getElementById("page-tool-returns"); },
  get pageVerifyReturn() { return document.getElementById("page-verify-return"); },
  get pageSuccessReturn() { return document.getElementById("page-success-return"); },
  get pageDummy() { return document.getElementById("page-dummy"); },
  get dummyTitle() { return document.getElementById("dummy-title"); },
  get dummyDesc() { return document.getElementById("dummy-desc"); },
  get btnBackToActive() { return document.getElementById("btn-back-to-active"); },

  get returnsQueueBody() { return document.getElementById("returns-queue-table-body"); },
  get verifyToolsBody() { return document.getElementById("verify-tools-table-body"); },
  get successExceptionsList() { return document.getElementById("success-exceptions-list"); },
  get returnSearchInput() { return document.getElementById("return-search-input"); },
  get returnFacultySelect() { return document.getElementById("return-faculty-select"); },
  get returnStatusSelect() { return document.getElementById("return-status-select"); },
  get returnDateInput() { return document.getElementById("return-date-input"); },
  get btnClearReturnFilters() { return document.getElementById("btn-clear-return-filters"); },
  get btnBackToQueueHeader() { return document.getElementById("btn-back-to-queue-header"); },
  get btnCancelVerification() { return document.getElementById("btn-cancel-verification"); },
  get btnCompleteVerification() { return document.getElementById("btn-complete-verification"); },
  get btnSuccessViewDetails() { return document.getElementById("btn-success-view-details"); },
  get btnSuccessBackQueue() { return document.getElementById("btn-success-back-queue"); },

  get modalMarkDamaged() { return document.getElementById("modal-mark-damaged"); },
  get modalMarkMissing() { return document.getElementById("modal-mark-missing"); },
  get modalConfirmVerification() { return document.getElementById("modal-confirm-verification"); },

  get toastContainer() { return document.getElementById("toast-container"); }
};

// ==========================================================================
// 4. NAVIGATION & VIEWS
// ==========================================================================
function showPage(pageId) {
  state.currentPage = pageId;
  
  if (DOM.pageToolReturns) DOM.pageToolReturns.classList.add("hidden");
  if (DOM.pageVerifyReturn) DOM.pageVerifyReturn.classList.add("hidden");
  if (DOM.pageSuccessReturn) DOM.pageSuccessReturn.classList.add("hidden");
  if (DOM.pageDummy) DOM.pageDummy.classList.add("hidden");
  
  DOM.sidebarMenuItems.forEach(item => item.classList.remove("active"));
  
  if (pageId === "page-tool-returns") {
    if (DOM.pageToolReturns) DOM.pageToolReturns.classList.remove("hidden");
    if (DOM.pageTitle) {
      DOM.pageTitle.textContent = state.activeCategory === "tool" ? "Return Status - Tools" : "Return Status - Components";
    }
    
    const returnsTrigger = document.querySelector('[data-target="returns-status"]');
    if (returnsTrigger) returnsTrigger.classList.add("active");
    
    // Highlight correct sub-menu link
    const activeSubTarget = state.activeCategory === "tool" ? "tool-returns" : "component-returns";
    const subMenuLink = document.querySelector(`.submenu-item[data-target="${activeSubTarget}"]`);
    if (subMenuLink) {
      document.querySelectorAll(".submenu-item").forEach(el => el.classList.remove("active"));
      subMenuLink.classList.add("active");
    }
    
    if (DOM.returnsDropdownParent) {
      DOM.returnsDropdownParent.classList.add("expanded");
    }
    
    state.lastActivePage = pageId;
    renderReturnsQueueTable();
  }
  else if (pageId === "page-verify-return") {
    if (DOM.pageVerifyReturn) DOM.pageVerifyReturn.classList.remove("hidden");
    if (DOM.pageTitle) DOM.pageTitle.textContent = "Verify Return Details";
    
    const returnsTrigger = document.querySelector('[data-target="returns-status"]');
    if (returnsTrigger) returnsTrigger.classList.add("active");
    
    renderVerifyReturnTable();
  }
  else if (pageId === "page-success-return") {
    if (DOM.pageSuccessReturn) DOM.pageSuccessReturn.classList.remove("hidden");
    if (DOM.pageTitle) DOM.pageTitle.textContent = "Receipt Verified";
    
    const returnsTrigger = document.querySelector('[data-target="returns-status"]');
    if (returnsTrigger) returnsTrigger.classList.add("active");
    
    renderSuccessReturnSummary();
  }
  else if (pageId.startsWith("dummy-")) {
    const sectionName = pageId.replace("dummy-", "");
    if (DOM.pageDummy) DOM.pageDummy.classList.remove("hidden");
    
    const titleFormatted = sectionName.split("-").map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(" ");
    if (DOM.pageTitle) DOM.pageTitle.textContent = titleFormatted;
    if (DOM.dummyTitle) DOM.dummyTitle.textContent = `${titleFormatted} Module`;
    if (DOM.dummyDesc) DOM.dummyDesc.textContent = `The "${titleFormatted}" lab module is currently under layout design for the Prototrack Lab Portal. Switch to the active "Tool Returns" screen to interact with the mock workspace.`;
    
    const targetMenu = document.querySelector(`[data-target="${sectionName}"]`);
    if (targetMenu) targetMenu.classList.add("active");
  }
}

// ==========================================================================
// 5. TOAST NOTIFICATION UTILITY
// ==========================================================================
function showToast(message, type = "success") {
  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  
  let iconSVG = "";
  if (type === "success") {
    iconSVG = `<svg class="toast-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>`;
  } else {
    iconSVG = `<svg class="toast-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;
  }

  toast.innerHTML = `
    ${iconSVG}
    <span>${message}</span>
  `;
  
  if (DOM.toastContainer) DOM.toastContainer.appendChild(toast);
  setTimeout(() => toast.classList.add("show"), 10);
  
  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// ==========================================================================
// 6. BUSINESS LOGIC & DATA HELPERS
// ==========================================================================
function getActiveDataset() {
  return state.activeCategory === "tool" ? state.returns : state.componentReturns;
}

function getActiveReturn() {
  const dataset = getActiveDataset();
  return dataset.find(r => r.id === state.activeReturnId);
}

function getFilteredReturns() {
  const dataset = getActiveDataset();
  return dataset.filter(ret => {
    const query = state.returnFilters.search.toLowerCase();
    const matchesSearch = !query || 
      ret.id.toLowerCase().includes(query) ||
      ret.team.toLowerCase().includes(query) ||
      ret.project.toLowerCase().includes(query) ||
      ret.leader.toLowerCase().includes(query) ||
      ret.items.some(item => item.name.toLowerCase().includes(query));

    const matchesFaculty = state.returnFilters.faculty === "All" || ret.faculty === state.returnFilters.faculty;
    const matchesStatus = state.returnFilters.status === "All" || ret.status === state.returnFilters.status;

    let matchesDate = true;
    if (state.activeCategory === "tool" && state.returnFilters.date && ret.expectedReturn) {
      const filterDateStr = state.returnFilters.date;
      const months = { "Jan":"01", "Feb":"02", "Mar":"03", "Apr":"04", "May":"05", "Jun":"06", "Jul":"07", "Aug":"08", "Sep":"09", "Oct":"10", "Nov":"11", "Dec":"12" };
      const parts = ret.expectedReturn.split(" ");
      if (parts.length >= 3) {
        const day = parts[0].padStart(2, "0");
        const month = months[parts[1]] || "01";
        const year = parts[2];
        const formattedExpected = `${year}-${month}-${day}`;
        matchesDate = (formattedExpected === filterDateStr);
      }
    }

    return matchesSearch && matchesFaculty && matchesStatus && matchesDate;
  });
}

function renderReturnsQueueTable() {
  const filtered = getFilteredReturns();
  if (!DOM.returnsQueueBody) return;
  DOM.returnsQueueBody.innerHTML = "";

  const dataset = getActiveDataset();
  const pendingCount = dataset.filter(r => r.status === "Pending").length;
  const completedCount = dataset.filter(r => r.status === "Completed").length;
  
  const kpiPending = document.getElementById("kpi-returns-pending");
  const kpiCompleted = document.getElementById("kpi-returns-completed");
  const kpiOutstanding = document.getElementById("kpi-returns-outstanding");
  const kpiExceptions = document.getElementById("kpi-returns-exceptions");

  if (kpiPending) kpiPending.textContent = pendingCount;
  if (kpiCompleted) kpiCompleted.textContent = completedCount;
  
  let totalOutstanding = 0;
  dataset.forEach(r => {
    r.items.forEach(item => {
      totalOutstanding += (item.issued - item.alreadyReturned);
    });
  });
  if (kpiOutstanding) kpiOutstanding.textContent = totalOutstanding;
  
  let totalExceptions = 0;
  dataset.forEach(r => {
    if (r.status === "Completed") {
      r.items.forEach(item => {
        if (item.damaged > 0 || item.missing > 0) {
          totalExceptions += (item.damaged + item.missing);
        }
      });
    }
  });
  if (kpiExceptions) kpiExceptions.textContent = totalExceptions;

  if (filtered.length === 0) {
    DOM.returnsQueueBody.innerHTML = `
      <tr>
        <td colspan="8" class="text-center text-muted" style="padding: 30px;">
          No ${state.activeCategory === "tool" ? "tool" : "component"} returns found matching filters.
        </td>
      </tr>
    `;
    const pagInfo = document.getElementById("returns-pagination-info");
    if (pagInfo) pagInfo.textContent = "Showing 0 to 0 of 0 entries";
    return;
  }

  filtered.forEach(ret => {
    const tr = document.createElement("tr");
    const itemsText = ret.items.map(i => {
      const remaining = i.issued - i.alreadyReturned;
      return `${i.name.split(" ")[0]} (${remaining})`;
    }).join(", ");

    const statusBadgeClass = ret.status === "Pending" ? "status-badge-pending" : "status-badge-completed";
    
    let actionBtnHTML = "";
    if (ret.status === "Pending") {
      actionBtnHTML = `<button class="btn btn-primary btn-sm btn-verify-ret" data-id="${ret.id}">Verify Return</button>`;
    } else {
      actionBtnHTML = `<button class="btn btn-outline btn-sm btn-view-success" data-id="${ret.id}">View Details</button>`;
    }

    tr.innerHTML = `
      <td><strong>${ret.id}</strong></td>
      <td>${ret.team}</td>
      <td>${ret.project}</td>
      <td>${ret.leader}</td>
      <td><span class="text-secondary">${itemsText}</span></td>
      <td>${ret.expectedReturn}</td>
      <td><span class="${statusBadgeClass}">${ret.status}</span></td>
      <td class="text-center">${actionBtnHTML}</td>
    `;

    const verifyBtn = tr.querySelector(".btn-verify-ret");
    if (verifyBtn) {
      verifyBtn.addEventListener("click", () => {
        state.activeReturnId = ret.id;
        showPage("page-verify-return");
      });
    }

    const viewBtn = tr.querySelector(".btn-view-success");
    if (viewBtn) {
      viewBtn.addEventListener("click", () => {
        state.activeReturnId = ret.id;
        showPage("page-success-return");
      });
    }

    DOM.returnsQueueBody.appendChild(tr);
  });

  const pagInfo = document.getElementById("returns-pagination-info");
  if (pagInfo) pagInfo.textContent = `Showing 1 to ${filtered.length} of ${filtered.length} entries`;
}

function renderVerifyReturnTable() {
  const ret = getActiveReturn();
  if (!ret) return;

  // Update breadcrumb and header text labels dynamically based on category
  const bCategory = document.getElementById("breadcrumb-category");
  const tHeader = document.getElementById("verify-table-item-header");
  const dModalLabel = document.getElementById("damaged-modal-item-label");
  const mModalLabel = document.getElementById("missing-modal-item-label");

  if (state.activeCategory === "tool") {
    if (bCategory) bCategory.textContent = "Tool Returns";
    if (tHeader) tHeader.textContent = "Tool";
    if (dModalLabel) dModalLabel.textContent = "Tool";
    if (mModalLabel) mModalLabel.textContent = "Tool";
  } else {
    if (bCategory) bCategory.textContent = "Component Returns";
    if (tHeader) tHeader.textContent = "Component";
    if (dModalLabel) dModalLabel.textContent = "Component";
    if (mModalLabel) mModalLabel.textContent = "Component";
  }

  const tTeam = document.getElementById("verify-meta-team");
  const tProj = document.getElementById("verify-meta-project");
  const tLead = document.getElementById("verify-meta-leader");
  const tFac = document.getElementById("verify-meta-faculty");
  const tIssue = document.getElementById("verify-meta-issuedate");
  const tExp = document.getElementById("verify-meta-expectdate");

  if (tTeam) tTeam.textContent = ret.team;
  if (tProj) tProj.textContent = ret.project;
  if (tLead) tLead.textContent = ret.leader;
  if (tFac) tFac.textContent = ret.faculty;
  if (tIssue) tIssue.textContent = ret.issuedDate;
  if (tExp) tExp.textContent = ret.expectedReturn;

  if (!DOM.verifyToolsBody) return;
  DOM.verifyToolsBody.innerHTML = "";

  ret.items.forEach((item, index) => {
    const tr = document.createElement("tr");
    const outstanding = item.issued - item.alreadyReturned - item.returnedToday;
    
    let detailsHTML = "-";
    if (item.damaged > 0) {
      const iconColor = item.remarks ? "color: var(--status-green);" : "color: var(--status-red);";
      detailsHTML = `
        <span class="exception-label-badge damaged">Damaged: ${item.damaged}</span>
        <button class="btn-edit-exception" data-index="${index}" data-type="damaged">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 14px; height: 14px; margin-left: 4px; ${iconColor}"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
        </button>
      `;
    } else if (item.missing > 0) {
      const iconColor = item.remarks ? "color: var(--status-green);" : "color: var(--status-orange);";
      detailsHTML = `
        <span class="exception-label-badge missing">Missing: ${item.missing}</span>
        <button class="btn-edit-exception" data-index="${index}" data-type="missing">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 14px; height: 14px; margin-left: 4px; ${iconColor}"><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></svg>
        </button>
      `;
    }

    const maxReturnedToday = item.issued - item.alreadyReturned;

    tr.innerHTML = `
      <td><strong>${item.name}</strong></td>
      <td class="text-right font-medium">${item.issued}</td>
      <td class="text-right text-secondary">${item.alreadyReturned}</td>
      <td class="text-center col-verify-qty"><input type="number" class="input-returned-today" min="0" max="${maxReturnedToday}" value="${item.returnedToday}"></td>
      <td class="text-center col-verify-qty"><input type="number" class="input-good" min="0" max="${item.returnedToday}" value="${item.good}"></td>
      <td class="text-center col-verify-qty"><input type="number" class="input-damaged" min="0" max="${item.returnedToday}" value="${item.damaged}"></td>
      <td class="text-center col-verify-qty"><input type="number" class="input-missing" min="0" max="${item.returnedToday}" value="${item.missing}"></td>
      <td class="text-right font-medium" id="outstanding-cell-${index}">${outstanding}</td>
      <td id="details-cell-${index}">${detailsHTML}</td>
    `;

    const inputRet = tr.querySelector(".input-returned-today");
    const inputGood = tr.querySelector(".input-good");
    const inputDamaged = tr.querySelector(".input-damaged");
    const inputMissing = tr.querySelector(".input-missing");

    inputRet.addEventListener("change", (e) => {
      let val = parseInt(e.target.value);
      const maxRet = item.issued - item.alreadyReturned;
      if (isNaN(val) || val < 0) val = 0;
      if (val > maxRet) val = maxRet;
      
      e.target.value = val;
      item.returnedToday = val;
      item.good = val;
      item.damaged = 0;
      item.missing = 0;
      item.remarks = "";

      renderVerifyReturnTable();
    });

    inputGood.addEventListener("change", (e) => {
      let val = parseInt(e.target.value);
      if (isNaN(val) || val < 0) val = 0;
      if (val > item.returnedToday) val = item.returnedToday;
      
      e.target.value = val;
      item.good = val;
      
      const diff = item.returnedToday - item.good;
      if (item.damaged + item.missing !== diff) {
        item.missing = diff;
        item.damaged = 0;
      }
      
      renderVerifyReturnTable();
    });

    inputDamaged.addEventListener("change", (e) => {
      let val = parseInt(e.target.value);
      const maxDamaged = item.returnedToday - item.good;
      if (isNaN(val) || val < 0) val = 0;
      if (val > maxDamaged) val = maxDamaged;
      
      e.target.value = val;
      item.damaged = val;
      item.missing = item.returnedToday - item.good - val;

      if (val > 0) {
        openRemarksModal(index, "damaged");
      }
      renderVerifyReturnTable();
    });

    inputMissing.addEventListener("change", (e) => {
      let val = parseInt(e.target.value);
      const maxMissing = item.returnedToday - item.good;
      if (isNaN(val) || val < 0) val = 0;
      if (val > maxMissing) val = maxMissing;
      
      e.target.value = val;
      item.missing = val;
      item.damaged = item.returnedToday - item.good - val;

      if (val > 0) {
        openRemarksModal(index, "missing");
      }
      renderVerifyReturnTable();
    });

    const editBtn = tr.querySelector(".btn-edit-exception");
    if (editBtn) {
      editBtn.addEventListener("click", () => {
        const type = editBtn.getAttribute("data-type");
        openRemarksModal(index, type);
      });
    }

    DOM.verifyToolsBody.appendChild(tr);
  });

  updateVerificationSummaryMetrics(ret);
}

function updateVerificationSummaryMetrics(ret) {
  let returnedToday = 0;
  let good = 0;
  let damaged = 0;
  let missing = 0;
  let outstanding = 0;
  let exceptions = 0;

  ret.items.forEach(item => {
    returnedToday += item.returnedToday;
    good += item.good;
    damaged += item.damaged;
    missing += item.missing;
    outstanding += (item.issued - item.alreadyReturned - item.returnedToday);
  });

  exceptions = damaged + missing;

  const sRet = document.getElementById("sum-returned-today");
  const sGood = document.getElementById("sum-good");
  const sDamaged = document.getElementById("sum-damaged");
  const sMissing = document.getElementById("sum-missing");
  const sOut = document.getElementById("sum-outstanding");
  const sExc = document.getElementById("sum-exceptions");

  if (sRet) sRet.textContent = returnedToday;
  if (sGood) sGood.textContent = good;
  if (sDamaged) sDamaged.textContent = damaged;
  if (sMissing) sMissing.textContent = missing;
  if (sOut) sOut.textContent = outstanding;
  if (sExc) sExc.textContent = exceptions;

  let allRemarksAdded = true;
  ret.items.forEach(item => {
    if ((item.damaged > 0 || item.missing > 0) && !item.remarks) {
      allRemarksAdded = false;
    }
  });

  if (DOM.btnCompleteVerification) {
    DOM.btnCompleteVerification.disabled = (returnedToday === 0) || !allRemarksAdded;
  }
}

function openRemarksModal(index, type) {
  const ret = getActiveReturn();
  if (!ret) return;
  
  const item = ret.items[index];
  state.activeExceptionTarget = { index, type };

  if (type === "damaged") {
    const mTool = document.getElementById("damaged-modal-tool");
    const mQty = document.getElementById("damaged-modal-qty");
    const mRemarks = document.getElementById("damaged-modal-remarks");
    if (mTool) mTool.value = item.name;
    if (mQty) mQty.value = item.damaged;
    if (mRemarks) mRemarks.value = item.remarks || "";
    if (DOM.modalMarkDamaged) DOM.modalMarkDamaged.classList.remove("hidden");
  } else {
    const mTool = document.getElementById("missing-modal-tool");
    const mQty = document.getElementById("missing-modal-qty");
    const mRemarks = document.getElementById("missing-modal-remarks");
    if (mTool) mTool.value = item.name;
    if (mQty) mQty.value = item.missing;
    if (mRemarks) mRemarks.value = item.remarks || "";
    if (DOM.modalMarkMissing) DOM.modalMarkMissing.classList.remove("hidden");
  }
}

function saveRemarks(type) {
  const ret = getActiveReturn();
  if (!ret || !state.activeExceptionTarget) return;

  const { index } = state.activeExceptionTarget;
  const item = ret.items[index];
  
  let remarksVal = "";
  if (type === "damaged") {
    const mRemarks = document.getElementById("damaged-modal-remarks");
    remarksVal = mRemarks ? mRemarks.value.trim() : "";
    if (!remarksVal) {
      showToast("Please enter remarks explaining the damage.", "error");
      return;
    }
    item.remarks = remarksVal;
    if (DOM.modalMarkDamaged) DOM.modalMarkDamaged.classList.add("hidden");
  } else {
    const mRemarks = document.getElementById("missing-modal-remarks");
    remarksVal = mRemarks ? mRemarks.value.trim() : "";
    if (!remarksVal) {
      showToast("Please enter remarks explaining the missing status.", "error");
      return;
    }
    item.remarks = remarksVal;
    if (DOM.modalMarkMissing) DOM.modalMarkMissing.classList.add("hidden");
  }

  showToast(`Saved remarks for ${item.name}!`);
  state.activeExceptionTarget = null;
  renderVerifyReturnTable();
}

function openConfirmVerificationModal() {
  const ret = getActiveReturn();
  if (!ret) return;

  let good = 0;
  let damaged = 0;
  let missing = 0;
  let outstanding = 0;
  
  ret.items.forEach(item => {
    good += item.good;
    damaged += item.damaged;
    missing += item.missing;
    outstanding += (item.issued - item.alreadyReturned - item.returnedToday);
  });

  const exceptions = damaged + missing;

  const cGood = document.getElementById("confirm-good-qty");
  const cDamaged = document.getElementById("confirm-damaged-qty");
  const cMissing = document.getElementById("confirm-missing-qty");
  const cOut = document.getElementById("confirm-outstanding-qty");
  const cExc = document.getElementById("confirm-exceptions-qty");

  if (cGood) cGood.textContent = good;
  if (cDamaged) cDamaged.textContent = damaged;
  if (cMissing) cMissing.textContent = missing;
  if (cOut) cOut.textContent = outstanding;
  if (cExc) cExc.textContent = exceptions;

  if (DOM.modalConfirmVerification) DOM.modalConfirmVerification.classList.remove("hidden");
}

function completeVerificationAndSave() {
  const ret = getActiveReturn();
  if (!ret) return;

  ret.status = "Completed";
  ret.items.forEach(item => {
    item.alreadyReturned += item.returnedToday;
  });

  if (DOM.modalConfirmVerification) DOM.modalConfirmVerification.classList.add("hidden");
  showToast(`Successfully verified and recorded return ${ret.id}!`);
  showPage("page-success-return");
}

function renderSuccessReturnSummary() {
  const ret = getActiveReturn();
  if (!ret) return;

  const sTeam = document.getElementById("succ-meta-team");
  const sProj = document.getElementById("succ-meta-project");
  const sLead = document.getElementById("succ-meta-leader");
  const sRetId = document.getElementById("succ-meta-returnid");
  const sVerOn = document.getElementById("succ-meta-verifiedon");

  if (sTeam) sTeam.textContent = ret.team;
  if (sProj) sProj.textContent = ret.project;
  if (sLead) sLead.textContent = ret.leader;
  if (sRetId) sRetId.textContent = ret.id;
  
  const now = new Date();
  const formatTime = now.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) + " " + 
                     now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  if (sVerOn) sVerOn.textContent = formatTime;

  let issued = 0;
  let already = 0;
  let today = 0;
  let good = 0;
  let damaged = 0;
  let missing = 0;
  let outstanding = 0;

  ret.items.forEach(item => {
    issued += item.issued;
    already += item.alreadyReturned - item.returnedToday;
    today += item.returnedToday;
    good += item.good;
    damaged += item.damaged;
    missing += item.missing;
    outstanding += (item.issued - item.alreadyReturned);
  });

  const exceptionsCount = damaged + missing;

  const scIssued = document.getElementById("succ-sum-issued");
  const scAlready = document.getElementById("succ-sum-already");
  const scToday = document.getElementById("succ-sum-today");
  const scGood = document.getElementById("succ-sum-good");
  const scDamaged = document.getElementById("succ-sum-damaged");
  const scMissing = document.getElementById("succ-sum-missing");
  const scOut = document.getElementById("succ-sum-outstanding");
  const scExc = document.getElementById("succ-sum-exceptions");

  if (scIssued) scIssued.textContent = issued;
  if (scAlready) scAlready.textContent = already;
  if (scToday) scToday.textContent = today;
  if (scGood) scGood.textContent = good;
  if (scDamaged) scDamaged.textContent = damaged;
  if (scMissing) scMissing.textContent = missing;
  if (scOut) scOut.textContent = outstanding;
  if (scExc) scExc.textContent = exceptionsCount;

  if (!DOM.successExceptionsList) return;
  DOM.successExceptionsList.innerHTML = "";
  let exIndex = 46;
  
  ret.items.forEach(item => {
    if (item.damaged > 0) {
      const card = document.createElement("div");
      card.className = "exception-mini-card";
      card.innerHTML = `
        <div class="exception-header-mini">
          <span>EX-2025-00${exIndex++}</span>
          <span class="exception-label-badge damaged">Damaged</span>
        </div>
        <div class="exception-meta-mini">${item.name} (Qty: ${item.damaged})</div>
        <div class="exception-remarks-mini">"${item.remarks}"</div>
      `;
      DOM.successExceptionsList.appendChild(card);
    }
    if (item.missing > 0) {
      const card = document.createElement("div");
      card.className = "exception-mini-card missing";
      card.innerHTML = `
        <div class="exception-header-mini">
          <span>EX-2025-00${exIndex++}</span>
          <span class="exception-label-badge missing">Missing</span>
        </div>
        <div class="exception-meta-mini">${item.name} (Qty: ${item.missing})</div>
        <div class="exception-remarks-mini">"${item.remarks}"</div>
      `;
      DOM.successExceptionsList.appendChild(card);
    }
  });

  if (exceptionsCount === 0) {
    DOM.successExceptionsList.innerHTML = `
      <div class="text-center text-muted" style="padding: 20px;">
        No exceptions created for this return.
      </div>
    `;
  }
}

// ==========================================================================
// 7. EVENT BINDINGS
// ==========================================================================
function switchTab(category) {
  state.activeCategory = category;
  
  // Update tab buttons
  const tabToolBtn = document.getElementById("tab-tool-returns");
  const tabCompBtn = document.getElementById("tab-component-returns");
  if (category === "tool") {
    if (tabToolBtn) tabToolBtn.classList.add("active");
    if (tabCompBtn) tabCompBtn.classList.remove("active");
  } else {
    if (tabToolBtn) tabToolBtn.classList.remove("active");
    if (tabCompBtn) tabCompBtn.classList.add("active");
  }
  
  // Update sidebar submenu active states
  const submenuItems = document.querySelectorAll(".submenu-item");
  submenuItems.forEach(item => {
    const target = item.getAttribute("data-target");
    if ((category === "tool" && target === "tool-returns") || 
        (category === "component" && target === "component-returns")) {
      item.classList.add("active");
    } else {
      item.classList.remove("active");
    }
  });

  // Toggle return date filter field visibility based on category
  const dateFilterField = document.getElementById("return-date-filter-field");
  if (dateFilterField) {
    if (category === "tool") {
      dateFilterField.style.display = "";
    } else {
      dateFilterField.style.display = "none";
    }
  }

  showPage("page-tool-returns");
}

function bindEvents() {
  DOM.sidebarMenuItems.forEach(item => {
    item.addEventListener("click", (e) => {
      const target = item.getAttribute("data-target");
      if (target === "returns-status") {
        e.preventDefault();
        DOM.returnsDropdownParent.classList.toggle("expanded");
      }
    });
  });

  // Submenu switches inside returns folder
  const submenuItems = document.querySelectorAll(".submenu-item");
  submenuItems.forEach(item => {
    item.addEventListener("click", (e) => {
      const target = item.getAttribute("data-target");
      if (target === "tool-returns") {
        e.preventDefault();
        switchTab("tool");
      } else if (target === "component-returns") {
        e.preventDefault();
        switchTab("component");
      }
    });
  });

  // Tab button bindings
  const tabToolBtn = document.getElementById("tab-tool-returns");
  const tabCompBtn = document.getElementById("tab-component-returns");
  if (tabToolBtn) {
    tabToolBtn.addEventListener("click", () => switchTab("tool"));
  }
  if (tabCompBtn) {
    tabCompBtn.addEventListener("click", () => switchTab("component"));
  }

  const applyReturnFilters = () => {
    state.returnFilters.search = DOM.returnSearchInput ? DOM.returnSearchInput.value : "";
    state.returnFilters.faculty = DOM.returnFacultySelect ? DOM.returnFacultySelect.value : "All";
    state.returnFilters.status = DOM.returnStatusSelect ? DOM.returnStatusSelect.value : "All";
    state.returnFilters.date = DOM.returnDateInput ? DOM.returnDateInput.value : "";
    renderReturnsQueueTable();
  };

  if (DOM.returnSearchInput) DOM.returnSearchInput.addEventListener("input", applyReturnFilters);
  if (DOM.returnFacultySelect) DOM.returnFacultySelect.addEventListener("change", applyReturnFilters);
  if (DOM.returnStatusSelect) DOM.returnStatusSelect.addEventListener("change", applyReturnFilters);
  if (DOM.returnDateInput) DOM.returnDateInput.addEventListener("change", applyReturnFilters);

  if (DOM.btnClearReturnFilters) {
    DOM.btnClearReturnFilters.addEventListener("click", () => {
      if (DOM.returnSearchInput) DOM.returnSearchInput.value = "";
      if (DOM.returnFacultySelect) DOM.returnFacultySelect.value = "All";
      if (DOM.returnStatusSelect) DOM.returnStatusSelect.value = "All";
      if (DOM.returnDateInput) DOM.returnDateInput.value = "2025-05-15";
      
      state.returnFilters.search = "";
      state.returnFilters.faculty = "All";
      state.returnFilters.status = "All";
      state.returnFilters.date = "2025-05-15";
      
      renderReturnsQueueTable();
      showToast("Return filters cleared.");
    });
  }

  if (DOM.btnBackToQueueHeader) {
    DOM.btnBackToQueueHeader.addEventListener("click", () => showPage("page-tool-returns"));
  }
  
  if (DOM.btnCancelVerification) {
    DOM.btnCancelVerification.addEventListener("click", () => {
      showPage("page-tool-returns");
      showToast("Verification cancelled.");
    });
  }

  if (DOM.btnCompleteVerification) {
    DOM.btnCompleteVerification.addEventListener("click", () => openConfirmVerificationModal());
  }

  document.querySelectorAll(".modal-close-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      if (DOM.modalMarkDamaged) DOM.modalMarkDamaged.classList.add("hidden");
      if (DOM.modalMarkMissing) DOM.modalMarkMissing.classList.add("hidden");
      if (DOM.modalConfirmVerification) DOM.modalConfirmVerification.classList.add("hidden");
      state.activeExceptionTarget = null;
    });
  });

  const btnCancelDamaged = document.getElementById("btn-cancel-damaged-modal");
  if (btnCancelDamaged) {
    btnCancelDamaged.addEventListener("click", () => cancelRemarksModal("damaged"));
  }

  const btnCancelMissing = document.getElementById("btn-cancel-missing-modal");
  if (btnCancelMissing) {
    btnCancelMissing.addEventListener("click", () => cancelRemarksModal("missing"));
  }

  const btnCancelConfirm = document.getElementById("btn-cancel-confirm-modal");
  if (btnCancelConfirm) {
    btnCancelConfirm.addEventListener("click", () => {
      if (DOM.modalConfirmVerification) DOM.modalConfirmVerification.classList.add("hidden");
    });
  }

  const btnSaveDamaged = document.getElementById("btn-save-damaged-modal");
  if (btnSaveDamaged) {
    btnSaveDamaged.addEventListener("click", () => saveRemarks("damaged"));
  }

  const btnSaveMissing = document.getElementById("btn-save-missing-modal");
  if (btnSaveMissing) {
    btnSaveMissing.addEventListener("click", () => saveRemarks("missing"));
  }

  const btnSaveConfirm = document.getElementById("btn-save-confirm-modal");
  if (btnSaveConfirm) {
    btnSaveConfirm.addEventListener("click", () => completeVerificationAndSave());
  }

  if (DOM.btnSuccessBackQueue) {
    DOM.btnSuccessBackQueue.addEventListener("click", () => showPage("page-tool-returns"));
  }
  
  if (DOM.btnSuccessViewDetails) {
    DOM.btnSuccessViewDetails.addEventListener("click", () => showToast("Already showing verification receipt details."));
  }

  // Logout / Sign Out toast hook
  const logoutBtn = document.querySelector(".logout-btn");
  if (logoutBtn) {
    logoutBtn.addEventListener("click", (e) => {
      e.preventDefault();
      showToast("Sign Out triggered. In a live system, this terminates the user session.", "error");
    });
  }

  function cancelRemarksModal(type) {
    if (state.activeExceptionTarget) {
      const { index } = state.activeExceptionTarget;
      const ret = getActiveReturn();
      if (ret) {
        const item = ret.items[index];
        if (type === "damaged") {
          item.damaged = 0;
        } else {
          item.missing = 0;
        }
        item.good = item.returnedToday - item.damaged - item.missing;
      }
    }
    if (DOM.modalMarkDamaged) DOM.modalMarkDamaged.classList.add("hidden");
    if (DOM.modalMarkMissing) DOM.modalMarkMissing.classList.add("hidden");
    state.activeExceptionTarget = null;
    renderVerifyReturnTable();
  }
}

// ==========================================================================
// 8. APP INITIALIZATION
// ==========================================================================
function initializeApp() {
  bindEvents();
  
  // Update timestamp to current local time dynamically
  const tStamp = document.getElementById("return-timestamp-val");
  if (tStamp) {
    const now = new Date();
    const options = { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' };
    tStamp.textContent = now.toLocaleDateString('en-GB', options).replace(/,/g, ' -');
  }

  // Route to the correct tab based on query parameters
  const urlParams = new URLSearchParams(window.location.search);
  const tabParam = urlParams.get('tab');
  if (tabParam === 'component') {
    switchTab("component");
  } else {
    switchTab("tool");
  }
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initializeApp);
} else {
  initializeApp();
}

/**
 * ==========================================================================
 * RAPID PROTOTYPING LAB DASHBOARD - APPLICATION CONTROLLER
 * ==========================================================================
 */

// --------------------------------------------------------------------------
// 1. MOCK DATABASE (INITIAL STATE)
// --------------------------------------------------------------------------
const INITIAL_TEAMS = [
  {
    id: "T-2026-001",
    name: "Team Alpha",
    project: "Smart Irrigation System",
    leader: "Surendhan",
    faculty: "Dr. Kumar",
    department: "Mechanical",
    stage: "Prototyping",
    members: [
      { name: "Surendhan", initial: "S", color: "#1D4ED8" },
      { name: "Aswin", initial: "A", color: "#10B981" },
      { name: "Bala", initial: "B", color: "#F59E0B" },
      { name: "Divya", initial: "D", color: "#EC4899" },
      { name: "Elango", initial: "E", color: "#8B5CF6" }
    ],
    resources: [
      { id: "R1", name: "Soldering Iron", type: "Tool", qtyIssued: 2, qtyReturned: 1, dueDate: "14 Jul 2026", status: "Overdue" },
      { id: "R2", name: "Screwdriver Set", type: "Tool", qtyIssued: 3, qtyReturned: 3, dueDate: "14 Jul 2026", status: "Returned" },
      { id: "R3", name: "Plier", type: "Tool", qtyIssued: 2, qtyReturned: 1, dueDate: "14 Jul 2026", status: "Overdue" },
      { id: "R4", name: "Multimeter", type: "Tool", qtyIssued: 1, qtyReturned: 0, dueDate: "14 Jul 2026", status: "Overdue" },
      { id: "R5", name: "Cutting Plier", type: "Tool", qtyIssued: 2, qtyReturned: 0, dueDate: "14 Jul 2026", status: "Returned" },
      { id: "R6", name: "Arduino Uno", type: "Component", qtyIssued: 5, qtyReturned: 0, dueDate: "18 Aug 2026", status: "Returned" },
      { id: "R7", name: "IR Sensor", type: "Component", qtyIssued: 10, qtyReturned: 0, dueDate: "18 Aug 2026", status: "Overdue" }
    ],
    bookings: [
      { id: "B1", equipment: "3D Printer", date: "14 Jul 2026", timeSlot: "09:00 AM - 11:00 AM", purpose: "Prototype Print", status: "Upcoming" },
      { id: "B2", equipment: "Laser Cutter", date: "15 Jul 2026", timeSlot: "11:30 AM - 01:30 PM", purpose: "Enclosure Cutting", status: "Confirmed" },
      { id: "B3", equipment: "CNC Machine", date: "16 Jul 2026", timeSlot: "02:00 PM - 04:00 PM", purpose: "Acrylic Parts", status: "Confirmed" },
      { id: "B4", equipment: "3D Printer", date: "16 Jul 2026", timeSlot: "04:30 PM - 06:30 PM", purpose: "Prototype Print", status: "Pending" },
      { id: "B5", equipment: "Laser Cutter", date: "17 Jul 2026", timeSlot: "10:00 AM - 12:00 PM", purpose: "Panel Cutting", status: "Pending" }
    ],
    returns: [
      { id: "RT-208", items: [{name: "Arduino Uno", qty: 2}, {name: "ESP32 Dev Board", qty: 1}, {name: "Breadboard", qty: 1}], date: "15 Jul 2026", time: "10:25 AM", status: "Need Approval" },
      { id: "RT-207", items: [{name: "Servo Motor SG90", qty: 2}, {name: "DHT22 Temperature Sensor", qty: 1}], date: "14 Jul 2026", time: "03:40 PM", status: "Approved" },
      { id: "RT-206", items: [{name: "Multimeter", qty: 1}, {name: "Soldering Iron", qty: 1}, {name: "Jumper Wires", qty: 10}, {name: "Heat Shrink", qty: 2}, {name: "Insulation Tape", qty: 1}], date: "13 Jul 2026", time: "11:15 AM", status: "Approved" },
      { id: "RT-203", items: [{name: "Plier", qty: 1}], date: "09 Jul 2026", time: "11:00 AM", status: "Approved" },
      { id: "RT-202", items: [{name: "Screwdriver Set", qty: 1}], date: "08 Jul 2026", time: "04:15 PM", status: "Approved" },
      { id: "RT-201", items: [{name: "Multimeter", qty: 1}], date: "07 Jul 2026", time: "10:00 AM", status: "Approved" }
    ],
    requests: [
      { id: "CR-104", items: [{name: "Arduino Uno", qty: 2}, {name: "ESP32 Dev Board", qty: 1}, {name: "Breadboard", qty: 1}, {name: "Jumper Wires", qty: 5}], date: "15 Jul 2026", time: "10:30 AM", status: "Need Approval" },
      { id: "CR-103", items: [{name: "Servo Motor SG90", qty: 2}, {name: "DHT22 Temperature Sensor", qty: 1}, {name: "USB Cable", qty: 1}], date: "14 Jul 2026", time: "03:15 PM", status: "Approved" },
      { id: "CR-102", items: [{name: "Multimeter", qty: 1}, {name: "Soldering Iron", qty: 1}, {name: "Jumper Wires", qty: 10}, {name: "Heat Shrink", qty: 2}, {name: "Insulation Tape", qty: 1}], date: "13 Jul 2026", time: "11:20 AM", status: "Approved" },
      { id: "CR-101", items: [{name: "ESP32 Dev Board", qty: 1}, {name: "DHT22", qty: 1}, {name: "LCD 16x2", qty: 1}, {name: "Resistor Set", qty: 1}], date: "12 Jul 2026", time: "09:45 AM", status: "Approved" },
      { id: "CR-100", items: [{name: "Arduino Uno R3", qty: 1}, {name: "Breadboard", qty: 1}], date: "11 Jul 2026", time: "02:10 PM", status: "Rejected" },
      { id: "CR-099", items: [{name: "Plier", qty: 1}], date: "10 Jul 2026", time: "11:30 AM", status: "Approved" },
      { id: "CR-098", items: [{name: "Screwdriver Set", qty: 1}], date: "09 Jul 2026", time: "04:00 PM", status: "Approved" },
      { id: "CR-097", items: [{name: "Arduino Uno", qty: 1}], date: "08 Jul 2026", time: "10:30 AM", status: "Approved" },
      { id: "CR-096", items: [{name: "IR Sensor", qty: 5}], date: "07 Jul 2026", time: "02:00 PM", status: "Approved" },
      { id: "CR-095", items: [{name: "Plier", qty: 2}], date: "06 Jul 2026", time: "11:00 AM", status: "Approved" },
      { id: "CR-094", items: [{name: "LED Pack", qty: 1}], date: "05 Jul 2026", time: "09:30 AM", status: "Approved" },
      { id: "CR-093", items: [{name: "Arduino Mega", qty: 1}], date: "04 Jul 2026", time: "03:45 PM", status: "Approved" }
    ],
    issues: [
      { id: "I1", description: "Defective Soldering Iron tip", date: "14 Jul 2026", severity: "Low", status: "Open" },
      { id: "I2", description: "3D Printer filament jam", date: "13 Jul 2026", severity: "High", status: "Open" },
      { id: "I3", description: "CNC Machine motor overheating", date: "12 Jul 2026", severity: "Critical", status: "Closed" }
    ]
  },
  {
    id: "T-2026-002",
    name: "Team Delta",
    project: "Autonomous Drone",
    leader: "Aravind",
    faculty: "Dr. Kumar",
    department: "Aerospace",
    stage: "Testing",
    members: [
      { name: "Aravind", initial: "Ar", color: "#10B981" },
      { name: "Priya", initial: "P", color: "#EC4899" },
      { name: "Gopal", initial: "G", color: "#F59E0B" }
    ],
    resources: [
      { id: "R201", name: "LiPo Battery Charger", type: "Tool", qtyIssued: 1, qtyReturned: 1, dueDate: "14 Jul 2026", status: "Returned" },
      { id: "R202", name: "Brushless Motor", type: "Component", qtyIssued: 4, qtyReturned: 0, dueDate: "10 Aug 2026", status: "Returned" },
      { id: "R203", name: "Carbon Fiber Frame", type: "Component", qtyIssued: 1, qtyReturned: 0, dueDate: "10 Aug 2026", status: "Returned" },
      { id: "R204", name: "Hex Wrench", type: "Tool", qtyIssued: 2, qtyReturned: 0, dueDate: "14 Jul 2026", status: "Overdue" }
    ],
    bookings: [
      { id: "B201", equipment: "CNC Machine", date: "14 Jul 2026", timeSlot: "01:00 PM - 03:00 PM", purpose: "Frame Milling", status: "Confirmed" }
    ],
    returns: [
      { id: "RT-308", items: [{name: "Hex Wrench", qty: 2}], date: "15 Jul 2026", time: "11:45 AM", status: "Need Approval" },
      { id: "RT-307", items: [{name: "LiPo Battery Charger", qty: 1}], date: "14 Jul 2026", time: "04:10 PM", status: "Approved" }
    ],
    requests: [
      { id: "CR-204", items: [{name: "LiPo Battery", qty: 2}, {name: "ESC 40A", qty: 4}], date: "14 Jul 2026", time: "02:15 PM", status: "Need Approval" },
      { id: "CR-203", items: [{name: "Brushless Motor", qty: 4}], date: "13 Jul 2026", time: "10:30 AM", status: "Approved" },
      { id: "CR-202", items: [{name: "Heat Shrink Gun", qty: 1}], date: "12 Jul 2026", time: "09:00 AM", status: "Approved" },
      { id: "CR-201", items: [{name: "Carbon Fiber Frame", qty: 1}], date: "11 Jul 2026", time: "03:45 PM", status: "Rejected" }
    ],
    issues: [
      { id: "I201", description: "ESC burned during testing", date: "14 Jul 2026", severity: "High", status: "Open" }
    ]
  },
  {
    id: "T-2026-003",
    name: "Team Phoenix",
    project: "Robotic Arm",
    leader: "Kavin",
    faculty: "Dr. Ramesh",
    department: "Robotics",
    stage: "Design",
    members: [
      { name: "Kavin", initial: "K", color: "#8B5CF6" },
      { name: "Meera", initial: "M", color: "#1D4ED8" },
      { name: "Siddharth", initial: "Si", color: "#10B981" },
      { name: "Nisha", initial: "N", color: "#F59E0B" }
    ],
    resources: [
      { id: "R301", name: "Allen Key Set", type: "Tool", qtyIssued: 1, qtyReturned: 1, dueDate: "14 Jul 2026", status: "Returned" },
      { id: "R302", name: "MG996R Servo Motor", type: "Component", qtyIssued: 6, qtyReturned: 0, dueDate: "15 Aug 2026", status: "Returned" },
      { id: "R303", name: "Screws & Nuts Box", type: "Component", qtyIssued: 1, qtyReturned: 0, dueDate: "15 Aug 2026", status: "Returned" }
    ],
    bookings: [
      { id: "B301", equipment: "3D Printer", date: "15 Jul 2026", timeSlot: "10:00 AM - 12:00 PM", purpose: "Joint Design Iteration", status: "Pending" }
    ],
    returns: [
      { id: "RT-408", items: [{name: "MG90S Servo", qty: 1}], date: "15 Jul 2026", time: "09:30 AM", status: "Need Approval" },
      { id: "RT-407", items: [{name: "Allen Key Set", qty: 1}], date: "14 Jul 2026", time: "11:20 AM", status: "Approved" }
    ],
    requests: [
      { id: "CR-304", items: [{name: "MG996R Servo Motor", qty: 6}, {name: "Servo Shield", qty: 1}], date: "14 Jul 2026", time: "11:00 AM", status: "Need Approval" },
      { id: "CR-303", items: [{name: "Screws & Nuts Box", qty: 1}], date: "13 Jul 2026", time: "03:15 PM", status: "Approved" },
      { id: "CR-302", items: [{name: "Breadboard", qty: 2}], date: "12 Jul 2026", time: "10:00 AM", status: "Approved" },
      { id: "CR-301", items: [{name: "Arduino Mega", qty: 1}], date: "11 Jul 2026", time: "04:30 PM", status: "Approved" }
    ],
    issues: []
  },
  {
    id: "T-2026-004",
    name: "Team Sigma",
    project: "Solar Tracker",
    leader: "Harish",
    faculty: "Dr. Ramesh",
    department: "Electronics",
    stage: "Prototyping",
    members: [
      { name: "Harish", initial: "H", color: "#EC4899" },
      { name: "Ram", initial: "R", color: "#8B5CF6" },
      { name: "Suresh", initial: "Su", color: "#1D4ED8" }
    ],
    resources: [
      { id: "R401", name: "Soldering Station", type: "Tool", qtyIssued: 1, qtyReturned: 1, dueDate: "14 Jul 2026", status: "Returned" },
      { id: "R402", name: "Solar Panel 10W", type: "Component", qtyIssued: 2, qtyReturned: 0, dueDate: "12 Aug 2026", status: "Returned" },
      { id: "R403", name: "Lead Acid Battery", type: "Component", qtyIssued: 1, qtyReturned: 0, dueDate: "12 Aug 2026", status: "Overdue" },
      { id: "R404", name: "Wire Stripper", type: "Tool", qtyIssued: 1, qtyReturned: 0, dueDate: "14 Jul 2026", status: "Overdue" }
    ],
    bookings: [
      { id: "B401", equipment: "Laser Cutter", date: "14 Jul 2026", timeSlot: "04:00 PM - 06:00 PM", purpose: "Solar Mount Cutting", status: "Confirmed" }
    ],
    returns: [
      { id: "RT-508", items: [{name: "LDR Sensors", qty: 2}], date: "15 Jul 2026", time: "02:10 PM", status: "Need Approval" },
      { id: "RT-507", items: [{name: "Soldering Station", qty: 1}], date: "14 Jul 2026", time: "09:00 AM", status: "Approved" }
    ],
    requests: [
      { id: "CR-404", items: [{name: "Solar Panel 10W", qty: 2}], date: "14 Jul 2026", time: "01:25 PM", status: "Need Approval" },
      { id: "CR-403", items: [{name: "LDR Sensors", qty: 4}], date: "13 Jul 2026", time: "11:40 AM", status: "Approved" },
      { id: "CR-402", items: [{name: "Lead Acid Battery", qty: 1}], date: "12 Jul 2026", time: "10:15 AM", status: "Rejected" },
      { id: "CR-401", items: [{name: "Wire Stripper", qty: 1}], date: "11 Jul 2026", time: "03:00 PM", status: "Rejected" }
    ],
    issues: [
      { id: "I401", description: "LDR sensor sensitivity issue", date: "14 Jul 2026", severity: "Low", status: "Open" }
    ]
  },
  {
    id: "T-2026-005",
    name: "Team Innovate",
    project: "AI Assistant",
    leader: "Keerthana",
    faculty: "Dr. Meena",
    department: "Computer Science",
    stage: "Development",
    members: [
      { name: "Keerthana", initial: "Ke", color: "#F59E0B" },
      { name: "Varun", initial: "V", color: "#10B981" },
      { name: "Ezhil", initial: "Ez", color: "#EC4899" },
      { name: "Ganga", initial: "Ga", color: "#8B5CF6" }
    ],
    resources: [
      { id: "R501", name: "Raspberry Pi 4", type: "Component", qtyIssued: 2, qtyReturned: 1, dueDate: "25 Aug 2026", status: "Returned" },
      { id: "R502", name: "USB Microphone", type: "Tool", qtyIssued: 1, qtyReturned: 0, dueDate: "14 Jul 2026", status: "Overdue" },
      { id: "R503", name: "HDMI Cable", type: "Tool", qtyIssued: 2, qtyReturned: 2, dueDate: "14 Jul 2026", status: "Returned" }
    ],
    bookings: [
      { id: "B501", equipment: "3D Printer", date: "14 Jul 2026", timeSlot: "11:00 AM - 01:00 PM", purpose: "Pi Case Enclosure", status: "Confirmed" }
    ],
    returns: [
      { id: "RT-608", items: [{name: "USB Microphone", qty: 1}], date: "15 Jul 2026", time: "01:50 PM", status: "Need Approval" },
      { id: "RT-607", items: [{name: "HDMI Cable", qty: 2}], date: "14 Jul 2026", time: "10:30 AM", status: "Approved" }
    ],
    requests: [
      { id: "CR-503", items: [{name: "Pi Camera Module", qty: 1}, {name: "USB Microphone", qty: 1}], date: "14 Jul 2026", time: "04:00 PM", status: "Approved" },
      { id: "CR-502", items: [{name: "HDMI Cable", qty: 2}], date: "13 Jul 2026", time: "11:15 AM", status: "Approved" },
      { id: "CR-501", items: [{name: "Raspberry Pi 4", qty: 2}], date: "12 Jul 2026", time: "09:00 AM", status: "Rejected" }
    ],
    issues: []
  }
];

// --------------------------------------------------------------------------
// 2. STATE MANAGER
// --------------------------------------------------------------------------
const appState = {
  currentView: 'landing', // 'landing' | 'overview' | 'resources' | 'bookings' | 'requests' | 'issues'
  selectedTeamId: 'T-2026-001',
  recentlyViewedIds: ['T-2026-001', 'T-2026-002', 'T-2026-003'],
  
  // Landing View state variables
  filters: {
    search: '',
    faculty: 'All',
    department: 'All',
    resources: {
      search: '',
      status: 'All',
      type: 'All'
    },
    bookings: {
      equipment: 'All',
      status: 'All'
    },
    requests: {
      type: 'All',
      status: 'All',
      search: ''
    },
    issues: {
      severity: 'All',
      status: 'All'
    }
  },
  pagination: {
    landing: { page: 1, limit: 5 },
    resources: { page: 1, limit: 5 },
    bookings: { page: 1, limit: 5 },
    requests: { page: 1, limit: 5 },
    issues: { page: 1, limit: 5 }
  },

  // Active sub-tabs
  returnsSubTab: 'All',
  requestsSubTab: 'All',
  returnsSegment: 'requests', // 'requests' | 'completed'
  requestsSegment: 'requests', // 'requests' | 'completed'

  // Master database
  teams: [...INITIAL_TEAMS]
};

// --------------------------------------------------------------------------
// 3. UI RENDERING CORE
// --------------------------------------------------------------------------

// Initializer
document.addEventListener('DOMContentLoaded', () => {
  initApp();
});

function initApp() {
  // Bind Static Events
  setupEventBindings();
  
  // Refresh & Render initial state
  refreshAppMetrics();
  renderLandingView();
  renderRecentlyViewed();
  
  // Load Lucide Icons
  lucide.createIcons();
}

// Global Metrics Evaluator
function refreshAppMetrics() {
  let totalOverdue = 0;
  let totalPending = 0;
  let totalBookingsToday = 0;
  let totalDefects = 0;

  appState.teams.forEach(team => {
    // 1. Tool Return Overdue (number of teams that have at least one overdue item)
    const hasOverdue = team.resources.some(r => r.status === 'Overdue');
    if (hasOverdue) totalOverdue++;

    // 2. Pending Requests (total sum of pending requests across all teams)
    const pendingCount = team.requests.filter(q => q.status === 'Pending' || q.status === 'Need Approval').length;
    totalPending += pendingCount;

    // 3. Bookings Today (bookings on '14 Jul 2026' or just count of today's bookings)
    const bookingsToday = team.bookings.filter(b => b.date === '14 Jul 2026').length;
    totalBookingsToday += bookingsToday;

    // 4. Open Defects (open issues status)
    const openIssues = team.issues.filter(i => i.status === 'Open').length;
    totalDefects += openIssues;
  });

  // Write variables back into DOM
  const overdueElem = document.getElementById('count-overdue');
  if (overdueElem) overdueElem.innerText = totalOverdue;
  const pendingElem = document.getElementById('count-pending');
  if (pendingElem) pendingElem.innerText = totalPending;
  const bookingsElem = document.getElementById('count-bookings');
  if (bookingsElem) bookingsElem.innerText = totalBookingsToday;
  
  const defectsElem = document.getElementById('count-defects');
  if (defectsElem) defectsElem.innerText = totalDefects;
}

// --------------------------------------------------------------------------
// 4. ROUTER ENGINE (VIEW DISPATCHER)
// --------------------------------------------------------------------------
function switchView(targetView, selectedTeamId = null) {
  // Fade active transition effect
  const panels = document.querySelectorAll('.view-panel');
  panels.forEach(p => p.classList.remove('active'));

  if (selectedTeamId) {
    appState.selectedTeamId = selectedTeamId;
    
    // Add to recently viewed if not already in front
    appState.recentlyViewedIds = appState.recentlyViewedIds.filter(id => id !== selectedTeamId);
    appState.recentlyViewedIds.unshift(selectedTeamId);
    if (appState.recentlyViewedIds.length > 3) {
      appState.recentlyViewedIds = appState.recentlyViewedIds.slice(0, 3);
    }
    renderRecentlyViewed();

    // Reset detailed view filters on team change
    appState.filters.resources.search = '';
    appState.filters.resources.status = 'All';
    appState.filters.resources.type = 'All';
    appState.filters.bookings.equipment = 'All';
    appState.filters.bookings.status = 'All';
    appState.filters.requests.search = '';
    appState.filters.requests.status = 'All';
    appState.filters.requests.type = 'All';
    appState.filters.issues.severity = 'All';
    appState.filters.issues.status = 'All';

    // Reset pagination to first page
    appState.pagination.resources.page = 1;
    appState.pagination.bookings.page = 1;
    appState.pagination.requests.page = 1;
    appState.pagination.issues.page = 1;

    // Reset sub-tabs and segments
    appState.returnsSubTab = 'All';
    appState.requestsSubTab = 'All';
    appState.returnsSegment = 'requests';
    appState.requestsSegment = 'requests';

    // Reset form elements in DOM if they exist
    const retSearch = document.getElementById('returns-search');
    if (retSearch) retSearch.value = '';
    const retStatus = document.getElementById('returns-filter-status');
    if (retStatus) retStatus.value = 'All';
    const retType = document.getElementById('returns-filter-type');
    if (retType) retType.value = 'All';
    
    const reqSearch = document.getElementById('requests-search');
    if (reqSearch) reqSearch.value = '';
    const reqStatus = document.getElementById('requests-filter-status');
    if (reqStatus) reqStatus.value = 'All';
    const reqType = document.getElementById('requests-filter-type');
    if (reqType) reqType.value = 'All';

    const bEquip = document.getElementById('bookings-filter-equip');
    if (bEquip) bEquip.value = 'All';
    const bStatus = document.getElementById('bookings-filter-status');
    if (bStatus) bStatus.value = 'All';
    const iSev = document.getElementById('issues-filter-severity');
    if (iSev) iSev.value = 'All';
    const iStatus = document.getElementById('issues-filter-status');
    if (iStatus) iStatus.value = 'All';
  }

  appState.currentView = targetView;
  const viewTitle = document.getElementById('view-title');
  const viewSubtitle = document.getElementById('view-subtitle');
  if (viewSubtitle) viewSubtitle.style.display = 'none'; // Hide badge to match design exactly

  if (targetView === 'landing') {
    document.getElementById('view-landing').classList.add('active');
    viewTitle.innerText = "Team Workspace";
    renderLandingView();
  } 
  else if (targetView === 'overview') {
    document.getElementById('view-overview').classList.add('active');
    viewTitle.innerText = "Team Workspace Overview";
    renderOverviewView();
  } 
  else {
    // Sub-view Tab tables (resources, bookings, requests, issues)
    document.getElementById('view-details-tables').classList.add('active');
    
    // Select correct tab in Details Section and update title
    activateDetailTab(targetView);
  }

}

// Global Redirect Function for Teammate Modules
function redirectToPage(pageId) {
  // 1. Remove active class from all view panels
  const panels = document.querySelectorAll('.view-panel');
  panels.forEach(p => p.classList.remove('active'));

  // 2. Select target sidebar link and add active class, removing from others
  const sidebarItems = document.querySelectorAll('.sidebar-menu .menu-item');
  sidebarItems.forEach(item => {
    item.classList.remove('active');
    if (item.getAttribute('data-page') === pageId) {
      item.classList.add('active');
    }
  });

  // 3. Update top header title
  const viewTitle = document.getElementById('view-title');
  const pageNameMap = {
    'dashboard': 'Dashboard',
    'inventory': 'Inventory Management',
    'material-requests': 'Material Requisitions',
    'equipment-booking': 'Equipment Booking',
    'material-returns': 'Material Returns',
    'equipment-tracking': 'Equipment Tracking',
    'defect-tracking': 'Defect Tracking',
    'reports': 'Reports & Analytics',
    'settings': 'Settings'
  };
  
  const pageTitle = pageNameMap[pageId] || 'System Module';
  if (viewTitle) {
    viewTitle.innerText = pageTitle;
  }

  // 4. Update the placeholder view details
  const placeholderIcon = document.getElementById('placeholder-icon');
  const placeholderTitle = document.getElementById('placeholder-title');
  const placeholderDescription = document.getElementById('placeholder-description');
  const placeholderIconWrap = document.getElementById('placeholder-icon-wrap');

  // Set page icon and details
  const pageDetails = {
    'dashboard': {
      icon: 'layout-dashboard',
      bg: 'var(--color-info-bg)',
      color: 'var(--color-info)',
      desc: 'The Lab Dashboard provides overview statistics, booking volume, pending tasks, and lab alerts. This interface is managed externally by teammate modules.'
    },
    'inventory': {
      icon: 'package',
      bg: 'hsl(142, 65%, 95%)',
      color: 'var(--color-success)',
      desc: 'The Lab Inventory Management system monitors tool usage, component stock levels, and automated parts ordering. This page is managed externally by teammate modules.'
    },
    'material-requests': {
      icon: 'git-pull-request',
      bg: 'var(--color-pending-bg)',
      color: 'var(--color-pending)',
      desc: 'The Material Requisitions workflow handles approval and issuing of new sensors, microcontroller boards, and tools to project teams. This page is managed externally by teammate modules.'
    },
    'equipment-booking': {
      icon: 'calendar',
      bg: 'var(--color-info-bg)',
      color: 'var(--color-info)',
      desc: 'The Equipment Booking schedule coordinates 3D Printer, Laser Cutter, and CNC Machine time slots. This page is managed externally by teammate modules.'
    },
    'material-returns': {
      icon: 'rotate-ccw',
      bg: 'var(--color-danger-bg)',
      color: 'var(--color-danger)',
      desc: 'The Material Returns portal handles the logging, inspection, and return processing of tools and components back to the stock room. This page is managed externally by teammate modules.'
    },
    'equipment-tracking': {
      icon: 'map-pin',
      bg: 'hsl(190, 70%, 95%)',
      color: 'hsl(190, 80%, 45%)',
      desc: 'The Equipment Tracking tracker traces portable testing tools, multimeters, and logic analyzers using Bluetooth beacons. This page is managed externally by teammate modules.'
    },
    'defect-tracking': {
      icon: 'alert-triangle',
      bg: 'var(--color-danger-bg)',
      color: 'var(--color-danger)',
      desc: 'The Defect Tracking ticketing system logs broken tools, machine malfunctions, and filament jams for immediate technician review. This page is managed externally by teammate modules.'
    },
    'reports': {
      icon: 'bar-chart-2',
      bg: 'hsl(270, 60%, 95%)',
      color: 'hsl(270, 70%, 50%)',
      desc: 'Reports and Analytics aggregates data on machine utilization rates, popular tools, and material consumption rates. This page is managed externally by teammate modules.'
    },
    'settings': {
      icon: 'settings',
      bg: 'hsl(215, 30%, 91%)',
      color: 'var(--color-text-main)',
      desc: 'System Configuration, technician assignment permissions, notification rules, and database tools. This page is managed externally by teammate modules.'
    }
  };

  const details = pageDetails[pageId] || {
    icon: 'arrow-up-right',
    bg: 'var(--color-brand-blue-light)',
    color: 'var(--color-brand-blue)',
    desc: 'This page is managed externally by another system component. Redirecting to your teammate\'s interface.'
  };

  if (placeholderIcon) {
    placeholderIcon.setAttribute('data-lucide', details.icon);
  }
  if (placeholderIconWrap) {
    placeholderIconWrap.style.backgroundColor = details.bg;
    placeholderIconWrap.style.color = details.color;
  }
  if (placeholderTitle) {
    placeholderTitle.innerText = pageTitle;
  }
  if (placeholderDescription) {
    placeholderDescription.innerText = details.desc;
  }

  // Show placeholder panel
  document.getElementById('view-external-placeholder').classList.add('active');

  // Trigger Lucide icon render for new icons
  lucide.createIcons();

  // Scroll to top
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// --------------------------------------------------------------------------
// 5. LANDING PAGE RENDERING
// --------------------------------------------------------------------------
function highlightText(text, query) {
  if (text === undefined || text === null) return '';
  const textStr = String(text);
  if (!query || !query.trim()) return textStr;
  
  // Escape regex special characters
  const escapedQuery = query.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
  const regex = new RegExp(`(${escapedQuery})`, 'gi');
  return textStr.replace(regex, '<mark class="search-highlight">$1</mark>');
}

function renderLandingView() {
  const tbody = document.getElementById('teams-table-body');
  tbody.innerHTML = '';

  // Get current filters
  const { search, faculty } = appState.filters;

  // Filter teams array
  const filteredTeams = appState.teams.filter(team => {
    // Multivariable Search match
    const matchesSearch = 
      team.name.toLowerCase().includes(search.toLowerCase()) ||
      team.project.toLowerCase().includes(search.toLowerCase()) ||
      team.leader.toLowerCase().includes(search.toLowerCase()) ||
      team.id.toLowerCase().includes(search.toLowerCase());

    const matchesFaculty = (faculty === 'All' || team.faculty === faculty);

    return matchesSearch && matchesFaculty;
  });

  // Paginate list
  const pgState = appState.pagination.landing;
  const totalItems = filteredTeams.length;
  const totalPages = Math.ceil(totalItems / pgState.limit) || 1;
  
  if (pgState.page > totalPages) pgState.page = totalPages;
  
  const startIndex = (pgState.page - 1) * pgState.limit;
  const endIndex = Math.min(startIndex + pgState.limit, totalItems);
  const paginatedTeams = filteredTeams.slice(startIndex, endIndex);

  // Render rows
  if (paginatedTeams.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--color-text-muted); padding: 2rem;">No matching teams found. Try adjusting your filters.</td></tr>`;
  } else {
    paginatedTeams.forEach(team => {
      const tr = document.createElement('tr');

      const highlightedId = highlightText(team.id, search);
      const highlightedProject = highlightText(team.project, search);
      const highlightedLeader = highlightText(team.leader, search);
      const highlightedFaculty = highlightText(team.faculty, search);

      tr.innerHTML = `
        <td><strong>${highlightedId}</strong></td>
        <td>${highlightedProject}</td>
        <td>${highlightedLeader}</td>
        <td>${highlightedFaculty}</td>
        <td>
          <a href="#" class="action-link" data-id="${team.id}">
            <i data-lucide="folder-open"></i> Open Workspace
          </a>
        </td>
      `;
      tbody.appendChild(tr);
    });

    // Row Click navigation mapping
    tbody.querySelectorAll('.action-link').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const teamId = btn.getAttribute('data-id');
        switchView('overview', teamId);
      });
    });
  }

  // Update Pagination Info
  document.getElementById('teams-pagination-info').innerText = 
    totalItems > 0 
      ? `Showing ${startIndex + 1} to ${endIndex} of ${totalItems} teams`
      : `Showing 0 to 0 of 0 teams`;

  // Draw Page Navigation numbers
  const pagesContainer = document.getElementById('teams-pagination-pages');
  pagesContainer.innerHTML = '';
  
  for (let i = 1; i <= totalPages; i++) {
    const pageTag = document.createElement('span');
    pageTag.className = `pagination-page-tag ${i === pgState.page ? 'active' : ''}`;
    pageTag.innerText = i;
    pageTag.addEventListener('click', () => {
      pgState.page = i;
      renderLandingView();
      lucide.createIcons();
    });
    pagesContainer.appendChild(pageTag);
  }

  // Button States
  document.getElementById('teams-prev-btn').disabled = (pgState.page === 1);
  document.getElementById('teams-next-btn').disabled = (pgState.page === totalPages);
}

// Draw Recently Viewed row
function renderRecentlyViewed() {
  const container = document.getElementById('recently-viewed-container');
  container.innerHTML = '';

  appState.recentlyViewedIds.forEach(id => {
    const team = appState.teams.find(t => t.id === id);
    if (!team) return;

    let iconClass = 'alpha';
    if (team.name.includes('Delta')) iconClass = 'delta';
    if (team.name.includes('Phoenix')) iconClass = 'phoenix';
    if (team.name.includes('Sigma')) iconClass = 'sigma';
    if (team.name.includes('Innovate')) iconClass = 'innovate';

    const card = document.createElement('div');
    card.className = 'recent-team-card';
    card.innerHTML = `
      <div class="recent-icon-wrap ${iconClass}">
        <i data-lucide="folder-open"></i>
      </div>
      <div class="recent-info">
        <h4>${team.id}</h4>
        <p>${team.project}</p>
      </div>
    `;
    card.addEventListener('click', () => {
      switchView('overview', team.id);
    });
    container.appendChild(card);
  });
}

// --------------------------------------------------------------------------
// 6. TEAM OVERVIEW PAGE (TEAM DETAILS)
// --------------------------------------------------------------------------
function renderOverviewView() {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  if (!team) return;

  // 1. Text metadata binds
  document.getElementById('detail-team-name').innerText = team.id;
  document.getElementById('detail-project-name').innerText = team.project;
  document.getElementById('detail-team-id').innerText = team.id;
  document.getElementById('detail-team-leader').innerText = team.leader;
  document.getElementById('detail-team-faculty').innerText = team.faculty;

  // 2. Member avatars list
  const avatarsWrap = document.getElementById('detail-team-members');
  avatarsWrap.innerHTML = '';
  
  team.members.forEach((m, idx) => {
    if (idx < 3) {
      const avatar = document.createElement('div');
      avatar.className = 'member-avatar';
      avatar.style.backgroundColor = m.color;
      avatar.innerText = m.initial;
      avatar.title = m.name;
      avatarsWrap.appendChild(avatar);
    }
  });
  
  if (team.members.length > 3) {
    const overflow = document.createElement('div');
    overflow.className = 'member-avatar overflow-badge';
    overflow.innerText = `+${team.members.length - 3}`;
    overflow.title = `${team.members.slice(3).map(m => m.name).join(', ')}`;
    avatarsWrap.appendChild(overflow);
  }

  // 3. Quick Summary count indicators (Calculated dynamically)
  const upbookings = team.bookings.filter(b => b.status === 'Upcoming' || b.status === 'Confirmed').length;
  document.getElementById('sum-bookings-count').innerText = upbookings;
  document.getElementById('sum-bookings-sub').innerText = `${upbookings} Scheduled`;

  const totalTools = team.resources.filter(r => r.type === 'Tool');
  const overdueTools = totalTools.filter(r => r.status === 'Overdue').length;
  document.getElementById('sum-tools-count').innerText = totalTools.length;
  document.getElementById('sum-tools-sub').innerText = `${overdueTools} Overdue`;
  document.getElementById('sum-tools-sub').className = overdueTools > 0 ? "mini-card-sub text-danger" : "mini-card-sub text-info";

  const totalComps = team.resources.filter(r => r.type === 'Component');
  const pendingReturn = totalComps.filter(r => r.status === 'Overdue').length; // let's label overdue components as pending return
  document.getElementById('sum-components-count').innerText = totalComps.length;
  document.getElementById('sum-components-sub').innerText = `${pendingReturn} Overdue`;
  document.getElementById('sum-components-sub').className = pendingReturn > 0 ? "mini-card-sub text-warning" : "mini-card-sub text-info";

  const pendingRequests = team.requests.filter(q => q.status === 'Pending' || q.status === 'Need Approval').length;
  document.getElementById('sum-requests-count').innerText = pendingRequests;
  document.getElementById('sum-requests-sub').innerText = `${pendingRequests} Pending`;
  document.getElementById('sum-requests-sub').className = pendingRequests > 0 ? "mini-card-sub text-warning" : "mini-card-sub text-info";
}

// --------------------------------------------------------------------------
// 7. SUB-PAGES & TABBED TABLES
// --------------------------------------------------------------------------
function activateDetailTab(tabId) {
  // Content panels activation
  const panels = document.querySelectorAll('.tab-panel');
  panels.forEach(p => p.classList.remove('active'));
  
  const targetPanel = document.getElementById(`tab-${tabId}`);
  if (targetPanel) {
    targetPanel.classList.add('active');
  }

  // Update dynamic header title
  const viewTitle = document.getElementById('view-title');
  if (viewTitle) {
    if (tabId === 'resources') {
      viewTitle.innerText = "Material Returns";
    } else if (tabId === 'requests') {
      viewTitle.innerText = "Material Requisitions";
    } else if (tabId === 'bookings') {
      viewTitle.innerText = "Equipment Bookings";
    } else if (tabId === 'issues') {
      viewTitle.innerText = "Issues & Defect Tickets";
    }
  }

  // Draw correct table rows
  if (tabId === 'resources') renderResourcesTable();
  if (tabId === 'bookings') renderBookingsTable();
  if (tabId === 'requests') renderRequestsTable();
  if (tabId === 'issues') renderIssuesTable();
}
function getItemType(itemName) {
  const tools = [
    "soldering iron", "screwdriver set", "plier", "multimeter", "cutting plier",
    "charger", "wrench", "key set", "heat shrink gun", "stripper", "station",
    "microphone", "hdmi cable", "solder lead roll"
  ];
  const name = itemName.toLowerCase();
  for (const tool of tools) {
    if (name.includes(tool)) return "Tool";
  }
  return "Component";
}

/* Tab 3: RESOURCES TABLE */
function getTeamReturns(team) {
  if (team.returns) return team.returns;
  
  // Fallback: generate mock return tickets from team's resources
  const mockReturns = [];
  const returnedItems = team.resources.filter(r => r.status === 'Returned');
  
  if (returnedItems.length > 0) {
    mockReturns.push({
      id: "RT-207",
      items: returnedItems.map(r => ({ name: r.name, qty: r.qtyReturned || 1 })),
      date: "14 Jul 2026",
      time: "03:40 PM",
      status: "Approved"
    });
  }
  
  // Default dummy returns to make it look full
  mockReturns.push({
    id: "RT-208",
    items: [{ name: "Arduino Uno", qty: 2 }, { name: "ESP32 Dev Board", qty: 1 }, { name: "Breadboard", qty: 1 }],
    date: "15 Jul 2026",
    time: "10:25 AM",
    status: "Need Approval"
  });
  mockReturns.push({
    id: "RT-206",
    items: [{ name: "Multimeter", qty: 1 }, { name: "Soldering Iron", qty: 1 }, { name: "Jumper Wires", qty: 10 }, { name: "Heat Shrink", qty: 2 }, { name: "Insulation Tape", qty: 1 }],
    date: "13 Jul 2026",
    time: "11:15 AM",
    status: "Approved"
  });
  mockReturns.push({
    id: "RT-203",
    items: [{ name: "Plier", qty: 1 }],
    date: "09 Jul 2026",
    time: "11:00 AM",
    status: "Approved"
  });
  mockReturns.push({
    id: "RT-202",
    items: [{ name: "Screwdriver Set", qty: 1 }],
    date: "08 Jul 2026",
    time: "04:15 PM",
    status: "Approved"
  });
  mockReturns.push({
    id: "RT-201",
    items: [{ name: "Multimeter", qty: 1 }],
    date: "07 Jul 2026",
    time: "10:00 AM",
    status: "Approved"
  });
  
  // Sort returns by ID descending
  mockReturns.sort((a, b) => b.id.localeCompare(a.id));
  
  team.returns = mockReturns;
  return mockReturns;
}

/* Tab 3: RESOURCES TABLE (Material Returns) */
function renderResourcesTable() {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  if (!team) return;

  const returns = getTeamReturns(team);
  const segment = appState.returnsSegment;

  // Update dynamic titles
  const returnsHeaderTitle = document.getElementById('returns-header-title');
  if (returnsHeaderTitle) {
    returnsHeaderTitle.innerText = `Material Returns – ${team.name}`;
  }
  const returnsSidebarTeam = document.getElementById('returns-sidebar-team');
  if (returnsSidebarTeam) {
    returnsSidebarTeam.innerText = team.name;
  }

  // Synchronize segment switcher active buttons
  const returnsSwitcher = document.getElementById('returns-segment-switcher');
  if (returnsSwitcher) {
    returnsSwitcher.querySelectorAll('.segment-btn').forEach(btn => {
      if (btn.getAttribute('data-segment') === segment) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
  }

  // Update dynamically the table header labels
  const thead = document.getElementById('returns-table-head');
  if (thead) {
    if (segment === 'requests') {
      thead.innerHTML = `
        <tr>
          <th>Request ID</th>
          <th>Items to Verify</th>
          <th>Submitted On</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      `;
    } else {
      thead.innerHTML = `
        <tr>
          <th>Return ID</th>
          <th>Returned Items</th>
          <th>Returned On</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      `;
    }
  }

  // Filter parameters
  const searchQuery = appState.filters.resources.search.toLowerCase();
  const filterStatusSelect = appState.filters.resources.status;
  const filterTypeSelect = appState.filters.resources.type || 'All';

  // Calculate counts dynamically based on search and type filters
  const metricsBase = returns.filter(ret => {
    // 1. Segment filter
    const matchesSegment = (segment === 'requests') 
      ? (ret.status === 'Need Approval')
      : (ret.status === 'Approved');

    // 2. Type select filter
    const matchesType = (filterTypeSelect === 'All' || 
                         (filterTypeSelect === 'Tool' && ret.items.some(item => getItemType(item.name) === 'Tool')) ||
                         (filterTypeSelect === 'Component' && ret.items.some(item => getItemType(item.name) === 'Component')));

    // 3. Search filter
    const itemsStr = ret.items.map(item => item.name).join(' ').toLowerCase();
    const matchesSearch = ret.id.toLowerCase().includes(searchQuery) || itemsStr.includes(searchQuery);

    return matchesSegment && matchesType && matchesSearch;
  });

  const totalCount = metricsBase.length;
  const needCount = metricsBase.filter(r => r.status === 'Need Approval').length;
  const approvedCount = metricsBase.filter(r => r.status === 'Approved').length;

  const filteredReturns = returns.filter(ret => {
    // 1. Segment filter
    const matchesSegment = (segment === 'requests') 
      ? (ret.status === 'Need Approval')
      : (ret.status === 'Approved');
    
    // 2. Status select filter
    const matchesSelect = (filterStatusSelect === 'All' || ret.status === filterStatusSelect);

    // 3. Type select filter
    const matchesType = (filterTypeSelect === 'All' || 
                         (filterTypeSelect === 'Tool' && ret.items.some(item => getItemType(item.name) === 'Tool')) ||
                         (filterTypeSelect === 'Component' && ret.items.some(item => getItemType(item.name) === 'Component')));

    // 4. Search filter
    const itemsStr = ret.items.map(item => item.name).join(' ').toLowerCase();
    const matchesSearch = ret.id.toLowerCase().includes(searchQuery) || itemsStr.includes(searchQuery);

    return matchesSegment && matchesSelect && matchesType && matchesSearch;
  });

  // Paginate list
  const pgState = appState.pagination.resources;
  const totalItems = filteredReturns.length;
  const totalPages = Math.ceil(totalItems / pgState.limit) || 1;
  if (pgState.page > totalPages) pgState.page = totalPages;

  const start = (pgState.page - 1) * pgState.limit;
  const end = Math.min(start + pgState.limit, totalItems);
  const pageData = filteredReturns.slice(start, end);

  // Render table rows
  const tbody = document.getElementById('returns-table-body');
  if (tbody) {
    tbody.innerHTML = '';

    if (pageData.length === 0) {
      tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--color-text-muted); padding: 2rem;">No returns in this segment.</td></tr>`;
    } else {
      pageData.forEach(ret => {
        const tr = document.createElement('tr');
        
        // Items Details Text
        const itemsCount = ret.items.reduce((sum, item) => sum + item.qty, 0);
        const itemsListStr = ret.items.map(item => `${item.name} (${item.qty}x)`).join(', ');
        
        // Status Badge class mapping
        let badgeClass = 'outline-orange';
        if (ret.status === 'Approved') badgeClass = 'outline-green';

        // Action Buttons specifically tailored for Requests vs Returned segments
        let actionBtnHtml = '';
        if (segment === 'requests') {
          actionBtnHtml = `<button class="btn-table-primary btn-review-return" data-id="${ret.id}">Verify Return</button>`;
        } else {
          actionBtnHtml = `<button class="btn-table-secondary btn-view-return" data-id="${ret.id}">View Details</button>`;
        }

        tr.innerHTML = `
          <td><strong>${highlightText(ret.id, appState.filters.resources.search)}</strong></td>
          <td>
            <div class="items-cell-wrap">
              <div class="items-cell-icon purple-theme">
                <i data-lucide="package"></i>
              </div>
              <div class="items-cell-details">
                <span class="items-cell-title">${itemsCount} Items</span>
                <span class="items-cell-subtext" title="${itemsListStr}">${highlightText(itemsListStr, appState.filters.resources.search)}</span>
              </div>
            </div>
          </td>
          <td>
            <div>
              <div class="date-cell-wrap">
                <i data-lucide="calendar"></i>
                <span>${ret.date}</span>
              </div>
              <span class="date-cell-time">${ret.time}</span>
            </div>
          </td>
          <td>
            <span class="badge-status ${badgeClass}">${ret.status}</span>
          </td>
          <td>
            <div class="actions-cell-group">
              ${actionBtnHtml}
            </div>
          </td>
        `;
        tbody.appendChild(tr);
      });

      // Bind action buttons
      tbody.querySelectorAll('.btn-review-return').forEach(btn => {
        btn.addEventListener('click', () => {
          const retId = btn.getAttribute('data-id');
          openReviewReturnModal(retId);
        });
      });

      tbody.querySelectorAll('.btn-view-return').forEach(btn => {
        btn.addEventListener('click', () => {
          const retId = btn.getAttribute('data-id');
          openViewReturnModal(retId);
        });
      });
    }
  }

  // Draw Pagination Bar
  renderTablePaginationControls('resources', totalItems, start, end, 'returns-pagination', renderResourcesTable);

  // Update Right Summary Sidebar Metrics
  const formattedCount = (val) => String(val).padStart(2, '0');

  const metricStack = document.getElementById('returns-metric-stack');
  if (metricStack) {
    metricStack.innerHTML = `
      <div class="summary-metric-tile purple-theme clickable-metric-tile" id="tile-ret-total">
        <div class="metric-tile-icon"><i data-lucide="file-text"></i></div>
        <div class="metric-tile-info">
          <span class="metric-tile-label">Total Returns</span>
          <span class="metric-tile-value">${formattedCount(totalCount)}</span>
        </div>
      </div>
      <div class="summary-metric-tile orange-theme clickable-metric-tile" id="tile-ret-need">
        <div class="metric-tile-icon"><i data-lucide="clock"></i></div>
        <div class="metric-tile-info">
          <span class="metric-tile-label">Need Approval</span>
          <span class="metric-tile-value">${formattedCount(needCount)}</span>
        </div>
      </div>
      <div class="summary-metric-tile green-theme clickable-metric-tile" id="tile-ret-approved">
        <div class="metric-tile-icon"><i data-lucide="check-circle"></i></div>
        <div class="metric-tile-info">
          <span class="metric-tile-label">Approved</span>
          <span class="metric-tile-value">${formattedCount(approvedCount)}</span>
        </div>
      </div>
    `;

    // Bind click handlers to summary metric cards for dynamic component breakdowns
    const totalRetTile = document.getElementById('tile-ret-total');
    if (totalRetTile) {
      totalRetTile.addEventListener('click', () => {
        showComponentBreakdown("Total Returns", metricsBase);
      });
    }
    const needRetTile = document.getElementById('tile-ret-need');
    if (needRetTile) {
      needRetTile.addEventListener('click', () => {
        showComponentBreakdown("Need Approval Returns", metricsBase.filter(r => r.status === 'Need Approval'));
      });
    }
    const approvedRetTile = document.getElementById('tile-ret-approved');
    if (approvedRetTile) {
      approvedRetTile.addEventListener('click', () => {
        showComponentBreakdown("Approved Returns", metricsBase.filter(r => r.status === 'Approved'));
      });
    }
  }

  // Reload icons
  lucide.createIcons();
}

/* Tab 4: BOOKINGS TABLE */
function renderBookingsTable() {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  if (!team) return;

  // Filter list
  const filteredBookings = team.bookings.filter(b => {
    // Equipment filter
    const matchesEquip = (appState.filters.bookings.equipment === 'All' || b.equipment === appState.filters.bookings.equipment);
    // Status filter
    const matchesStatus = (appState.filters.bookings.status === 'All' || b.status === appState.filters.bookings.status);

    return matchesEquip && matchesStatus;
  });

  const pgState = appState.pagination.bookings;
  const totalItems = filteredBookings.length;
  const totalPages = Math.ceil(totalItems / pgState.limit) || 1;
  if (pgState.page > totalPages) pgState.page = totalPages;

  const start = (pgState.page - 1) * pgState.limit;
  const end = Math.min(start + pgState.limit, totalItems);
  const pageData = filteredBookings.slice(start, end);

  const tbody = document.getElementById('bookings-table-body');
  tbody.innerHTML = '';

  if (pageData.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--color-text-muted); padding: 1.5rem;">No equipment bookings recorded.</td></tr>`;
  } else {
    pageData.forEach(b => {
      const tr = document.createElement('tr');
      
      let statusClass = 'info';
      if (b.status === 'Confirmed') statusClass = 'success';
      if (b.status === 'Pending') statusClass = 'pending';

      tr.innerHTML = `
        <td><strong>${b.equipment}</strong></td>
        <td>${b.date}</td>
        <td>${b.timeSlot}</td>
        <td>${b.purpose}</td>
        <td><span class="badge-status ${statusClass}">${b.status}</span></td>
        <td>
          <button class="btn-table-action btn-redirect-page" data-target="equipment-booking" style="background-color: var(--color-brand-blue-light); color: var(--color-brand-blue); border-color: transparent;">Go to Bookings</button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    tbody.querySelectorAll('.btn-redirect-page').forEach(btn => {
      btn.addEventListener('click', () => {
        const target = btn.getAttribute('data-target');
        redirectToPage(target);
      });
    });
  }

  renderTablePaginationControls('bookings', totalItems, start, end, 'bookings-pagination', renderBookingsTable);
}

function getTeamRequests(team) {
  if (team.requests && team.requests.length > 0 && team.requests[0].items) {
    return team.requests;
  }
  
  // Fallback: convert original requests to the new format
  const mockRequests = [];
  
  // Default dummy requests to make it look full
  mockRequests.push({
    id: "CR-104",
    items: [{ name: "Arduino Uno", qty: 2 }, { name: "ESP32 Dev Board", qty: 1 }, { name: "Breadboard", qty: 1 }, { name: "Jumper Wires", qty: 5 }],
    date: "15 Jul 2026",
    time: "10:30 AM",
    status: "Need Approval"
  });
  mockRequests.push({
    id: "CR-103",
    items: [{ name: "Servo Motor SG90", qty: 2 }, { name: "DHT22 Temperature Sensor", qty: 1 }, { name: "USB Cable", qty: 1 }],
    date: "14 Jul 2026",
    time: "03:15 PM",
    status: "Approved"
  });
  mockRequests.push({
    id: "CR-102",
    items: [{ name: "Multimeter", qty: 1 }, { name: "Soldering Iron", qty: 1 }, { name: "Jumper Wires", qty: 10 }, { name: "Heat Shrink", qty: 2 }, { name: "Insulation Tape", qty: 1 }],
    date: "13 Jul 2026",
    time: "11:20 AM",
    status: "Approved"
  });
  mockRequests.push({
    id: "CR-101",
    items: [{ name: "ESP32 Dev Board", qty: 1 }, { name: "DHT22", qty: 1 }, { name: "LCD 16x2", qty: 1 }, { name: "Resistor Set", qty: 1 }],
    date: "12 Jul 2026",
    time: "09:45 AM",
    status: "Approved"
  });
  mockRequests.push({
    id: "CR-100",
    items: [{ name: "Arduino Uno R3", qty: 1 }, { name: "Breadboard", qty: 1 }],
    date: "11 Jul 2026",
    time: "02:10 PM",
    status: "Rejected"
  });
  mockRequests.push({
    id: "CR-099",
    items: [{ name: "Plier", qty: 1 }],
    date: "10 Jul 2026",
    time: "11:30 AM",
    status: "Approved"
  });
  mockRequests.push({
    id: "CR-098",
    items: [{ name: "Screwdriver Set", qty: 1 }],
    date: "09 Jul 2026",
    time: "04:00 PM",
    status: "Approved"
  });
  mockRequests.push({
    id: "CR-097",
    items: [{ name: "Arduino Uno", qty: 1 }],
    date: "08 Jul 2026",
    time: "10:30 AM",
    status: "Approved"
  });
  mockRequests.push({
    id: "CR-096",
    items: [{ name: "IR Sensor", qty: 5 }],
    date: "07 Jul 2026",
    time: "02:00 PM",
    status: "Approved"
  });
  mockRequests.push({
    id: "CR-095",
    items: [{ name: "Plier", qty: 2 }],
    date: "06 Jul 2026",
    time: "11:00 AM",
    status: "Approved"
  });
  mockRequests.push({
    id: "CR-094",
    items: [{ name: "LED Pack", qty: 1 }],
    date: "05 Jul 2026",
    time: "09:30 AM",
    status: "Approved"
  });
  mockRequests.push({
    id: "CR-093",
    items: [{ name: "Arduino Mega", qty: 1 }],
    date: "04 Jul 2026",
    time: "03:45 PM",
    status: "Approved"
  });
  
  // Sort requests by ID descending
  mockRequests.sort((a, b) => b.id.localeCompare(a.id));
  
  team.requests = mockRequests;
  return mockRequests;
}

/* Tab 5: REQUESTS TABLE (Material Requisitions) */
function renderRequestsTable() {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  if (!team) return;

  const requests = getTeamRequests(team);
  const segment = appState.requestsSegment;

  // Update dynamic titles
  const requestsHeaderTitle = document.getElementById('requests-header-title');
  if (requestsHeaderTitle) {
    requestsHeaderTitle.innerText = `Material Requisitions – ${team.name}`;
  }
  const requestsSidebarTeam = document.getElementById('requests-sidebar-team');
  if (requestsSidebarTeam) {
    requestsSidebarTeam.innerText = team.name;
  }

  // Synchronize segment switcher active buttons
  const requestsSwitcher = document.getElementById('requests-segment-switcher');
  if (requestsSwitcher) {
    requestsSwitcher.querySelectorAll('.segment-btn').forEach(btn => {
      if (btn.getAttribute('data-segment') === segment) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
  }

  // Update dynamically the table header labels
  const thead = document.getElementById('requests-table-head');
  if (thead) {
    if (segment === 'requests') {
      thead.innerHTML = `
        <tr>
          <th>Requisition ID</th>
          <th>Requested Items</th>
          <th>Requested On</th>
          <th>Status</th>
          <th>Action</th>
        </tr>
      `;
    } else {
      thead.innerHTML = `
        <tr>
          <th>Handover ID</th>
          <th>Handed Over Items</th>
          <th>Handed Over On</th>
          <th>Authorized By</th>
          <th>Action</th>
        </tr>
      `;
    }
  }

  // Filter parameters
  const searchQuery = appState.filters.requests.search.toLowerCase();
  const filterStatusSelect = appState.filters.requests.status;
  const filterTypeSelect = appState.filters.requests.type || 'All';

  // Calculate counts dynamically based on search and type filters
  const metricsBase = requests.filter(req => {
    // 1. Segment filter
    const matchesSegment = (segment === 'requests') 
      ? (req.status === 'Need Approval' || req.status === 'Rejected')
      : (req.status === 'Approved');

    // 2. Type select filter
    const matchesType = (filterTypeSelect === 'All' || 
                         (filterTypeSelect === 'Tool' && req.items.some(item => getItemType(item.name) === 'Tool')) ||
                         (filterTypeSelect === 'Component' && req.items.some(item => getItemType(item.name) === 'Component')));

    // 3. Search filter
    const itemsStr = req.items.map(item => item.name).join(' ').toLowerCase();
    const matchesSearch = req.id.toLowerCase().includes(searchQuery) || itemsStr.includes(searchQuery);

    return matchesSegment && matchesType && matchesSearch;
  });

  const totalCount = metricsBase.length;
  const needCount = metricsBase.filter(r => r.status === 'Need Approval').length;
  const approvedCount = metricsBase.filter(r => r.status === 'Approved').length;
  const rejectedCount = metricsBase.filter(r => r.status === 'Rejected').length;

  const filteredRequests = requests.filter(req => {
    // 1. Segment filter
    const matchesSegment = (segment === 'requests') 
      ? (req.status === 'Need Approval' || req.status === 'Rejected')
      : (req.status === 'Approved');
    
    // 2. Status select filter
    const matchesSelect = (filterStatusSelect === 'All' || req.status === filterStatusSelect);

    // 3. Type select filter
    const matchesType = (filterTypeSelect === 'All' || 
                         (filterTypeSelect === 'Tool' && req.items.some(item => getItemType(item.name) === 'Tool')) ||
                         (filterTypeSelect === 'Component' && req.items.some(item => getItemType(item.name) === 'Component')));

    // 4. Search filter
    const itemsStr = req.items.map(item => item.name).join(' ').toLowerCase();
    const matchesSearch = req.id.toLowerCase().includes(searchQuery) || itemsStr.includes(searchQuery);

    return matchesSegment && matchesSelect && matchesType && matchesSearch;
  });

  // Paginate list
  const pgState = appState.pagination.requests;
  const totalItems = filteredRequests.length;
  const totalPages = Math.ceil(totalItems / pgState.limit) || 1;
  if (pgState.page > totalPages) pgState.page = totalPages;

  const start = (pgState.page - 1) * pgState.limit;
  const end = Math.min(start + pgState.limit, totalItems);
  const pageData = filteredRequests.slice(start, end);

  // Render table rows
  const tbody = document.getElementById('requests-table-body');
  if (tbody) {
    tbody.innerHTML = '';

    if (pageData.length === 0) {
      tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--color-text-muted); padding: 2rem;">No requisitions in this segment.</td></tr>`;
    } else {
      pageData.forEach(req => {
        const tr = document.createElement('tr');
        
        // Items Details Text
        const itemsCount = req.items.reduce((sum, item) => sum + item.qty, 0);
        const itemsListStr = req.items.map(item => `${item.name} (${item.qty}x)`).join(', ');
        
        // Status Badge class mapping
        let badgeClass = 'outline-orange';
        if (req.status === 'Approved') badgeClass = 'outline-green';
        if (req.status === 'Rejected') badgeClass = 'outline-red';

        // Action Buttons tailored for Requisitions vs Handovers segments
        let actionBtnHtml = '';
        if (segment === 'requests') {
          if (req.status === 'Need Approval') {
            actionBtnHtml = `<button class="btn-table-primary btn-approve-req-ticket" data-id="${req.id}">Approve Requisition</button>`;
          } else {
            actionBtnHtml = `<button class="btn-table-secondary btn-view-req-ticket" data-id="${req.id}">View Details</button>`;
          }
        } else {
          actionBtnHtml = `<button class="btn-table-secondary btn-view-issuance" data-id="${req.id}">Handover Slip</button>`;
        }

        if (segment === 'requests') {
          tr.innerHTML = `
            <td><strong>${highlightText(req.id, appState.filters.requests.search)}</strong></td>
            <td>
              <div class="items-cell-wrap">
                <div class="items-cell-icon purple-theme">
                  <i data-lucide="package"></i>
                </div>
                <div class="items-cell-details">
                  <span class="items-cell-title">${itemsCount} Items</span>
                  <span class="items-cell-subtext" title="${itemsListStr}">${highlightText(itemsListStr, appState.filters.requests.search)}</span>
                </div>
              </div>
            </td>
            <td>
              <div>
                <div class="date-cell-wrap">
                  <i data-lucide="calendar"></i>
                  <span>${req.date}</span>
                </div>
                <span class="date-cell-time">${req.time}</span>
              </div>
            </td>
            <td>
              <span class="badge-status ${badgeClass}">${req.status}</span>
            </td>
            <td>
              <div class="actions-cell-group">
                ${actionBtnHtml}
              </div>
            </td>
          `;
        } else {
          // Completed handovers view
          const authorizedBy = req.approvedBy && req.approvedBy !== '--' ? req.approvedBy : 'Lab In-Charge';
          tr.innerHTML = `
            <td><strong>${highlightText(req.id, appState.filters.requests.search)}</strong></td>
            <td>
              <div class="items-cell-wrap">
                <div class="items-cell-icon purple-theme">
                  <i data-lucide="package"></i>
                </div>
                <div class="items-cell-details">
                  <span class="items-cell-title">${itemsCount} Items Handed Over</span>
                  <span class="items-cell-subtext" title="${itemsListStr}">${highlightText(itemsListStr, appState.filters.requests.search)}</span>
                </div>
              </div>
            </td>
            <td>
              <div>
                <div class="date-cell-wrap">
                  <i data-lucide="calendar"></i>
                  <span>${req.date}</span>
                </div>
                <span class="date-cell-time">${req.time}</span>
              </div>
            </td>
            <td>
              <span style="font-size: 0.85rem; font-weight: 600; color: var(--color-text-main);">${authorizedBy}</span>
            </td>
            <td>
              <div class="actions-cell-group">
                ${actionBtnHtml}
              </div>
            </td>
          `;
        }
        
        tbody.appendChild(tr);
      });

      // Bind action buttons
      tbody.querySelectorAll('.btn-approve-req-ticket').forEach(btn => {
        btn.addEventListener('click', () => {
          const reqId = btn.getAttribute('data-id');
          openReviewRequestModal(reqId);
        });
      });

      tbody.querySelectorAll('.btn-view-req-ticket').forEach(btn => {
        btn.addEventListener('click', () => {
          const reqId = btn.getAttribute('data-id');
          openViewRequestModal(reqId);
        });
      });

      tbody.querySelectorAll('.btn-view-issuance').forEach(btn => {
        btn.addEventListener('click', () => {
          const reqId = btn.getAttribute('data-id');
          openViewIssuanceSlipModal(reqId);
        });
      });
    }
  }

  // Draw Pagination Bar
  renderTablePaginationControls('requests', totalItems, start, end, 'requests-pagination', renderRequestsTable);

  // Update Right Summary Sidebar Metrics
  const formattedCount = (val) => String(val).padStart(2, '0');

  const metricStack = document.getElementById('requests-metric-stack');
  if (metricStack) {
    metricStack.innerHTML = `
      <div class="summary-metric-tile purple-theme clickable-metric-tile" id="tile-req-total">
        <div class="metric-tile-icon"><i data-lucide="file-text"></i></div>
        <div class="metric-tile-info">
          <span class="metric-tile-label">Total Requests</span>
          <span class="metric-tile-value">${formattedCount(totalCount)}</span>
        </div>
      </div>
      <div class="summary-metric-tile orange-theme clickable-metric-tile" id="tile-req-need">
        <div class="metric-tile-icon"><i data-lucide="clock"></i></div>
        <div class="metric-tile-info">
          <span class="metric-tile-label">Need Approval</span>
          <span class="metric-tile-value">${formattedCount(needCount)}</span>
        </div>
      </div>
      <div class="summary-metric-tile green-theme clickable-metric-tile" id="tile-req-approved">
        <div class="metric-tile-icon"><i data-lucide="check-circle"></i></div>
        <div class="metric-tile-info">
          <span class="metric-tile-label">Approved</span>
          <span class="metric-tile-value">${formattedCount(approvedCount)}</span>
        </div>
      </div>
      <div class="summary-metric-tile red-theme clickable-metric-tile" id="tile-req-rejected">
        <div class="metric-tile-icon"><i data-lucide="x-circle"></i></div>
        <div class="metric-tile-info">
          <span class="metric-tile-label">Rejected</span>
          <span class="metric-tile-value">${formattedCount(rejectedCount)}</span>
        </div>
      </div>
    `;

    // Bind click handlers to summary metric cards for dynamic component breakdowns
    const totalReqTile = document.getElementById('tile-req-total');
    if (totalReqTile) {
      totalReqTile.addEventListener('click', () => {
        showComponentBreakdown("Total Requests", metricsBase);
      });
    }
    const needReqTile = document.getElementById('tile-req-need');
    if (needReqTile) {
      needReqTile.addEventListener('click', () => {
        showComponentBreakdown("Need Approval Requests", metricsBase.filter(r => r.status === 'Need Approval'));
      });
    }
    const approvedReqTile = document.getElementById('tile-req-approved');
    if (approvedReqTile) {
      approvedReqTile.addEventListener('click', () => {
        showComponentBreakdown("Approved Requests", metricsBase.filter(r => r.status === 'Approved'));
      });
    }
    const rejectedReqTile = document.getElementById('tile-req-rejected');
    if (rejectedReqTile) {
      rejectedReqTile.addEventListener('click', () => {
        showComponentBreakdown("Rejected Requests", metricsBase.filter(r => r.status === 'Rejected'));
      });
    }
  }

  // Reload icons
  lucide.createIcons();
}

/* Tab 6: ISSUES TABLE */
function renderIssuesTable() {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  if (!team) return;

  // Filter list
  const filteredIssues = team.issues.filter(i => {
    // Severity filter
    const matchesSeverity = (appState.filters.issues.severity === 'All' || i.severity === appState.filters.issues.severity);
    // Status filter
    const matchesStatus = (appState.filters.issues.status === 'All' || i.status === appState.filters.issues.status);

    return matchesSeverity && matchesStatus;
  });

  const pgState = appState.pagination.issues;
  const totalItems = filteredIssues.length;
  const totalPages = Math.ceil(totalItems / pgState.limit) || 1;
  if (pgState.page > totalPages) pgState.page = totalPages;

  const start = (pgState.page - 1) * pgState.limit;
  const end = Math.min(start + pgState.limit, totalItems);
  const pageData = filteredIssues.slice(start, end);

  const tbody = document.getElementById('issues-table-body');
  tbody.innerHTML = '';

  if (pageData.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--color-text-muted); padding: 1.5rem;">No defects reported.</td></tr>`;
  } else {
    pageData.forEach(i => {
      const tr = document.createElement('tr');
      
      let statusClass = 'pending';
      if (i.status === 'Closed') statusClass = 'success';
      if (i.status === 'Open') statusClass = 'danger';

      tr.innerHTML = `
        <td>${i.id}</td>
        <td><strong>${i.description}</strong></td>
        <td>${i.date}</td>
        <td><span class="badge-status ${i.severity.toLowerCase() === 'critical' ? 'danger' : i.severity.toLowerCase() === 'high' ? 'pending' : 'info'}">${i.severity}</span></td>
        <td><span class="badge-status ${statusClass}">${i.status}</span></td>
        <td>
          <button class="btn-table-action btn-redirect-page" data-target="defect-tracking" style="background-color: var(--color-brand-blue-light); color: var(--color-brand-blue); border-color: transparent;">Go to Defects</button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    tbody.querySelectorAll('.btn-redirect-page').forEach(btn => {
      btn.addEventListener('click', () => {
        const target = btn.getAttribute('data-target');
        redirectToPage(target);
      });
    });
  }

  renderTablePaginationControls('issues', totalItems, start, end, 'issues-pagination', renderIssuesTable);
}

// --------------------------------------------------------------------------
// 8. PAGINATION CONTROLS DRAWER
// --------------------------------------------------------------------------
function renderTablePaginationControls(key, totalItems, start, end, targetDivId, callback) {
  const container = document.getElementById(targetDivId);
  if (!container) return;

  const pgState = appState.pagination[key];
  const totalPages = Math.ceil(totalItems / pgState.limit) || 1;

  container.innerHTML = `
    <span class="pagination-info">Showing ${totalItems > 0 ? start + 1 : 0} to ${end} of ${totalItems} rows</span>
    <div class="pagination-controls-wrap">
      <button class="btn-pagination-arrow btn-prev" ${pgState.page === 1 ? 'disabled' : ''}><i data-lucide="chevron-left"></i></button>
      <div class="pagination-pages">
        <!-- Render tags -->
      </div>
      <button class="btn-pagination-arrow btn-next" ${pgState.page === totalPages ? 'disabled' : ''}><i data-lucide="chevron-right"></i></button>
    </div>
    <div class="rows-per-page">
      <select class="sel-rows">
        <option value="5" ${pgState.limit === 5 ? 'selected' : ''}>5 / page</option>
        <option value="10" ${pgState.limit === 10 ? 'selected' : ''}>10 / page</option>
        <option value="20" ${pgState.limit === 20 ? 'selected' : ''}>20 / page</option>
      </select>
    </div>
  `;

  // Page Numbers
  const pagesContainer = container.querySelector('.pagination-pages');
  for (let i = 1; i <= totalPages; i++) {
    const pageTag = document.createElement('span');
    pageTag.className = `pagination-page-tag ${i === pgState.page ? 'active' : ''}`;
    pageTag.innerText = i;
    pageTag.addEventListener('click', () => {
      pgState.page = i;
      callback();
      lucide.createIcons();
    });
    pagesContainer.appendChild(pageTag);
  }

  // Bind Arrows
  container.querySelector('.btn-prev').addEventListener('click', () => {
    if (pgState.page > 1) {
      pgState.page--;
      callback();
      lucide.createIcons();
    }
  });

  container.querySelector('.btn-next').addEventListener('click', () => {
    if (pgState.page < totalPages) {
      pgState.page++;
      callback();
      lucide.createIcons();
    }
  });

  // Bind Rows Select
  container.querySelector('.sel-rows').addEventListener('change', (e) => {
    pgState.limit = parseInt(e.target.value, 10);
    pgState.page = 1;
    callback();
    lucide.createIcons();
  });
}

// --------------------------------------------------------------------------
// 9. EVENT BINDINGS & ACTIONS
// --------------------------------------------------------------------------
function setupEventBindings() {
  
  // Landing Filters
  document.getElementById('search-query').addEventListener('input', (e) => {
    appState.filters.search = e.target.value;
    appState.pagination.landing.page = 1;
    renderLandingView();
    lucide.createIcons();
  });

  document.getElementById('filter-faculty').addEventListener('change', (e) => {
    appState.filters.faculty = e.target.value;
    appState.pagination.landing.page = 1;
    renderLandingView();
    lucide.createIcons();
  });

  document.getElementById('btn-reset-filters').addEventListener('click', () => {
    document.getElementById('search-query').value = '';
    document.getElementById('filter-faculty').value = 'All';
    
    appState.filters.search = '';
    appState.filters.faculty = 'All';
    appState.filters.department = 'All';
    appState.pagination.landing.page = 1;
    
    renderLandingView();
    lucide.createIcons();
    showToast("Filters successfully reset!");
  });

  // Rows Limit landing dropdown
  document.getElementById('teams-rows-select').addEventListener('change', (e) => {
    appState.pagination.landing.limit = parseInt(e.target.value, 10);
    appState.pagination.landing.page = 1;
    renderLandingView();
    lucide.createIcons();
  });

  document.getElementById('teams-prev-btn').addEventListener('click', () => {
    if (appState.pagination.landing.page > 1) {
      appState.pagination.landing.page--;
      renderLandingView();
      lucide.createIcons();
    }
  });

  document.getElementById('teams-next-btn').addEventListener('click', () => {
    const { search, faculty } = appState.filters;
    const filteredTeams = appState.teams.filter(team => {
      const matchesSearch = 
        team.name.toLowerCase().includes(search.toLowerCase()) ||
        team.project.toLowerCase().includes(search.toLowerCase()) ||
        team.leader.toLowerCase().includes(search.toLowerCase()) ||
        team.id.toLowerCase().includes(search.toLowerCase());
      const matchesFaculty = (faculty === 'All' || team.faculty === faculty);
      return matchesSearch && matchesFaculty;
    });
    
    const maxPages = Math.ceil(filteredTeams.length / appState.pagination.landing.limit) || 1;
    if (appState.pagination.landing.page < maxPages) {
      appState.pagination.landing.page++;
      renderLandingView();
      lucide.createIcons();
    }
  });

  // Metric cards jumps
  document.querySelectorAll('.view-detail-link').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const target = link.getAttribute('data-target');
      switchView(target, appState.selectedTeamId);
    });
  });

  // Detail Sub-tabs buttons
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const tab = btn.getAttribute('data-tab');
      activateDetailTab(tab);
      lucide.createIcons();
    });
  });

  // Back Navigations
  document.getElementById('btn-back-to-teams').addEventListener('click', (e) => {
    e.preventDefault();
    switchView('landing');
  });

  document.getElementById('btn-back-to-overview').addEventListener('click', (e) => {
    e.preventDefault();
    switchView('overview');
  });

  // Placeholder navigation back links
  document.getElementById('btn-placeholder-back').addEventListener('click', (e) => {
    e.preventDefault();
    switchView('landing');
  });

  document.getElementById('btn-placeholder-home').addEventListener('click', () => {
    switchView('landing');
  });

  // Sidebar Menu Item Click Handling
  document.querySelectorAll('.sidebar-menu .menu-item').forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const page = item.getAttribute('data-page');
      if (page === 'team-workspace') {
        switchView('landing');
      } else {
        redirectToPage(page);
      }
    });
  });

  // Click View Details on Overview activity cards
  document.querySelectorAll('.activity-card').forEach(card => {
    card.addEventListener('click', () => {
      const tab = card.getAttribute('data-tab');
      switchView(tab);
    });
  });

  // Click mini cards on Overview
  document.querySelectorAll('.select-details-tab').forEach(card => {
    card.addEventListener('click', () => {
      const tab = card.getAttribute('data-tab');
      switchView(tab);
    });
  });

  // Modal Closing binds
  document.getElementById('btn-close-modal').addEventListener('click', closeModal);
  document.getElementById('action-modal').addEventListener('click', (e) => {
    if (e.target.id === 'action-modal') closeModal();
  });

  // Exports click trigger
  document.querySelectorAll('.btn-export').forEach(btn => {
    btn.addEventListener('click', () => {
      const type = btn.getAttribute('data-type');
      showToast(`Exported ${type} spreadsheet successfully!`);
    });
  });

  // Filter click visual trigger
  document.querySelectorAll('.btn-filter').forEach(btn => {
    btn.addEventListener('click', () => {
      showToast("Advanced table sorting enabled.");
    });
  });

  // Returns detailed tab inputs
  const returnsSearch = document.getElementById('returns-search');
  if (returnsSearch) {
    returnsSearch.addEventListener('input', (e) => {
      appState.filters.resources.search = e.target.value;
      appState.pagination.resources.page = 1;
      renderResourcesTable();
    });
  }
  const returnsFilterStatus = document.getElementById('returns-filter-status');
  if (returnsFilterStatus) {
    returnsFilterStatus.addEventListener('change', (e) => {
      appState.filters.resources.status = e.target.value;
      appState.pagination.resources.page = 1;
      renderResourcesTable();
    });
  }
  const returnsFilterType = document.getElementById('returns-filter-type');
  if (returnsFilterType) {
    returnsFilterType.addEventListener('change', (e) => {
      appState.filters.resources.type = e.target.value;
      appState.pagination.resources.page = 1;
      renderResourcesTable();
    });
  }

  // Bookings detailed tab inputs
  const bookingsFilterEquip = document.getElementById('bookings-filter-equip');
  if (bookingsFilterEquip) {
    bookingsFilterEquip.addEventListener('change', (e) => {
      appState.filters.bookings.equipment = e.target.value;
      appState.pagination.bookings.page = 1;
      renderBookingsTable();
    });
  }
  const bookingsFilterStatus = document.getElementById('bookings-filter-status');
  if (bookingsFilterStatus) {
    bookingsFilterStatus.addEventListener('change', (e) => {
      appState.filters.bookings.status = e.target.value;
      appState.pagination.bookings.page = 1;
      renderBookingsTable();
    });
  }

  // Requests detailed tab inputs
  const requestsSearch = document.getElementById('requests-search');
  if (requestsSearch) {
    requestsSearch.addEventListener('input', (e) => {
      appState.filters.requests.search = e.target.value;
      appState.pagination.requests.page = 1;
      renderRequestsTable();
    });
  }
  const requestsFilterStatus = document.getElementById('requests-filter-status');
  if (requestsFilterStatus) {
    requestsFilterStatus.addEventListener('change', (e) => {
      appState.filters.requests.status = e.target.value;
      appState.pagination.requests.page = 1;
      renderRequestsTable();
    });
  }
  const requestsFilterType = document.getElementById('requests-filter-type');
  if (requestsFilterType) {
    requestsFilterType.addEventListener('change', (e) => {
      appState.filters.requests.type = e.target.value;
      appState.pagination.requests.page = 1;
      renderRequestsTable();
    });
  }

  // Issues detailed tab inputs
  document.getElementById('issues-filter-severity').addEventListener('change', (e) => {
    appState.filters.issues.severity = e.target.value;
    appState.pagination.issues.page = 1;
    renderIssuesTable();
  });
  document.getElementById('issues-filter-status').addEventListener('change', (e) => {
    appState.filters.issues.status = e.target.value;
    appState.pagination.issues.page = 1;
    renderIssuesTable();
  });

  // Segment switchers bindings
  const returnsSwitcher = document.getElementById('returns-segment-switcher');
  if (returnsSwitcher) {
    returnsSwitcher.querySelectorAll('.segment-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        returnsSwitcher.querySelectorAll('.segment-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        appState.returnsSegment = btn.getAttribute('data-segment');
        appState.pagination.resources.page = 1;
        
        // Reset filters on segment switch
        appState.filters.resources.status = 'All';
        appState.filters.resources.search = '';
        appState.filters.resources.type = 'All';
        
        const retSearch = document.getElementById('returns-search');
        if (retSearch) retSearch.value = '';
        const retType = document.getElementById('returns-filter-type');
        if (retType) retType.value = 'All';

        updateReturnsStatusDropdownOptions();
        renderResourcesTable();
      });
    });
  }

  const requestsSwitcher = document.getElementById('requests-segment-switcher');
  if (requestsSwitcher) {
    requestsSwitcher.querySelectorAll('.segment-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        requestsSwitcher.querySelectorAll('.segment-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        appState.requestsSegment = btn.getAttribute('data-segment');
        appState.pagination.requests.page = 1;
        
        // Reset filters on segment switch
        appState.filters.requests.status = 'All';
        appState.filters.requests.search = '';
        appState.filters.requests.type = 'All';
        
        const reqSearch = document.getElementById('requests-search');
        if (reqSearch) reqSearch.value = '';
        const reqType = document.getElementById('requests-filter-type');
        if (reqType) reqType.value = 'All';

        updateRequestsStatusDropdownOptions();
        renderRequestsTable();
      });
    });
  }
}

function updateReturnsStatusDropdownOptions() {
  const select = document.getElementById('returns-filter-status');
  if (!select) return;
  const currentVal = select.value;
  if (appState.returnsSegment === 'requests') {
    select.innerHTML = `
      <option value="All">All Statuses</option>
      <option value="Need Approval">Need Approval</option>
    `;
  } else {
    select.innerHTML = `
      <option value="All">All Statuses</option>
      <option value="Approved">Approved</option>
    `;
  }
  const options = Array.from(select.options).map(o => o.value);
  if (options.includes(currentVal)) {
    select.value = currentVal;
  } else {
    select.value = 'All';
    appState.filters.resources.status = 'All';
  }
}

function updateRequestsStatusDropdownOptions() {
  const select = document.getElementById('requests-filter-status');
  if (!select) return;
  const currentVal = select.value;
  if (appState.requestsSegment === 'requests') {
    select.innerHTML = `
      <option value="All">All Statuses</option>
      <option value="Need Approval">Need Approval</option>
      <option value="Rejected">Rejected</option>
    `;
  } else {
    select.innerHTML = `
      <option value="All">All Statuses</option>
      <option value="Approved">Approved</option>
    `;
  }
  const options = Array.from(select.options).map(o => o.value);
  if (options.includes(currentVal)) {
    select.value = currentVal;
  } else {
    select.value = 'All';
    appState.filters.requests.status = 'All';
  }
}

// --------------------------------------------------------------------------
// 10. INTERACTIVE WRITE OPERATIONS
// --------------------------------------------------------------------------

// Return Item Modal Builder
function openReturnModal(resId) {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  const resource = team.resources.find(r => r.id === resId);

  const modal = document.getElementById('action-modal');
  const title = document.getElementById('modal-title');
  const body = document.getElementById('modal-body-content');

  title.innerText = `Material Return: ${resource.name}`;
  const maxToReturn = resource.qtyIssued - resource.qtyReturned;

  body.innerHTML = `
    <p style="font-size: 0.85rem; color: var(--color-text-muted);">
      Specify the quantity of <strong>${resource.name}</strong> being returned to the inventory.
    </p>
    <div class="form-group">
      <label>Current Outstanding Issued</label>
      <input type="text" value="${maxToReturn}" disabled style="background-color: var(--color-bg-app);">
    </div>
    <div class="form-group">
      <label for="return-qty">Quantity to Return</label>
      <input type="number" id="return-qty" min="1" max="${maxToReturn}" value="${maxToReturn}">
    </div>
    <div class="modal-actions">
      <button class="btn btn-secondary" id="btn-modal-cancel">Cancel</button>
      <button class="btn btn-primary" id="btn-modal-submit">Confirm Return</button>
    </div>
  `;

  // Bind controls inside modal
  document.getElementById('btn-modal-cancel').addEventListener('click', closeModal);
  document.getElementById('btn-modal-submit').addEventListener('click', () => {
    const qty = parseInt(document.getElementById('return-qty').value, 10);
    if (qty >= 1 && qty <= maxToReturn) {
      // Apply modification
      resource.qtyReturned += qty;
      if (resource.qtyReturned === resource.qtyIssued) {
        resource.status = 'Returned';
      }
      
      closeModal();
      refreshAppMetrics();
      renderResourcesTable();
      showToast(`Processed return of ${qty}x ${resource.name} successfully!`);
    } else {
      alert(`Please enter a quantity between 1 and ${maxToReturn}.`);
    }
  });

  modal.classList.add('active');
}

// Confirm Equipment Booking
function confirmBooking(bookingId) {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  const booking = team.bookings.find(b => b.id === bookingId);
  
  booking.status = 'Confirmed';
  refreshAppMetrics();
  renderBookingsTable();
  showToast(`Booking for ${booking.equipment} is now Confirmed!`);
}

// Approve Request
function approveRequest(reqId) {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  const req = team.requests.find(q => q.id === reqId);

  req.status = 'Approved';
  req.approvedBy = 'Lab In-Charge';
  
  // If component/tool request, let's append it to team resources!
  if (req.type.includes('Component') || req.type.includes('Tool')) {
    const existing = team.resources.find(r => r.name.toLowerCase() === req.item.toLowerCase());
    if (existing) {
      existing.qtyIssued += req.qty;
      if (existing.status === 'Returned') existing.status = 'Issued';
    } else {
      team.resources.push({
        id: 'R_NEW_' + Date.now(),
        name: req.item,
        type: req.type.includes('Tool') ? 'Tool' : 'Component',
        qtyIssued: req.qty,
        qtyReturned: 0,
        dueDate: '20 Aug 2026',
        status: 'Returned' // Initially in safe status
      });
    }
  } else if (req.type.includes('Booking')) {
    team.bookings.push({
      id: 'B_NEW_' + Date.now(),
      equipment: req.item,
      date: '16 Jul 2026',
      timeSlot: '02:00 PM - 04:00 PM',
      purpose: 'Approved Request Allocation',
      status: 'Confirmed'
    });
  }

  refreshAppMetrics();
  renderRequestsTable();
  showToast(`Requisition for ${req.item} approved successfully!`);
}

function approveRequestTicket(reqId) {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  const req = team.requests.find(q => q.id === reqId);
  if (req) {
    req.status = 'Approved';
    
    // Add items to team's resources
    req.items.forEach(item => {
      const existing = team.resources.find(r => r.name.toLowerCase() === item.name.toLowerCase());
      if (existing) {
        existing.qtyIssued += item.qty;
      } else {
        team.resources.push({
          id: 'R_NEW_' + Date.now(),
          name: item.name,
          type: 'Component',
          qtyIssued: item.qty,
          qtyReturned: 0,
          dueDate: '20 Aug 2026',
          status: 'Returned'
        });
      }
    });

    refreshAppMetrics();
    renderRequestsTable();
    showToast(`Request ${reqId} approved successfully!`);
  }
}

function openReviewReturnModal(retId) {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  const ret = team.returns.find(r => r.id === retId);
  if (!ret) return;

  const modal = document.getElementById('action-modal');
  const title = document.getElementById('modal-title');
  const body = document.getElementById('modal-body-content');

  title.innerText = `Verify Return: ${ret.id}`;
  
  let itemsHtml = ret.items.map(item => `
    <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid var(--color-border);">
      <span><strong>${item.name}</strong></span>
      <span>Qty Returned: ${item.qty}</span>
    </div>
  `).join('');

  body.innerHTML = `
    <p style="font-size: 0.85rem; color: var(--color-text-muted); margin-bottom: 1rem;">
      Please inspect and verify the returned components listed below from <strong>${team.name}</strong>.
    </p>
    <div style="background-color: var(--color-bg-app); padding: 1rem; border-radius: var(--radius-sm); margin-bottom: 1.25rem;">
      ${itemsHtml}
    </div>
    <div class="modal-actions">
      <button class="btn btn-secondary" id="btn-modal-cancel">Cancel</button>
      <button class="btn btn-primary" id="btn-modal-submit" style="background-color: var(--color-brand-blue); color: #fff;">Approve Return</button>
    </div>
  `;

  document.getElementById('btn-modal-cancel').addEventListener('click', closeModal);
  document.getElementById('btn-modal-submit').addEventListener('click', () => {
    ret.status = 'Approved';

    // Update resources returned quantities
    ret.items.forEach(item => {
      const resource = team.resources.find(r => r.name.toLowerCase() === item.name.toLowerCase());
      if (resource) {
        resource.qtyReturned = Math.min(resource.qtyReturned + item.qty, resource.qtyIssued);
        if (resource.qtyReturned === resource.qtyIssued) {
          resource.status = 'Returned';
        }
      }
    });

    closeModal();
    refreshAppMetrics();
    renderResourcesTable();
    showToast(`Return ticket ${retId} approved and verified!`);
  });

  modal.classList.add('active');
}

function openViewReturnModal(retId) {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  const ret = team.returns.find(r => r.id === retId);
  if (!ret) return;

  const modal = document.getElementById('action-modal');
  const title = document.getElementById('modal-title');
  const body = document.getElementById('modal-body-content');

  title.innerText = `Return Details: ${ret.id}`;
  
  let itemsHtml = ret.items.map(item => `
    <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid var(--color-border);">
      <span><strong>${item.name}</strong></span>
      <span>Qty: ${item.qty}</span>
    </div>
  `).join('');

  body.innerHTML = `
    <div style="background-color: var(--color-bg-app); padding: 1rem; border-radius: var(--radius-sm); margin-bottom: 1.25rem;">
      <div style="margin-bottom: 0.5rem; font-size: 0.8rem; color: var(--color-text-muted);">
        Status: <strong style="color: var(--color-brand-blue);">${ret.status}</strong> | Date: ${ret.date} ${ret.time}
      </div>
      ${itemsHtml}
    </div>
    <div class="modal-actions">
      <button class="btn btn-secondary" id="btn-modal-cancel">Close</button>
    </div>
  `;

  document.getElementById('btn-modal-cancel').addEventListener('click', closeModal);
  modal.classList.add('active');
}

function openViewRequestModal(reqId) {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  const req = team.requests.find(q => q.id === reqId);
  if (!req) return;

  const modal = document.getElementById('action-modal');
  const title = document.getElementById('modal-title');
  const body = document.getElementById('modal-body-content');

  title.innerText = `Request Details: ${req.id}`;
  
  let itemsHtml = req.items.map(item => `
    <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid var(--color-border);">
      <span><strong>${item.name}</strong></span>
      <span>Qty: ${item.qty}</span>
    </div>
  `).join('');

  body.innerHTML = `
    <div style="background-color: var(--color-bg-app); padding: 1rem; border-radius: var(--radius-sm); margin-bottom: 1.25rem;">
      <div style="margin-bottom: 0.5rem; font-size: 0.8rem; color: var(--color-text-muted);">
        Status: <strong style="color: var(--color-brand-blue);">${req.status}</strong> | Date: ${req.date} ${req.time}
      </div>
      ${itemsHtml}
    </div>
    <div class="modal-actions">
      <button class="btn btn-secondary" id="btn-modal-cancel">Close</button>
    </div>
  `;

  document.getElementById('btn-modal-cancel').addEventListener('click', closeModal);
  modal.classList.add('active');
}

function openReviewRequestModal(reqId) {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  const req = team.requests.find(q => q.id === reqId);
  if (!req) return;

  const modal = document.getElementById('action-modal');
  const title = document.getElementById('modal-title');
  const body = document.getElementById('modal-body-content');

  title.innerText = `Review Requisition Request: ${req.id}`;
  
  let itemsHtml = req.items.map(item => `
    <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid var(--color-border);">
      <span><strong>${item.name}</strong></span>
      <span>Qty Requested: ${item.qty}</span>
    </div>
  `).join('');

  body.innerHTML = `
    <p style="font-size: 0.85rem; color: var(--color-text-muted); margin-bottom: 1rem;">
      Please review the requested components listed below from <strong>${team.name}</strong>.
    </p>
    <div style="background-color: var(--color-bg-app); padding: 1rem; border-radius: var(--radius-sm); margin-bottom: 1.25rem;">
      ${itemsHtml}
    </div>
    <div class="modal-actions">
      <button class="btn btn-secondary" id="btn-modal-cancel">Cancel</button>
      <button class="btn" id="btn-modal-reject" style="background-color: var(--color-danger); color: #fff;">Reject</button>
      <button class="btn btn-primary" id="btn-modal-approve" style="background-color: var(--color-brand-blue); color: #fff;">Approve Request</button>
    </div>
  `;

  document.getElementById('btn-modal-cancel').addEventListener('click', closeModal);
  
  document.getElementById('btn-modal-reject').addEventListener('click', () => {
    req.status = 'Rejected';
    closeModal();
    refreshAppMetrics();
    renderRequestsTable();
    showToast(`Request ${reqId} has been rejected.`);
  });

  document.getElementById('btn-modal-approve').addEventListener('click', () => {
    req.status = 'Approved';
    
    // Add items to team's resources
    req.items.forEach(item => {
      const existing = team.resources.find(r => r.name.toLowerCase() === item.name.toLowerCase());
      if (existing) {
        existing.qtyIssued += item.qty;
      } else {
        team.resources.push({
          id: 'R_NEW_' + Date.now(),
          name: item.name,
          type: 'Component',
          qtyIssued: item.qty,
          qtyReturned: 0,
          dueDate: '20 Aug 2026',
          status: 'Returned'
        });
      }
    });

    closeModal();
    refreshAppMetrics();
    renderRequestsTable();
    showToast(`Request ${reqId} approved successfully!`);
  });

  modal.classList.add('active');
}

function showComponentBreakdown(categoryName, itemsList) {
  const counts = {};
  itemsList.forEach(item => {
    item.items.forEach(subItem => {
      const name = subItem.name;
      counts[name] = (counts[name] || 0) + subItem.qty;
    });
  });
  
  const modal = document.getElementById('action-modal');
  const title = document.getElementById('modal-title');
  const body = document.getElementById('modal-body-content');
  
  title.innerText = `Component Breakdown – ${categoryName}`;
  
  let itemsHtml = '';
  const sortedItems = Object.entries(counts).sort((a, b) => b[1] - a[1]);
  
  if (sortedItems.length === 0) {
    itemsHtml = `<div style="text-align: center; color: var(--color-text-muted); padding: 1rem;">No items found.</div>`;
  } else {
    itemsHtml = sortedItems.map(([name, qty]) => `
      <div style="display: flex; justify-content: space-between; align-items: center; padding: 0.75rem 0; border-bottom: 1px solid var(--color-border);">
        <span style="font-weight: 500; color: var(--color-text-main);">${name}</span>
        <span class="badge-status info" style="font-weight: 600; font-size: 0.9rem; background-color: var(--color-info-bg); color: var(--color-info);">x${qty}</span>
      </div>
    `).join('');
  }
  
  body.innerHTML = `
    <p style="font-size: 0.85rem; color: var(--color-text-muted); margin-bottom: 1.25rem;">
      Showing aggregated component quantities for all items in <strong>${categoryName}</strong>.
    </p>
    <div style="background-color: var(--color-bg-app); padding: 1rem; border-radius: var(--radius-sm); max-height: 300px; overflow-y: auto;">
      ${itemsHtml}
    </div>
    <div class="modal-actions" style="margin-top: 1.25rem;">
      <button class="btn btn-secondary" id="btn-modal-cancel">Close</button>
    </div>
  `;
  
  document.getElementById('btn-modal-cancel').addEventListener('click', closeModal);
  modal.classList.add('active');
}

function openViewIssuanceSlipModal(reqId) {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  const req = team.requests.find(q => q.id === reqId);
  if (!req) return;

  const modal = document.getElementById('action-modal');
  const title = document.getElementById('modal-title');
  const body = document.getElementById('modal-body-content');

  title.innerText = `Material Handover Slip: ${req.id}`;
  
  let itemsHtml = req.items.map(item => `
    <div style="display: flex; justify-content: space-between; padding: 0.5rem 0; border-bottom: 1px solid var(--color-border);">
      <span><strong>${item.name}</strong></span>
      <span>Qty Handed Over: ${item.qty}</span>
    </div>
  `).join('');

  const authorizedBy = req.approvedBy && req.approvedBy !== '--' ? req.approvedBy : 'Lab In-Charge';

  body.innerHTML = `
    <div style="border: 2px dashed var(--color-border); padding: 1.5rem; border-radius: var(--radius-sm); font-family: monospace; background-color: #fff; color: #333; line-height: 1.5; box-shadow: inset 0 0 10px rgba(0,0,0,0.02);">
      <div style="text-align: center; border-bottom: 2px solid #333; padding-bottom: 0.5rem; margin-bottom: 1rem;">
        <h4 style="margin: 0; font-size: 1.1rem; text-transform: uppercase; font-weight: bold; letter-spacing: 1px;">INVENTORY HANDOVER VOUCHER</h4>
        <span style="font-size: 0.75rem; color: #666;">Lab Operations Management System</span>
      </div>
      
      <div style="display: flex; justify-content: space-between; font-size: 0.8rem; margin-bottom: 1rem;">
        <div>
          <strong>Voucher ID:</strong> ${req.id}<br>
          <strong>Recipient:</strong> ${team.name} (${team.leader})
        </div>
        <div style="text-align: right;">
          <strong>Date:</strong> ${req.date}<br>
          <strong>Time:</strong> ${req.time}
        </div>
      </div>

      <div style="border-top: 1px solid #ddd; border-bottom: 1px solid #ddd; padding: 0.5rem 0; margin-bottom: 1rem; font-size: 0.8rem;">
        <div style="display: flex; justify-content: space-between; font-weight: bold; margin-bottom: 0.25rem; border-bottom: 1px solid #eee; padding-bottom: 0.25rem;">
          <span>Item Description</span>
          <span>Qty</span>
        </div>
        ${req.items.map(item => `
          <div style="display: flex; justify-content: space-between; margin-bottom: 0.25rem;">
            <span>${item.name}</span>
            <span>${item.qty}</span>
          </div>
        `).join('')}
      </div>

      <div style="font-size: 0.8rem; margin-bottom: 1.5rem;">
        <strong>Authorized Signatory:</strong> ${authorizedBy}<br>
        <strong>Status:</strong> HANDED OVER
      </div>

      <div style="text-align: center; font-size: 0.7rem; color: #888; border-top: 1px solid #eee; padding-top: 0.5rem;">
        Thank you for maintaining lab safety and documentation records.
      </div>
    </div>
    <div class="modal-actions" style="margin-top: 1.25rem;">
      <button class="btn btn-secondary" id="btn-modal-cancel">Close</button>
      <button class="btn btn-primary" id="btn-modal-print" style="background-color: var(--color-brand-blue); color: #fff; display: flex; align-items: center; gap: 4px;"><i data-lucide="printer" style="width: 14px; height: 14px;"></i>Print Slip</button>
    </div>
  `;

  document.getElementById('btn-modal-cancel').addEventListener('click', closeModal);
  document.getElementById('btn-modal-print').addEventListener('click', () => {
    alert("Voucher sent to default lab receipt printer.");
  });
  
  modal.classList.add('active');
  lucide.createIcons();
}

// Resolve Issue Ticket
function resolveIssue(issueId) {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  const issue = team.issues.find(i => i.id === issueId);

  issue.status = 'Closed';
  refreshAppMetrics();
  renderIssuesTable();
  showToast(`Defect ticket ${issue.id} marked as Resolved!`);
}

// Utility Modal Close
function closeModal() {
  document.getElementById('action-modal').classList.remove('active');
}

// Toaster Notification
function showToast(message) {
  const toast = document.getElementById('toast-notification');
  document.getElementById('toast-message').innerText = message;
  
  toast.classList.add('active');
  setTimeout(() => {
    toast.classList.remove('active');
  }, 2500);
}

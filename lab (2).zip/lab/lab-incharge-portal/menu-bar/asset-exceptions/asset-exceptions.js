// Shared Front-end controller, Navigation systems, and database initialization

// Define default database structure
const DEFAULT_DATABASE = {
    currentUser: {
        username: "priya.sharma@rplms.com",
        name: "Dr. Priya Sharma",
        role: "Lab Incharge",
        avatar: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150",
        status: "Online",
        location: "Main Lab Complex",
        timezone: "IST (UTC+5:30)",
        email: "priya.sharma@rplms.com",
        phone: "+91 98765 43210"
    },

    notifications: [
        { id: "NTF-001", icon: "📦", iconClass: "notif-icon-request", body: "TEAM-001 has submitted a new component request for Arduino Mega boards.", time: "2 min ago", unread: true },
        { id: "NTF-002", icon: "⏰", iconClass: "notif-icon-overdue", body: "TEAM-006 has 1 overdue equipment return — Raspberry Pi 4 (EQ-011).", time: "18 min ago", unread: true },
        { id: "NTF-003", icon: "🎫", iconClass: "notif-icon-ticket", body: "New damage ticket TKT-007 raised by TEAM-002 for Digital Oscilloscope.", time: "1 hr ago", unread: true },
        { id: "NTF-004", icon: "✅", iconClass: "notif-icon-info", body: "Component request REQ-012 for resistors was approved and marked fulfilled.", time: "3 hrs ago", unread: false },
        { id: "NTF-005", icon: "📋", iconClass: "notif-icon-request", body: "TEAM-005 submitted a material return for Soldering Station (EQ-012).", time: "5 hrs ago", unread: false },
        { id: "NTF-006", icon: "⚠️", iconClass: "notif-icon-overdue", body: "Inventory alert: 3D Printer (EQ-001) maintenance is due this week.", time: "Yesterday", unread: false }
    ],

    teams: [
        { id: "TEAM-001", name: "Solar Car Project", leader: "Anil Mehta", membersCount: 8, activeProjects: 2, status: "Active" },
        { id: "TEAM-002", name: "Drone Flight Tech", leader: "Vikas Pillai", membersCount: 5, activeProjects: 1, status: "Active" },
        { id: "TEAM-003", name: "Bio-Sensor Systems", leader: "Sarah Khan", membersCount: 6, activeProjects: 2, status: "Active" },
        { id: "TEAM-004", name: "Haptic Arm Development", leader: "John Doe", membersCount: 4, activeProjects: 1, status: "Suspended" },
        { id: "TEAM-005", name: "Smart Irrigation System", leader: "Rajesh Kumar", membersCount: 7, activeProjects: 2, status: "Active" },
        { id: "TEAM-006", name: "Eco Waste sorter", leader: "Deepa Nair", membersCount: 6, activeProjects: 1, status: "Active" },
        { id: "TEAM-007", name: "VTOL UAV Propulsion", leader: "Karan Johar", membersCount: 9, activeProjects: 3, status: "Active" },
        { id: "TEAM-008", name: "3D Prosthetic Hand", leader: "Aditi Rao", membersCount: 5, activeProjects: 1, status: "Active" },
        { id: "TEAM-009", name: "Autonomous AGV", leader: "Sanjay Dutt", membersCount: 6, activeProjects: 2, status: "Active" },
        { id: "TEAM-010", name: "Water Purifier IoT", leader: "Rita Sen", membersCount: 4, activeProjects: 1, status: "Active" },
        { id: "TEAM-011", name: "Robotics Arm Team", leader: "Preeti Zinta", membersCount: 7, activeProjects: 2, status: "Active" },
        { id: "TEAM-012", name: "Smart Traffic Guard", leader: "Amir Khan", membersCount: 5, activeProjects: 1, status: "Active" },
        { id: "TEAM-013", name: "Ocean Cleaner Probe", leader: "Shruti Roy", membersCount: 8, activeProjects: 2, status: "Active" },
        { id: "TEAM-014", name: "RFID Warehouse Robot", leader: "Abhay Singh", membersCount: 6, activeProjects: 1, status: "Active" },
        { id: "TEAM-015", name: "Waste Management", leader: "Nikhil Joshi", membersCount: 7, activeProjects: 1, status: "Active" },
        { id: "TEAM-016", name: "Exoskeleton Suit", leader: "Meera Iyer", membersCount: 6, activeProjects: 2, status: "Active" },
        { id: "TEAM-017", name: "Nano Filtration Unit", leader: "Arjun Verma", membersCount: 5, activeProjects: 1, status: "Active" },
        { id: "TEAM-018", name: "AI Crop Monitor", leader: "Pooja Reddy", membersCount: 7, activeProjects: 2, status: "Active" },
        { id: "TEAM-019", name: "Swarm Robotics Lab", leader: "Farhan Qureshi", membersCount: 8, activeProjects: 3, status: "Active" },
        { id: "TEAM-020", name: "EV Charging Station", leader: "Kavya Menon", membersCount: 6, activeProjects: 1, status: "Active" },
        { id: "TEAM-021", name: "Underwater ROV", leader: "Rohan Desai", membersCount: 5, activeProjects: 2, status: "Active" }
    ],
    equipment: [
        {
            sno: 1,
            eqpid: "EQP001",
            componentName: "3D Printer",
            make: "Creality",
            specification: "Ender 3 V2",
            totalCount: 3,
            componentType: "Manufacturing Equipment",
            lab: "Mechanical Lab",
            remarks: "Working Fine"
        },
        {
            sno: 2,
            eqpid: "EQP002",
            componentName: "Laser Cutter",
            make: "Ortur",
            specification: "Laser Master 2",
            totalCount: 10,
            componentType: "Manufacturing Equipment",
            lab: "Mechanical Lab",
            remarks: "Service Due"
        },
        {
            sno: 3,
            eqpid: "EQP003",
            componentName: "CNC Machine",
            make: "Genmitsu",
            specification: "3018-PRO",
            totalCount: 5,
            componentType: "Manufacturing Equipment",
            lab: "Manufacturing Lab",
            remarks: "Operational"
        }
    ],

    components: [
        {
            sno: 1,
            cid: "CID001",
            componentName: "Arduino Uno",
            make: "Arduino",
            specification: "ATmega328P",
            cost: 850,
            returnTimeline: "Project Completion",
            totalCount: 40,
            componentType: "Electronics",
            lab: "Embedded Lab",
            cupboard: "CUP-1",
            shelf1: "A1",
            count1: 20,
            shelf2: "A2",
            count2: 20,
            purpose: "Student Projects",
            comments: "Available"
        },
        {
            sno: 2,
            cid: "CID002",
            componentName: "Raspberry Pi 4",
            make: "Raspberry",
            specification: "8GB RAM",
            cost: 7000,
            returnTimeline: "Project Completion",
            totalCount: 15,
            componentType: "Embedded",
            lab: "IoT Lab",
            cupboard: "CUP-2",
            shelf1: "B1",
            count1: 8,
            shelf2: "B2",
            count2: 7,
            purpose: "Research",
            comments: "Limited"
        }
    ],

    tools: [
        {
            sno: 1,
            toolid: "T001",
            componentName: "Screw Driver Set",
            make: "Bosch",
            specification: "Professional Kit",
            cost: 2500,
            returnTimeline: "Daily",
            totalCount: 10,
            componentType: "Hand Tool",
            lab: "Mechanical Lab",
            cupboard: "CUP-5",
            shelf1: "A1",
            count1: 5,
            shelf2: "A2",
            count2: 5,
            purpose: "Maintenance",
            comments: "Good Condition"
        },
        {
            sno: 2,
            toolid: "T002",
            componentName: "Soldering Iron",
            make: "Hakko",
            specification: "60W",
            cost: 3200,
            returnTimeline: "Daily",
            totalCount: 12,
            componentType: "Electronic Tool",
            lab: "Embedded Lab",
            cupboard: "CUP-6",
            shelf1: "B1",
            count1: 6,
            shelf2: "B2",
            count2: 6,
            purpose: "PCB Assembly",
            comments: "Available"
        }
    ],

    inventory: [
        { id: "EQ-001", name: "3D Printer", type: "Equipment", manufacturer: "Creality", model: "Ender-3 V2", serial: "CRL-3DV2-2024-1125", location: "Mechanical Lab", status: "Available", dateAdded: "2025-06-15", description: "FDM 3D printer used for rapid prototyping and model making." },
        { id: "EQ-002", name: "Arduino Uno R3", type: "Component", manufacturer: "Arduino", model: "Uno Rev 3", serial: "ARD-UNO-99382", location: "Electronics Lab", status: "Available", dateAdded: "2025-01-10", description: "Microcontroller board based on the ATmega328P." },
        { id: "EQ-003", name: "Ultrasonic Sensor", type: "Component", manufacturer: "Elegoo", model: "HC-SR04", serial: "EL-HC-2092", location: "Electronics Lab", status: "Available", dateAdded: "2025-02-14", description: "Ultrasonic distance sensor module." },
        { id: "EQ-004", name: "Soil Moisture Sensor", type: "Component", manufacturer: "Generic", model: "YL-69", serial: "GEN-YL-77291", location: "Bio Lab", status: "Available", dateAdded: "2025-03-01", description: "Resistance-based soil moisture measurement probe." },
        { id: "EQ-005", name: "CNC Milling Machine", type: "Equipment", manufacturer: "SainSmart", model: "Genmitsu 3018-PRO", serial: "CNC-GEN-8827", location: "Mechanical Lab", status: "Maintenance", dateAdded: "2025-04-18", description: "Desktop CNC router for wood, acrylic, and PCB engraving." },
        { id: "EQ-006", name: "Digital Oscilloscope", type: "Equipment", manufacturer: "Rigol", model: "DS1202Z-E", serial: "RIG-DS-44932", location: "Electronics Lab", status: "Available", dateAdded: "2025-02-28", description: "200 MHz, 2-channel digital storage oscilloscope." },
        { id: "EQ-007", name: "DC Motor 12V", type: "Component", manufacturer: "Generic", model: "RS-555", serial: "GEN-DC-38291", location: "Mechanical Lab", status: "Available", dateAdded: "2025-05-02", description: "High torque 12V DC motor." },
        { id: "EQ-008", name: "16x2 LCD Display", type: "Component", manufacturer: "Generic", model: "HD44780", serial: "GEN-LCD-10293", location: "Electronics Lab", status: "Available", dateAdded: "2025-03-12", description: "Alpha-numeric display module with purple backlight." },
        { id: "EQ-009", name: "Li-ion Battery 18650", type: "Component", manufacturer: "Samsung", model: "25R 2500mAh", serial: "SAM-186-8291", location: "Electronics Lab", status: "Available", dateAdded: "2025-04-05", description: "High-discharge rechargeable lithium-ion cell." },
        { id: "EQ-010", name: "Laser Cutter", type: "Equipment", manufacturer: "Ortur", model: "Laser Master 2 Pro", serial: "ORT-LM2-88271", location: "Mechanical Lab", status: "Available", dateAdded: "2025-05-20", description: "Diode laser engraving and cutting machine." },
        { id: "EQ-011", name: "Raspberry Pi 4", type: "Component", manufacturer: "Raspberry Pi", model: "Model B 8GB", serial: "RPi4-8G-0029", location: "Electronics Lab", status: "Available", dateAdded: "2025-01-16", description: "Single board computer with 8GB RAM." },
        { id: "EQ-012", name: "Soldering Station", type: "Equipment", manufacturer: "Hakko", model: "FX-888D", serial: "HAK-FX-2023", location: "Electronics Lab", status: "Available", dateAdded: "2025-02-05", description: "Digital soldering station with temperature control." },
        { id: "EQ-013", name: "Bench Multimeter", type: "Equipment", manufacturer: "Fluke", model: "8808A", serial: "FLU-88-82910", location: "Electronics Lab", status: "Available", dateAdded: "2025-03-24", description: "5.5 digit precision benchtop digital multimeter." },
        { id: "EQ-014", name: "Bipolar NEMA 17", type: "Component", manufacturer: "Stepperonline", model: "17HS19", serial: "STEP-N17-3829", location: "Mechanical Lab", status: "Available", dateAdded: "2025-04-11", description: "High-torque stepper motor for CNC/3D Printers." },
        { id: "EQ-015", name: "LiPo Battery 11.1V", type: "Component", manufacturer: "Tattu", model: "2200mAh 3S 45C", serial: "TAT-LIPO-223", location: "Electronics Lab", status: "Available", dateAdded: "2025-05-30", description: "Lithium polymer pack for drones and RC vehicles." },
        { id: "EQ-016", name: "Hot Air Rework Station", type: "Equipment", manufacturer: "Quick", model: "861DW", serial: "QUI-861-9021", location: "Electronics Lab", status: "Available", dateAdded: "2025-02-12", description: "1000W professional lead-free hot air rework station." },
        { id: "EQ-017", name: "PIR Motion Sensor", type: "Component", manufacturer: "Adafruit", model: "HC-SR501", serial: "ADA-PIR-3329", location: "Electronics Lab", status: "Available", dateAdded: "2025-03-10", description: "Pyroelectric infrared motion detection module." },
        { id: "EQ-018", name: "Variable DC Power Supply", type: "Equipment", manufacturer: "Korado", model: "KA3005D", serial: "KOR-PWR-3829", location: "Electronics Lab", status: "Available", dateAdded: "2025-02-22", description: "Precision programmable DC linear power supply, 30V/5A." },
        { id: "EQ-019", name: "3D Scanner", type: "Equipment", manufacturer: "EinScan", model: "SE V2", serial: "EIN-SCAN-4822", location: "Mechanical Lab", status: "Available", dateAdded: "2025-06-02", description: "Desktop white light 3D scanner for modeling." },
        { id: "EQ-020", name: "Co2 Laser Tube", type: "Component", manufacturer: "RECI", model: "W2 90W", serial: "REC-CO2-9902", location: "Mechanical Lab", status: "Repairing", dateAdded: "2025-05-15", description: "CO2 glass laser tube replacement part." }
    ],

    materialRequests: [
        { id: "REQ-001", teamId: "TEAM-001", teamName: "Solar Car Project", item: "Li-ion Battery 18650", avail: 30, qty: 24, status: "Fully Issued", date: "2025-07-02", slot: "2.00-3.00" },
        { id: "REQ-002", teamId: "TEAM-005", teamName: "Smart Irrigation System", item: "Soil Moisture Sensor", avail: 30, qty: 5, status: "Pending", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-003", teamId: "TEAM-003", teamName: "Bio-Sensor Systems", item: "Arduino Uno R3", avail: 30, qty: 3, status: "Fully Issued", date: "2025-07-01", slot: "2.00-3.00" },
        { id: "REQ-004", teamId: "TEAM-011", teamName: "Robotics Arm Team", item: "DC Motor 12V", avail: 30, qty: 6, status: "Rejected", date: "2025-06-30", slot: "2.00-3.00" },
        { id: "REQ-005", teamId: "TEAM-002", teamName: "Drone Flight Tech", item: "LiPo Battery 11.1V", avail: 30, qty: 4, status: "Pending", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-006", teamId: "TEAM-008", teamName: "3D Prosthetic Hand", item: "Bipolar NEMA 17", avail: 30, qty: 10, status: "Fully Issued", date: "2025-06-28", slot: "2.00-3.00" },
        { id: "REQ-007", teamId: "TEAM-009", teamName: "Autonomous AGV", item: "Arduino Uno R3", avail: 30, qty: 2, status: "Pending", date: "2025-07-04", slot: "2.00-3.00" },
        { id: "REQ-008", teamId: "TEAM-015", teamName: "Waste Management", item: "Ultrasonic Sensor", avail: 30, qty: 4, status: "Fully Issued", date: "2025-06-27", slot: "2.00-3.00" },
        { id: "REQ-009", teamId: "TEAM-001", teamName: "Solar Car Project", item: "Raspberry Pi 4", avail: 30, qty: 2, status: "Pending", date: "2025-07-05", slot: "2.00-3.00" },
        { id: "REQ-010", teamId: "TEAM-002", teamName: "Drone Flight Tech", item: "PIR Motion Sensor", avail: 30, qty: 6, status: "Fully Issued", date: "2025-06-29", slot: "2.00-3.00" },
        { id: "REQ-011", teamId: "TEAM-003", teamName: "Bio-Sensor Systems", item: "16x2 LCD Display", avail: 30, qty: 4, status: "Pending", date: "2025-07-05", slot: "2.00-3.00" },
        { id: "REQ-012", teamId: "TEAM-004", teamName: "Haptic Arm Development", item: "Bipolar NEMA 17", avail: 30, qty: 3, status: "Rejected", date: "2025-06-26", slot: "2.00-3.00" },
        { id: "REQ-013", teamId: "TEAM-005", teamName: "Smart Irrigation System", item: "Arduino Uno R3", avail: 30, qty: 5, status: "Fully Issued", date: "2025-07-01", slot: "2.00-3.00" },
        { id: "REQ-014", teamId: "TEAM-006", teamName: "Eco Waste Sorter", item: "Raspberry Pi 4", avail: 30, qty: 1, status: "Pending", date: "2025-07-04", slot: "2.00-3.00" },
        { id: "REQ-015", teamId: "TEAM-006", teamName: "Eco Waste Sorter", item: "Ultrasonic Sensor", avail: 30, qty: 8, status: "Fully Issued", date: "2025-06-30", slot: "2.00-3.00" },
        { id: "REQ-016", teamId: "TEAM-007", teamName: "VTOL UAV Propulsion", item: "LiPo Battery 11.1V", avail: 30, qty: 6, status: "Fully Issued", date: "2025-07-02", slot: "2.00-3.00" },
        { id: "REQ-017", teamId: "TEAM-007", teamName: "VTOL UAV Propulsion", item: "DC Motor 12V", avail: 30, qty: 4, status: "Pending", date: "2025-07-05", slot: "2.00-3.00" },
        { id: "REQ-018", teamId: "TEAM-008", teamName: "3D Prosthetic Hand", item: "Li-ion Battery 18650", avail: 30, qty: 8, status: "Pending", date: "2025-07-04", slot: "2.00-3.00" },
        { id: "REQ-019", teamId: "TEAM-009", teamName: "Autonomous AGV", item: "PIR Motion Sensor", avail: 30, qty: 5, status: "Fully Issued", date: "2025-06-28", slot: "2.00-3.00" },
        { id: "REQ-020", teamId: "TEAM-010", teamName: "Water Purifier IoT", item: "Soil Moisture Sensor", avail: 30, qty: 6, status: "Fully Issued", date: "2025-07-01", slot: "2.00-3.00" },
        { id: "REQ-021", teamId: "TEAM-010", teamName: "Water Purifier IoT", item: "Arduino Uno R3", avail: 30, qty: 2, status: "Pending", date: "2025-07-05", slot: "2.00-3.00" },
        { id: "REQ-022", teamId: "TEAM-011", teamName: "Robotics Arm Team", item: "Bipolar NEMA 17", avail: 30, qty: 8, status: "Fully Issued", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-023", teamId: "TEAM-012", teamName: "Smart Traffic Guard", item: "Raspberry Pi 4", avail: 30, qty: 2, status: "Fully Issued", date: "2025-06-29", slot: "2.00-3.00" },
        { id: "REQ-024", teamId: "TEAM-012", teamName: "Smart Traffic Guard", item: "PIR Motion Sensor", avail: 30, qty: 10, status: "Pending", date: "2025-07-04", slot: "2.00-3.00" },
        { id: "REQ-025", teamId: "TEAM-013", teamName: "Ocean Cleaner Probe", item: "DC Motor 12V", avail: 30, qty: 3, status: "Fully Issued", date: "2025-07-02", slot: "2.00-3.00" },
        { id: "REQ-026", teamId: "TEAM-013", teamName: "Ocean Cleaner Probe", item: "Li-ion Battery 18650", avail: 30, qty: 12, status: "Pending", date: "2025-07-05", slot: "2.00-3.00" },
        { id: "REQ-027", teamId: "TEAM-014", teamName: "RFID Warehouse Robot", item: "Arduino Uno R3", avail: 30, qty: 4, status: "Fully Issued", date: "2025-06-30", slot: "2.00-3.00" },
        { id: "REQ-028", teamId: "TEAM-014", teamName: "RFID Warehouse Robot", item: "16x2 LCD Display", avail: 30, qty: 6, status: "Rejected", date: "2025-06-27", slot: "2.00-3.00" },
        { id: "REQ-029", teamId: "TEAM-015", teamName: "Waste Management", item: "Soil Moisture Sensor", avail: 30, qty: 5, status: "Pending", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-030", teamId: "TEAM-004", teamName: "Haptic Arm Development", item: "16x2 LCD Display", avail: 30, qty: 2, status: "Pending", date: "2025-07-05", slot: "2.00-3.00" },
        { id: "REQ-031", teamId: "TEAM-016", teamName: "Exoskeleton Suit", item: "Bipolar NEMA 17", avail: 30, qty: 6, status: "Fully Issued", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-032", teamId: "TEAM-016", teamName: "Exoskeleton Suit", item: "Arduino Uno R3", avail: 30, qty: 3, status: "Pending", date: "2025-07-06", slot: "2.00-3.00" },
        { id: "REQ-033", teamId: "TEAM-017", teamName: "Nano Filtration Unit", item: "Soil Moisture Sensor", avail: 30, qty: 8, status: "Fully Issued", date: "2025-07-02", slot: "2.00-3.00" },
        { id: "REQ-034", teamId: "TEAM-017", teamName: "Nano Filtration Unit", item: "DC Motor 12V", avail: 30, qty: 2, status: "Pending", date: "2025-07-06", slot: "2.00-3.00" },
        { id: "REQ-035", teamId: "TEAM-018", teamName: "AI Crop Monitor", item: "Raspberry Pi 4", avail: 30, qty: 3, status: "Fully Issued", date: "2025-07-04", slot: "2.00-3.00" },
        { id: "REQ-036", teamId: "TEAM-018", teamName: "AI Crop Monitor", item: "PIR Motion Sensor", avail: 30, qty: 6, status: "Pending", date: "2025-07-06", slot: "2.00-3.00" },
        { id: "REQ-037", teamId: "TEAM-019", teamName: "Swarm Robotics Lab", item: "Arduino Uno R3", avail: 30, qty: 8, status: "Fully Issued", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-038", teamId: "TEAM-019", teamName: "Swarm Robotics Lab", item: "LiPo Battery 11.1V", avail: 30, qty: 5, status: "Pending", date: "2025-07-06", slot: "2.00-3.00" },
        { id: "REQ-039", teamId: "TEAM-020", teamName: "EV Charging Station", item: "Li-ion Battery 18650", avail: 30, qty: 20, status: "Fully Issued", date: "2025-07-04", slot: "2.00-3.00" },
        { id: "REQ-040", teamId: "TEAM-020", teamName: "EV Charging Station", item: "Variable DC Power Supply", avail: 30, qty: 1, status: "Pending", date: "2025-07-06", slot: "2.00-3.00" },
        { id: "REQ-041", teamId: "TEAM-021", teamName: "Underwater ROV", item: "DC Motor 12V", avail: 30, qty: 4, status: "Fully Issued", date: "2025-07-03", slot: "2.00-3.00" },
        { id: "REQ-042", teamId: "TEAM-021", teamName: "Underwater ROV", item: "Raspberry Pi 4", avail: 30, qty: 2, status: "Pending", date: "2025-07-06", slot: "2.00-3.00" }
    ],

    materialReturns: (function () {
        // Helper: offset days from today
        function daysFromToday(n) {
            const d = new Date();
            d.setDate(d.getDate() + n);
            return d.toISOString().slice(0, 10);
        }
        return [
            { id: "RET-001", teamId: "TEAM-001", teamName: "Solar Car Project", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(-4) },
            { id: "RET-002", teamId: "TEAM-003", teamName: "Bio-Sensor Systems", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(-10) },
            { id: "RET-003", teamId: "TEAM-005", teamName: "Smart Irrigation System", item: "Soldering Station", qty: 2, status: "Pending", date: daysFromToday(10) },
            { id: "RET-004", teamId: "TEAM-011", teamName: "Robotics Arm Team", item: "Variable DC Power Supply", qty: 1, status: "Pending", date: daysFromToday(7) },
            { id: "RET-005", teamId: "TEAM-002", teamName: "Drone Flight Tech", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(-3) },
            { id: "RET-006", teamId: "TEAM-013", teamName: "Ocean Cleaner Probe", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(9) },
            { id: "RET-007", teamId: "TEAM-001", teamName: "Solar Car Project", item: "Laser Cutter", qty: 1, status: "Pending", date: daysFromToday(8) },
            { id: "RET-008", teamId: "TEAM-001", teamName: "Solar Car Project", item: "3D Printer", qty: 1, status: "Pending", date: daysFromToday(-7) },
            { id: "RET-009", teamId: "TEAM-002", teamName: "Drone Flight Tech", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(6) },
            { id: "RET-010", teamId: "TEAM-002", teamName: "Drone Flight Tech", item: "Hot Air Rework Station", qty: 1, status: "Pending", date: daysFromToday(-11) },
            { id: "RET-011", teamId: "TEAM-003", teamName: "Bio-Sensor Systems", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(5) },
            { id: "RET-012", teamId: "TEAM-003", teamName: "Bio-Sensor Systems", item: "Variable DC Power Supply", qty: 1, status: "Pending", date: daysFromToday(-2) },
            { id: "RET-013", teamId: "TEAM-004", teamName: "Haptic Arm Development", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(-13) },
            { id: "RET-014", teamId: "TEAM-005", teamName: "Smart Irrigation System", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(-1) },
            { id: "RET-015", teamId: "TEAM-005", teamName: "Smart Irrigation System", item: "3D Printer", qty: 1, status: "Pending", date: daysFromToday(11) },
            { id: "RET-016", teamId: "TEAM-006", teamName: "Eco Waste Sorter", item: "Laser Cutter", qty: 1, status: "Pending", date: daysFromToday(4) },
            { id: "RET-017", teamId: "TEAM-006", teamName: "Eco Waste Sorter", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(-9) },
            { id: "RET-018", teamId: "TEAM-007", teamName: "VTOL UAV Propulsion", item: "CNC Milling Machine", qty: 1, status: "Pending", date: daysFromToday(13) },
            { id: "RET-019", teamId: "TEAM-007", teamName: "VTOL UAV Propulsion", item: "3D Scanner", qty: 1, status: "Pending", date: daysFromToday(-5) },
            { id: "RET-020", teamId: "TEAM-007", teamName: "VTOL UAV Propulsion", item: "Hot Air Rework Station", qty: 1, status: "Pending", date: daysFromToday(-12) },
            { id: "RET-021", teamId: "TEAM-008", teamName: "3D Prosthetic Hand", item: "3D Printer", qty: 1, status: "Pending", date: daysFromToday(5) },
            { id: "RET-022", teamId: "TEAM-008", teamName: "3D Prosthetic Hand", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(-4) },
            { id: "RET-023", teamId: "TEAM-009", teamName: "Autonomous AGV", item: "Laser Cutter", qty: 1, status: "Pending", date: daysFromToday(7) },
            { id: "RET-024", teamId: "TEAM-009", teamName: "Autonomous AGV", item: "Variable DC Power Supply", qty: 1, status: "Pending", date: daysFromToday(-8) },
            { id: "RET-025", teamId: "TEAM-010", teamName: "Water Purifier IoT", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(6) },
            { id: "RET-026", teamId: "TEAM-010", teamName: "Water Purifier IoT", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(-3) },
            { id: "RET-027", teamId: "TEAM-011", teamName: "Robotics Arm Team", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(-6) },
            { id: "RET-028", teamId: "TEAM-012", teamName: "Smart Traffic Guard", item: "3D Printer", qty: 1, status: "Pending", date: daysFromToday(9) },
            { id: "RET-029", teamId: "TEAM-012", teamName: "Smart Traffic Guard", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(-2) },
            { id: "RET-030", teamId: "TEAM-013", teamName: "Ocean Cleaner Probe", item: "Laser Cutter", qty: 1, status: "Pending", date: daysFromToday(-5) },
            { id: "RET-031", teamId: "TEAM-014", teamName: "RFID Warehouse Robot", item: "Variable DC Power Supply", qty: 1, status: "Pending", date: daysFromToday(8) },
            { id: "RET-032", teamId: "TEAM-014", teamName: "RFID Warehouse Robot", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(-1) },
            { id: "RET-033", teamId: "TEAM-015", teamName: "Waste Management", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(10) },
            { id: "RET-034", teamId: "TEAM-015", teamName: "Waste Management", item: "Hot Air Rework Station", qty: 1, status: "Pending", date: daysFromToday(-10) },
            { id: "RET-035", teamId: "TEAM-016", teamName: "Exoskeleton Suit", item: "Variable DC Power Supply", qty: 1, status: "Pending", date: daysFromToday(11) },
            { id: "RET-036", teamId: "TEAM-016", teamName: "Exoskeleton Suit", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(-7) },
            { id: "RET-037", teamId: "TEAM-017", teamName: "Nano Filtration Unit", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(9) },
            { id: "RET-038", teamId: "TEAM-017", teamName: "Nano Filtration Unit", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(-2) },
            { id: "RET-039", teamId: "TEAM-018", teamName: "AI Crop Monitor", item: "3D Printer", qty: 1, status: "Pending", date: daysFromToday(12) },
            { id: "RET-040", teamId: "TEAM-018", teamName: "AI Crop Monitor", item: "Laser Cutter", qty: 1, status: "Pending", date: daysFromToday(-8) },
            { id: "RET-041", teamId: "TEAM-019", teamName: "Swarm Robotics Lab", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(10) },
            { id: "RET-042", teamId: "TEAM-019", teamName: "Swarm Robotics Lab", item: "Hot Air Rework Station", qty: 1, status: "Pending", date: daysFromToday(-9) },
            { id: "RET-043", teamId: "TEAM-020", teamName: "EV Charging Station", item: "Variable DC Power Supply", qty: 1, status: "Pending", date: daysFromToday(8) },
            { id: "RET-044", teamId: "TEAM-020", teamName: "EV Charging Station", item: "Bench Multimeter", qty: 1, status: "Pending", date: daysFromToday(-1) },
            { id: "RET-045", teamId: "TEAM-021", teamName: "Underwater ROV", item: "Digital Oscilloscope", qty: 1, status: "Pending", date: daysFromToday(11) },
            { id: "RET-046", teamId: "TEAM-021", teamName: "Underwater ROV", item: "Soldering Station", qty: 1, status: "Pending", date: daysFromToday(-6) }
        ];
    })(),

    tickets: [
        {
            id: "TKT-001", type: "Procurement", assignedTo: "Administrator", subject: "Low Stock Components", priority: "High", date: "04 Jul 2025", status: "Open", assigneeRole: "System Admin", raisedBy: "Dr. Priya Sharma", time: "10:15 AM", reason: "Multiple inventory components have reached the minimum stock level. Procurement approval is requested to maintain smooth lab operations.", items: [
                { name: "Arduino Uno R3", qty: "05", min: "10" },
                { name: "Soil Moisture Sensor", qty: "02", min: "05" },
                { name: "16x2 LCD Display", qty: "03", min: "05" },
                { name: "DC Motor 12V", qty: "01", min: "03" },
                { name: "Li-ion Battery 18650", qty: "04", min: "10" }
            ], adminResponse: ""
        },

        { id: "TKT-002", type: "Damage", assignedTo: "TEAM-005", subject: "Arduino Uno R3 Damaged", priority: "Medium", date: "03 Jul 2025", status: "Pending", teamName: "Smart Irrigation System", equipmentName: "Arduino Uno R3", raisedBy: "Lab Incharge", time: "02:15 PM", damageDescription: "USB port is physically damaged during project testing.", fineAmount: "500", dueDate: "10 Jul 2025", remarks: "Fine to be paid by the team before next material issue.", teamResponse: "", lastUpdated: "03 Jul 2025, 02:15 PM" },

        { id: "TKT-003", type: "Damage", assignedTo: "TEAM-011", subject: "DC Motor 12V Broken", priority: "High", date: "02 Jul 2025", status: "In Progress", teamName: "Robotics Arm", equipmentName: "DC Motor 12V", raisedBy: "Lab Incharge", time: "11:30 AM", damageDescription: "Motor coil burned out due to overloading.", fineAmount: "300", dueDate: "09 Jul 2025", remarks: "Replacement motor cost.", teamResponse: "We have received the notice. Discussing with team leader.", lastUpdated: "02 Jul 2025, 03:00 PM" },

        {
            id: "TKT-004", type: "Procurement", assignedTo: "Administrator", subject: "Request for Additional Sensors", priority: "Medium", date: "01 Jul 2025", status: "In Progress", assigneeRole: "System Admin", raisedBy: "Dr. Priya Sharma", time: "09:45 AM", reason: "Additional sensors needed for upcoming workshop.", items: [
                { name: "Ultrasonic Sensor", qty: "15", min: "05" },
                { name: "PIR Motion Sensor", qty: "20", min: "05" }
            ], adminResponse: "Quotation requested from vendor."
        },

        { id: "TKT-005", type: "Damage", assignedTo: "TEAM-008", subject: "16x2 LCD Display Cracked", priority: "Low", date: "30 Jun 2025", status: "Resolved", teamName: "3D Prosthetic Hand", equipmentName: "16x2 LCD Display", raisedBy: "Lab Incharge", time: "04:00 PM", damageDescription: "Screen cracked during mechanical assembly mounting.", fineAmount: "150", dueDate: "07 Jul 2025", remarks: "Standard replacement fine.", teamResponse: "Fine paid. Receipt number #88271.", lastUpdated: "01 Jul 2025, 10:20 AM" },

        {
            id: "TKT-006", type: "Procurement", assignedTo: "Administrator", subject: "Low Stock - Batteries", priority: "High", date: "29 Jun 2025", status: "Resolved", assigneeRole: "System Admin", raisedBy: "Dr. Priya Sharma", time: "11:20 AM", reason: "Li-ion Battery stock critically low.", items: [
                { name: "Li-ion Battery 18650", qty: "02", min: "10" }
            ], adminResponse: "PO Issued. Delivery expected by next week."
        },

        { id: "TKT-007", type: "Damage", assignedTo: "TEAM-015", subject: "Soil Moisture Sensor Damaged", priority: "Medium", date: "28 Jun 2025", status: "Open", teamName: "Waste Management", equipmentName: "Soil Moisture Sensor", raisedBy: "Lab Incharge", time: "10:00 AM", damageDescription: "Corrosion due to extended water immersion test without waterproofing cover.", fineAmount: "200", dueDate: "05 Jul 2025", remarks: "Cost of sensor replacement.", teamResponse: "", lastUpdated: "28 Jun 2025, 10:00 AM" }
    ],
    bookedEquipment: [],
    equipmentRequests: [
        {
            teamId: "TEAM-001",
            teamName: "Solar Car Project",
            requests: [
                { id: "ER-101", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "10:00 AM - 12:00 PM", status: "Rejected", rejectionReason: "Sent for Repair" },
                { id: "ER-102", equipmentType: "Manufacturing", equipmentId: "EQ-005", equipmentName: "CNC Milling Machine", timeSlot: "02:00 PM - 04:00 PM", status: "Approved", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-002",
            teamName: "Drone Flight Tech",
            requests: [
                { id: "ER-201", equipmentType: "Manufacturing", equipmentId: "EQ-010", equipmentName: "Laser Cutter", timeSlot: "11:00 AM - 01:00 PM", status: "Rejected", rejectionReason: "It is damaged and it will available from tomorrow" }
            ]
        },
        {
            teamId: "TEAM-003",
            teamName: "Bio-Sensor Systems",
            requests: [
                { id: "ER-301", equipmentType: "Electronics", equipmentId: "EQ-006", equipmentName: "Digital Oscilloscope", timeSlot: "09:00 AM - 11:00 AM", status: "Approved", rejectionReason: "" },
                { id: "ER-302", equipmentType: "Electronics", equipmentId: "EQ-018", equipmentName: "Variable DC Power Supply", timeSlot: "01:00 PM - 03:00 PM", status: "Approved", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-005",
            teamName: "Smart Irrigation System",
            requests: [
                { id: "ER-501", equipmentType: "Electronics", equipmentId: "EQ-012", equipmentName: "Soldering Station", timeSlot: "02:00 PM - 04:00 PM", status: "Rejected", rejectionReason: "Sent for Repair" }
            ]
        },
        {
            teamId: "TEAM-004",
            teamName: "Haptic Arm Development",
            requests: [
                { id: "ER-401", equipmentType: "Electronics", equipmentId: "EQ-013", equipmentName: "Bench Multimeter", timeSlot: "03:00 PM - 05:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-402", equipmentType: "Manufacturing", equipmentId: "EQ-016", equipmentName: "Hot Air Rework Station", timeSlot: "10:00 AM - 12:00 PM", status: "Pending", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-006",
            teamName: "Eco Waste Sorter",
            requests: [
                { id: "ER-601", equipmentType: "Manufacturing", equipmentId: "EQ-010", equipmentName: "Laser Cutter", timeSlot: "02:00 PM - 04:00 PM", status: "Rejected", rejectionReason: "Slot not available, try next week" },
                { id: "ER-602", equipmentType: "Electronics", equipmentId: "EQ-011", equipmentName: "Raspberry Pi 4", timeSlot: "11:00 AM - 01:00 PM", status: "Approved", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-007",
            teamName: "VTOL UAV Propulsion",
            requests: [
                { id: "ER-701", equipmentType: "Manufacturing", equipmentId: "EQ-005", equipmentName: "CNC Milling Machine", timeSlot: "09:00 AM - 12:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-702", equipmentType: "Manufacturing", equipmentId: "EQ-019", equipmentName: "3D Scanner", timeSlot: "01:00 PM - 02:00 PM", status: "Pending", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-008",
            teamName: "3D Prosthetic Hand",
            requests: [
                { id: "ER-801", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "01:00 PM - 03:00 PM", status: "Rejected", rejectionReason: "Maintenance scheduled on this date" }
            ]
        },
        {
            teamId: "TEAM-009",
            teamName: "Autonomous AGV",
            requests: [
                { id: "ER-901", equipmentType: "Manufacturing", equipmentId: "EQ-010", equipmentName: "Laser Cutter", timeSlot: "10:00 AM - 12:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-902", equipmentType: "Electronics", equipmentId: "EQ-006", equipmentName: "Digital Oscilloscope", timeSlot: "02:00 PM - 04:00 PM", status: "Pending", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-010",
            teamName: "Water Purifier IoT",
            requests: [
                { id: "ER-1001", equipmentType: "Electronics", equipmentId: "EQ-012", equipmentName: "Soldering Station", timeSlot: "09:00 AM - 11:00 AM", status: "Approved", rejectionReason: "" },
                { id: "ER-1002", equipmentType: "Electronics", equipmentId: "EQ-013", equipmentName: "Bench Multimeter", timeSlot: "11:00 AM - 12:00 PM", status: "Rejected", rejectionReason: "Currently in use by another team" }
            ]
        },
        {
            teamId: "TEAM-011",
            teamName: "Robotics Arm Team",
            requests: [
                { id: "ER-1101", equipmentType: "Electronics", equipmentId: "EQ-018", equipmentName: "Variable DC Power Supply", timeSlot: "02:00 PM - 04:00 PM", status: "Pending", rejectionReason: "" },
                { id: "ER-1102", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "03:00 PM - 05:00 PM", status: "Approved", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-012",
            teamName: "Smart Traffic Guard",
            requests: [
                { id: "ER-1201", equipmentType: "Electronics", equipmentId: "EQ-011", equipmentName: "Raspberry Pi 4", timeSlot: "10:00 AM - 12:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-1202", equipmentType: "Electronics", equipmentId: "EQ-017", equipmentName: "PIR Motion Sensor", timeSlot: "01:00 PM - 03:00 PM", status: "Rejected", rejectionReason: "Out of stock" }
            ]
        },
        {
            teamId: "TEAM-013",
            teamName: "Ocean Cleaner Probe",
            requests: [
                { id: "ER-1301", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "09:00 AM - 11:00 AM", status: "Approved", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-014",
            teamName: "RFID Warehouse Robot",
            requests: [
                { id: "ER-1401", equipmentType: "Electronics", equipmentId: "EQ-013", equipmentName: "Bench Multimeter", timeSlot: "11:00 AM - 12:00 PM", status: "Rejected", rejectionReason: "Sent for calibration" },
                { id: "ER-1402", equipmentType: "Electronics", equipmentId: "EQ-006", equipmentName: "Digital Oscilloscope", timeSlot: "02:00 PM - 04:00 PM", status: "Pending", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-015",
            teamName: "Waste Management",
            requests: [
                { id: "ER-1501", equipmentType: "Electronics", equipmentId: "EQ-012", equipmentName: "Soldering Station", timeSlot: "01:00 PM - 03:00 PM", status: "Approved", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-016",
            teamName: "Exoskeleton Suit",
            requests: [
                { id: "ER-1601", equipmentType: "Electronics", equipmentId: "EQ-018", equipmentName: "Variable DC Power Supply", timeSlot: "09:00 AM - 11:00 AM", status: "Approved", rejectionReason: "" },
                { id: "ER-1602", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "01:00 PM - 03:00 PM", status: "Rejected", rejectionReason: "Nozzle replacement in progress" }
            ]
        },
        {
            teamId: "TEAM-017",
            teamName: "Nano Filtration Unit",
            requests: [
                { id: "ER-1701", equipmentType: "Electronics", equipmentId: "EQ-013", equipmentName: "Bench Multimeter", timeSlot: "10:00 AM - 12:00 PM", status: "Pending", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-018",
            teamName: "AI Crop Monitor",
            requests: [
                { id: "ER-1801", equipmentType: "Electronics", equipmentId: "EQ-011", equipmentName: "Raspberry Pi 4", timeSlot: "02:00 PM - 04:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-1802", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "09:00 AM - 11:00 AM", status: "Rejected", rejectionReason: "Filament depleted" }
            ]
        },
        {
            teamId: "TEAM-019",
            teamName: "Swarm Robotics Lab",
            requests: [
                { id: "ER-1901", equipmentType: "Electronics", equipmentId: "EQ-012", equipmentName: "Soldering Station", timeSlot: "10:00 AM - 12:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-1902", equipmentType: "Manufacturing", equipmentId: "EQ-010", equipmentName: "Laser Cutter", timeSlot: "02:00 PM - 04:00 PM", status: "Pending", rejectionReason: "" }
            ]
        },
        {
            teamId: "TEAM-020",
            teamName: "EV Charging Station",
            requests: [
                { id: "ER-2001", equipmentType: "Electronics", equipmentId: "EQ-018", equipmentName: "Variable DC Power Supply", timeSlot: "09:00 AM - 11:00 AM", status: "Rejected", rejectionReason: "Overbooked for this time slot" }
            ]
        },
        {
            teamId: "TEAM-021",
            teamName: "Underwater ROV",
            requests: [
                { id: "ER-2101", equipmentType: "Electronics", equipmentId: "EQ-006", equipmentName: "Digital Oscilloscope", timeSlot: "01:00 PM - 03:00 PM", status: "Approved", rejectionReason: "" },
                { id: "ER-2102", equipmentType: "Manufacturing", equipmentId: "EQ-001", equipmentName: "3D Printer", timeSlot: "10:00 AM - 12:00 PM", status: "Pending", rejectionReason: "" }
            ]
        }
    ]
};

// Generate dummy data up to 32 items for tickets
function fillRemainingTickets() {
    const types = ["Procurement", "Damage"];
    const priorities = ["High", "Medium", "Low"];
    const statuses = ["Open", "Pending", "In Progress", "Resolved"];
    const asignees = [
        { name: "TEAM-006", desc: "Eco Waste sorter" },
        { name: "TEAM-001", desc: "Solar Car Project" },
        { name: "Administrator", desc: "System Admin" },
        { name: "TEAM-002", desc: "Drone Flight Tech" },
        { name: "TEAM-003", desc: "Bio-Sensor Systems" }
    ];
    const equipment = ["Arduino Uno R3", "3D Printer", "CNC Milling Machine", "Digital Oscilloscope", "Raspberry Pi 4"];
    const dates = ["27 Jun 2025", "26 Jun 2025", "25 Jun 2025", "24 Jun 2025", "23 Jun 2025", "22 Jun 2025", "21 Jun 2025", "20 Jun 2025"];

    let baseId = 8;
    while (DEFAULT_DATABASE.tickets.length < 32) {
        const type = types[Math.floor(Math.random() * types.length)];
        const priority = priorities[Math.floor(Math.random() * priorities.length)];
        const status = statuses[Math.floor(Math.random() * statuses.length)];
        const date = dates[Math.floor(Math.random() * dates.length)];
        const id = `TKT-${String(baseId).padStart(3, '0')}`;
        baseId++;

        if (type === "Procurement") {
            DEFAULT_DATABASE.tickets.push({
                id,
                type,
                assignedTo: "Administrator",
                subject: `Refocking ${equipment[Math.floor(Math.random() * equipment.length)]}s`,
                priority,
                date,
                status,
                assigneeRole: "System Admin",
                raisedBy: "Dr. Priya Sharma",
                time: "02:00 PM",
                reason: "Stock replenishment request.",
                items: [
                    { name: "Item Replacements", qty: "02", min: "05" }
                ],
                adminResponse: status === "Resolved" ? "Request processed." : ""
            });
        } else {
            const teamIdx = Math.floor(Math.random() * asignees.length);
            DEFAULT_DATABASE.tickets.push({
                id,
                type,
                assignedTo: asignees[teamIdx].name,
                subject: `${equipment[Math.floor(Math.random() * equipment.length)]} Damaged`,
                priority,
                date,
                status,
                teamName: asignees[teamIdx].desc,
                equipmentName: equipment[Math.floor(Math.random() * equipment.length)],
                raisedBy: "Lab Incharge",
                time: "11:00 AM",
                damageDescription: "Physical structural damage observed post usage.",
                fineAmount: "450",
                dueDate: "12 Jul 2025",
                remarks: "Please deposit the replacement fine.",
                teamResponse: status === "Resolved" ? "Fine cleared." : "",
                lastUpdated: `${date}, 11:30 AM`
            });
        }
    }
}
fillRemainingTickets();


// Initialize LocalStorage database
const DB_VERSION = 12;
let MEMORY_DB = null;

function initLocalStorageDB() {
    try {
        const storedVersion = parseInt(localStorage.getItem("rplms_db_version") || "0");
        if (storedVersion < DB_VERSION) {
            localStorage.setItem("rplms_db", JSON.stringify(DEFAULT_DATABASE));
            localStorage.setItem("rplms_db_version", String(DB_VERSION));
        }
    } catch (e) {
        console.warn("LocalStorage access blocked. Falling back to in-memory database.", e);
        MEMORY_DB = DEFAULT_DATABASE;
    }
}
initLocalStorageDB();

// Read DB helper
function getDB() {
    try {
        return JSON.parse(localStorage.getItem("rplms_db")) || DEFAULT_DATABASE;
    } catch (e) {
        if (!MEMORY_DB) MEMORY_DB = DEFAULT_DATABASE;
        return MEMORY_DB;
    }
}

// Write DB helper
function setDB(db) {
    try {
        localStorage.setItem("rplms_db", JSON.stringify(db));
    } catch (e) {
        MEMORY_DB = db;
    }
}

// // Check logged in state (Bypassed to keep user auto-logged in)
// function checkAuth() {
//     const isLoggedIn = localStorage.getItem("rplms_logged_in");
//     const currentPage = window.location.pathname.split("/").pop();
//     if (!isLoggedIn && currentPage !== "login.html" && currentPage !== "") {
//         window.location.href = "login.html";
//     } else if (isLoggedIn && currentPage === "login.html") {
//         window.location.href = "index.html";
//     }
// }
// checkAuth();

// --- Sidebar & Layout Builder ---

function renderBaseLayout(activeMenu) {
    const db = getDB();
    const user = db.currentUser;

    // Calculate user initials dynamically
    const nameWithoutTitle = user.name.replace(/^(Dr\.|Mr\.|Ms\.|Mrs\.)\s+/i, '');
    const nameParts = nameWithoutTitle.split(/\s+/).filter(Boolean);
    let userInitials = 'F';
    if (nameParts.length > 0) {
        userInitials = nameParts.map(p => p[0]).join('').substring(0, 2).toUpperCase();
    }

    // Update avatar and username if elements exist
    const avatarEl = document.querySelector(".header-avatar");
    if (avatarEl) avatarEl.textContent = userInitials;

    const nameEl = document.querySelector(".header-user-name");
    if (nameEl) nameEl.textContent = user.name;

    // Set active class on sidebar items
    const navItems = document.querySelectorAll(".nav-links .nav-item");
    navItems.forEach(item => {
        item.classList.remove("active");
    });
    
    // Find the item corresponding to activeMenu
    const activeItem = document.querySelector(`.nav-links a[href*="/${activeMenu}/"], .nav-links a[href="${activeMenu}.html"], .nav-links a[href*="${activeMenu}"]`);
    if (activeItem) {
        const parentLi = activeItem.closest(".nav-item");
        if (parentLi) parentLi.classList.add("active");
    }

    // Attach logout click listener
    const logoutBtn = document.querySelector("#logoutBtn");
    if (logoutBtn) {
        logoutBtn.addEventListener("click", () => {
            localStorage.removeItem("rplms_logged_in");
        });
    }

    // Notifications Dropdown dynamic build
    function buildNotificationsDropdown() {
        const dbNow = getDB();
        const notifs = dbNow.notifications || [];
        const unreadCount = notifs.filter(n => n.unread).length;

        // Update the bell badge
        const badge = document.querySelector(".notif-wrapper .icon-badge");
        if (badge) {
            badge.textContent = unreadCount;
            badge.style.display = unreadCount > 0 ? "" : "none";
        }

        const dropdown = document.querySelector(".notifications-dropdown");
        if (!dropdown) return;

        const listHtml = notifs.length === 0
            ? `<div class="notif-empty"><span class="notif-empty-icon">🔔</span>No notifications yet</div>`
            : notifs.map(n => `
                <div class="notif-item ${n.unread ? 'unread' : ''}" data-notif-id="${n.id}">
                    <div class="notif-icon-wrapper ${n.iconClass}">${n.icon}</div>
                    <div class="notif-content">
                        <div class="notif-body">${n.body}</div>
                        <div class="notif-time">${n.time}</div>
                    </div>
                </div>`).join("");

        dropdown.innerHTML = `
            <div class="notif-header">
                <div class="notif-header-title">
                    Notifications
                    ${unreadCount > 0 ? `<span class="notif-count-badge">${unreadCount}</span>` : ''}
                </div>
                ${unreadCount > 0 ? '<button class="notif-header-action" id="markAllReadBtn">Mark all read</button>' : ''}
            </div>
            <div class="notif-list">${listHtml}</div>
        `;

        // Mark all read
        const markAllBtn = dropdown.querySelector("#markAllReadBtn");
        if (markAllBtn) {
            markAllBtn.addEventListener("click", (e) => {
                e.stopPropagation();
                const db2 = getDB();
                db2.notifications.forEach(n => n.unread = false);
                setDB(db2);
                buildNotificationsDropdown();
            });
        }

        // Mark individual as read on click
        dropdown.querySelectorAll(".notif-item").forEach(el => {
            el.addEventListener("click", () => {
                const id = el.dataset.notifId;
                const db2 = getDB();
                const notif = db2.notifications.find(n => n.id === id);
                if (notif) { notif.unread = false; setDB(db2); }
                buildNotificationsDropdown();
            });
        });
    }

    // Toggle dropdown open/close
    const bellBtn = document.querySelector(".notif-wrapper .header-icon-btn");
    const notifDropdown = document.querySelector(".notifications-dropdown");
    if (bellBtn && notifDropdown) {
        // Remove old listeners to avoid stacking
        const newBellBtn = bellBtn.cloneNode(true);
        bellBtn.parentNode.replaceChild(newBellBtn, bellBtn);

        newBellBtn.addEventListener("click", (e) => {
            e.stopPropagation();
            const isOpen = notifDropdown.classList.toggle("open");
            if (isOpen) buildNotificationsDropdown();
        });

        // Close on outside click
        document.addEventListener("click", (e) => {
            if (!e.target.closest(".notif-wrapper")) {
                notifDropdown.classList.remove("open");
            }
        });

        // Initialize badge on page load
        buildNotificationsDropdown();
    }
}

// Custom Toast notification loader
function showToast(message, type = "success") {
    let container = document.querySelector(".toast-container");
    if (!container) {
        container = document.createElement("div");
        container.className = "toast-container";
        document.body.appendChild(container);
    }

    const toast = document.createElement("div");
    toast.className = `toast ${type}`;

    let icon = "&#10003;";
    if (type === "error") icon = "&#9888;";
    if (type === "warn") icon = "&#9757;";
    if (type === "info") icon = "&#8505;";

    toast.innerHTML = `
    <div class="toast-content">
      <span class="toast-icon">${icon}</span>
      <span class="toast-message">${message}</span>
    </div>
    <button class="toast-close">&times;</button>
  `;

    container.appendChild(toast);

    // Trigger show layout
    setTimeout(() => toast.classList.add("show"), 10);

    // Auto remove after 4 seconds
    const autoClose = setTimeout(() => {
        toast.classList.remove("show");
        setTimeout(() => toast.remove(), 300);
    }, 4000);

    // Close button trigger
    toast.querySelector(".toast-close").addEventListener("click", () => {
        clearTimeout(autoClose);
        toast.classList.remove("show");
        setTimeout(() => toast.remove(), 300);
    });
}

// Confirmation Popups Setup
function createConfirmationModal(title, bodyText, confirmCallback, confirmText = "Confirm", isDanger = false) {
    // Check if confirmation modal backdrop already exists
    let backdrop = document.getElementById("confirmModalBackdrop");
    if (!backdrop) {
        backdrop = document.createElement("div");
        backdrop.id = "confirmModalBackdrop";
        backdrop.className = "modal-backdrop";
        document.body.appendChild(backdrop);
    }

    backdrop.innerHTML = `
    <div class="modal-container" style="max-width: 420px;">
      <div class="modal-header" style="padding: 20px 24px;">
        <div class="modal-header-left">
          <div class="circle-icon-wrapper ${isDanger ? 'red-alert' : 'blue-info'}" style="width: 40px; height: 40px; font-size: 16px;">
            ${isDanger ? '&#9888;' : '&#8505;'}
          </div>
          <div class="card-header-text">
            <span class="card-title">${title}</span>
          </div>
        </div>
        <button class="modal-close-btn" id="confirmModalClose">&times;</button>
      </div>
      <div class="modal-body" style="padding: 20px 24px; font-size: 13px; color: var(--text-secondary); line-height: 1.5;">
        ${bodyText}
      </div>
      <div class="modal-footer" style="padding: 12px 24px;">
        <button class="btn btn-secondary" id="confirmCancelBtn" style="padding: 8px 16px; font-size: 12px;">Cancel</button>
        <button class="btn ${isDanger ? 'btn-danger' : 'btn-primary'}" id="confirmConfirmBtn" style="padding: 8px 16px; font-size: 12px;">${confirmText}</button>
      </div>
    </div>
  `;

    // Escape key handler
    const escapeHandler = function (e) {
        if (e.key === "Escape") {
            closeConfirm();
        }
    };

    function openConfirm() {
        backdrop.classList.add("show");
        document.addEventListener("keydown", escapeHandler);
    }

    function closeConfirm() {
        backdrop.classList.remove("show");
        document.removeEventListener("keydown", escapeHandler);
        setTimeout(() => backdrop.remove(), 300);
    }

    // Bind cancel actions
    backdrop.querySelector("#confirmModalClose").addEventListener("click", closeConfirm);
    backdrop.querySelector("#confirmCancelBtn").addEventListener("click", closeConfirm);
    backdrop.addEventListener("click", (e) => {
        if (e.target === backdrop) closeConfirm();
    });

    // Bind confirm action
    backdrop.querySelector("#confirmConfirmBtn").addEventListener("click", () => {
        confirmCallback();
        closeConfirm();
    });

    openConfirm();
}



// Debounce search inputs helper
function debounce(func, delay = 300) {
    let timer;
    return function (...args) {
        clearTimeout(timer);
        timer = setTimeout(() => {
            func.apply(this, args);
        }, delay);
    };
}

// Escape inputs to prevent XSS
function escapeHtml(str) {
    if (typeof str !== 'string') return str;
    return str.replace(/[&<>"']/g, function (match) {
        switch (match) {
            case '&': return '&amp;';
            case '<': return '&lt;';
            case '>': return '&gt;';
            case '"': return '&quot;';
            case "'": return '&#39;';
        }
    });
}

// Basic SQL injection keyword check
function hasSqlInfectionRisk(str) {
    if (typeof str !== 'string') return false;
    const sqlRegex = /\b(select|insert|update|delete|drop|alter|union|where|exec|truncate)\b/gi;
    return sqlRegex.test(str);
}
//common.js

/* === js/asset-exceptions.js === */
/**
 * Asset Exceptions Portal Engine
 * Implements filters, tabs, verification forms, timeline generation,
 * and database integration with localStorage.
 */

// ==========================================================================
// 1. INITIAL EXCEPTIONS DATASET
// ==========================================================================
const initialExceptions = [
  {
    id: "EX-2025-0012",
    assetId: "CMP-002",
    asset: "Arduino Uno",
    type: "Missing",
    category: "Component",
    team: "Team Alpha",
    project: "Smart Irrigation",
    faculty: "Dr. Kumar",
    reportedBy: "Lab In-Charge",
    reportedOn: "18 May 2025",
    returnedOn: "15 May 2025",
    daysOpen: 2,
    status: "Open",
    returnId: "RET-2025-0045",
    remarks: "Student informed the board is misplaced during testing session.",
    timeline: [
      { time: "18 May 2025 10:15 AM", title: "Return verification completed", desc: "By Lab In-Charge", type: "system" },
      { time: "18 May 2025 10:30 AM", title: "Missing exception created", desc: "Exception record EX-2025-0012 generated", type: "system" },
      { time: "18 May 2025 03:00 PM", title: "Notified to Senior Faculty", desc: "Dr. Kumar was alert notification about exception", type: "notification" },
      { time: "", title: "Pending decision", desc: "Awaiting resolution review", type: "pending" }
    ],
    decision: null
  },
  {
    id: "EX-2025-0011",
    assetId: "TOL-025",
    asset: "Digital Multimeter",
    type: "Damaged",
    category: "Tool",
    team: "Team Beta",
    project: "Drone Prototype",
    faculty: "Dr. Kumar",
    reportedBy: "Lab In-Charge",
    reportedOn: "10 May 2025",
    returnedOn: "09 May 2025",
    daysOpen: 6,
    status: "Waiting Approval",
    returnId: "RET-2025-0038",
    remarks: "Probe input terminal socket has crack damage and burns.",
    timeline: [
      { time: "10 May 2025 09:30 AM", title: "Return verification completed", desc: "By Lab In-Charge", type: "system" },
      { time: "10 May 2025 09:45 AM", title: "Damaged exception created", desc: "Probe input terminal socket damage reported", type: "system" },
      { time: "11 May 2025 11:00 AM", title: "Under review by Senior Faculty", desc: "Assigned to Dr. Kumar", type: "active" }
    ],
    decision: {
      type: "Accepted",
      decisionBy: "Dr. Kumar (Senior Faculty)",
      date: "15 May 2025 11:30 AM",
      remarks: "Damage accepted. Student will pay for replacement as per lab policy.",
      attachment: "decision_doc.pdf"
    }
  },
  {
    id: "EX-2025-0010",
    assetId: "CMP-007",
    asset: "Breadboard",
    type: "Missing",
    category: "Component",
    team: "Team Gamma",
    project: "Home Automation",
    faculty: "Prof. Ramesh",
    reportedBy: "Lab In-Charge",
    reportedOn: "13 May 2025",
    returnedOn: "16 May 2025",
    daysOpen: 1,
    status: "Found Awaiting Verify",
    returnId: "RET-2025-0042",
    remarks: "Breadboard core was lost at the workspace, but later retrieved by team leader.",
    timeline: [
      { time: "13 May 2025 02:00 PM", title: "Return verification completed", desc: "Missing Breadboard reported", type: "system" },
      { time: "16 May 2025 01:30 PM", title: "Asset found notification", desc: "Retrieved by Gamma team leader", type: "action" }
    ],
    decision: null
  },
  {
    id: "EX-2025-0009",
    assetId: "TOL-004",
    asset: "Vernier Caliper",
    type: "Damaged",
    category: "Tool",
    team: "Team Delta",
    project: "CNC Machine",
    faculty: "Dr. Priya",
    reportedBy: "Lab In-Charge",
    reportedOn: "01 May 2025",
    returnedOn: "15 May 2025",
    daysOpen: 15,
    status: "Closed",
    returnId: "RET-2025-0021",
    remarks: "Vernier scale locking screw is stripped.",
    timeline: [
      { time: "01 May 2025 11:00 AM", title: "Return verification completed", desc: "Locking screw damage reported", type: "system" },
      { time: "05 May 2025 03:00 PM", title: "Under review by Senior Faculty", desc: "Assigned to Dr. Priya", type: "system" },
      { time: "15 May 2025 04:45 PM", title: "Decision: Accepted", desc: "By Dr. Priya", type: "completed" },
      { time: "15 May 2025 05:00 PM", title: "Case closed", desc: "Minor damage accepted. No further action required.", type: "closed" }
    ],
    decision: {
      type: "Accepted",
      decisionBy: "Dr. Priya (Senior Faculty)",
      date: "15 May 2025 04:45 PM",
      remarks: "Minor damage accepted. No further action required.",
      attachment: "return_photo.jpg"
    }
  },
  {
    id: "EX-2025-0008",
    assetId: "TOL-022",
    asset: "Screwdriver Set",
    type: "Missing",
    category: "Tool",
    team: "Team Epsilon",
    project: "Robotics Arm",
    faculty: "Dr. Kumar",
    reportedBy: "Lab In-Charge",
    reportedOn: "24 Apr 2025",
    returnedOn: "24 Apr 2025",
    daysOpen: 22,
    status: "Waiting Approval",
    returnId: "RET-2025-0010",
    remarks: "Complete screwdriver set is missing from tool kit slot.",
    timeline: [
      { time: "24 Apr 2025 11:00 AM", title: "Return verification completed", desc: "By Lab In-Charge", type: "system" },
      { time: "24 Apr 2025 11:15 AM", title: "Missing exception created", desc: "Record EX-2025-0008 generated", type: "system" },
      { time: "26 Apr 2025 09:30 AM", title: "Notified to Senior Faculty", desc: "Dr. Kumar alert raised", type: "notification" }
    ],
    decision: null
  },
  {
    id: "EX-2025-0015",
    assetId: "CMP-009",
    asset: "Battery Pack",
    type: "Damaged",
    category: "Component",
    team: "Team Zeta",
    project: "Electric Kart",
    faculty: "Prof. Ramesh",
    reportedBy: "Lab In-Charge",
    reportedOn: "15 May 2025",
    returnedOn: "14 May 2025",
    daysOpen: 1,
    status: "Open",
    returnId: "RET-2025-0035",
    remarks: "Battery swelling exception reported.",
    timeline: [
      { time: "15 May 2025 09:00 AM", title: "Return verification completed", desc: "By Lab In-Charge", type: "system" },
      { time: "15 May 2025 09:15 AM", title: "Damaged exception created", desc: "Record EX-2025-0015 generated", type: "system" }
    ],
    decision: null
  },
  {
    id: "EX-2025-0017",
    assetId: "CMP-002",
    asset: "Raspberry Pi 4",
    type: "Missing",
    category: "Component",
    team: "Team Theta",
    project: "AI Camera",
    faculty: "Dr. Kumar",
    reportedBy: "Lab In-Charge",
    reportedOn: "13 May 2025",
    returnedOn: "13 May 2025",
    daysOpen: 3,
    status: "Open",
    returnId: "RET-2025-0029",
    remarks: "Misplaced in test lab. Searching in progress.",
    timeline: [
      { time: "13 May 2025 10:00 AM", title: "Return verification completed", desc: "By Lab In-Charge", type: "system" }
    ],
    decision: null
  },
  {
    id: "EX-2025-0020",
    assetId: "TOL-018",
    asset: "Power Supply",
    type: "Damaged",
    category: "Tool",
    team: "Team Kappa",
    project: "Lab Automation",
    faculty: "Dr. Kumar",
    reportedBy: "Lab In-Charge",
    reportedOn: "11 May 2025",
    returnedOn: "11 May 2025",
    daysOpen: 5,
    status: "Open",
    returnId: "RET-2025-0026",
    remarks: "Overvoltage protection trigger damage.",
    timeline: [
      { time: "11 May 2025 04:00 PM", title: "Return verification completed", desc: "By Lab In-Charge", type: "system" }
    ],
    decision: null
  }
];

// ==========================================================================
// 2. STATE OBJECT
// ==========================================================================
const state = {
  exceptions: [],
  activeExceptionId: null,
  activeFilterTab: "All", // "All", "Open", "Waiting Approval", "Found Awaiting Verify", "Closed"
  filters: {
    search: "",
    type: "All",
    category: "All",
    faculty: "All",
    date: ""
  }
};

// Helper: load database
function loadDatabase() {
  try {
    const stored = localStorage.getItem("rplms_exceptions");
    if (stored) {
      state.exceptions = JSON.parse(stored);
    } else {
      state.exceptions = JSON.parse(JSON.stringify(initialExceptions));
      localStorage.setItem("rplms_exceptions", JSON.stringify(state.exceptions));
    }
  } catch (e) {
    console.warn("LocalStorage access failed, falling back to memory.", e);
    state.exceptions = JSON.parse(JSON.stringify(initialExceptions));
  }
}

// Helper: save database
function saveDatabase() {
  try {
    localStorage.setItem("rplms_exceptions", JSON.stringify(state.exceptions));
  } catch (e) {
    console.warn("LocalStorage save failed.", e);
  }
}

// ==========================================================================
// 3. DOM ELEMENTS
// ==========================================================================
const DOM = {
  get exceptionsTableBody() { return document.getElementById("exceptions-table-body"); },
  get pageExceptionsList() { return document.getElementById("page-exceptions-list"); },
  get pageExceptionDetails() { return document.getElementById("page-exception-details"); },
  get pageVerifyAsset() { return document.getElementById("page-verify-asset"); },
  get pageDecisionDetails() { return document.getElementById("page-decision-details"); },
  
  get searchInput() { return document.getElementById("filter-search"); },
  get typeSelect() { return document.getElementById("filter-type"); },
  get categorySelect() { return document.getElementById("filter-category"); },
  get facultySelect() { return document.getElementById("filter-faculty"); },
  get dateInput() { return document.getElementById("filter-date"); },
  get btnClearFilters() { return document.getElementById("btn-clear-filters"); },
  
  get kpiOpen() { return document.getElementById("kpi-open-count"); },
  get kpiWaiting() { return document.getElementById("kpi-waiting-count"); },
  get kpiVerify() { return document.getElementById("kpi-verify-count"); },
  get kpiClosed() { return document.getElementById("kpi-closed-count"); }
};

// ==========================================================================
// 4. BUSINESS LOGIC & DATA HELPERS
// ==========================================================================
function getFilteredExceptions() {
  return state.exceptions.filter(item => {
    // Search query
    const q = state.filters.search.toLowerCase();
    const matchesSearch = !q || 
      item.id.toLowerCase().includes(q) ||
      item.asset.toLowerCase().includes(q) ||
      item.team.toLowerCase().includes(q) ||
      item.project.toLowerCase().includes(q);
      
    // Type query
    const matchesType = state.filters.type === "All" || item.type === state.filters.type;
    
    // Category query
    const matchesCategory = state.filters.category === "All" || item.category === state.filters.category;
    
    // Faculty query
    const matchesFaculty = state.filters.faculty === "All" || item.faculty === state.filters.faculty;
    
    // Date query
    const matchesDate = !state.filters.date || item.reportedOn === state.filters.date;
    
    // Tab filter
    let matchesTab = true;
    if (state.activeFilterTab !== "All") {
      matchesTab = item.status.toLowerCase() === state.activeFilterTab.toLowerCase();
    }
    
    return matchesSearch && matchesType && matchesCategory && matchesFaculty && matchesDate && matchesTab;
  });
}

function updateKPIs() {
  const openCount = state.exceptions.filter(i => i.status === "Open").length;
  const waitingCount = state.exceptions.filter(i => i.status === "Waiting Approval").length;
  const verifyCount = state.exceptions.filter(i => i.status === "Found Awaiting Verify").length;
  const closedCount = state.exceptions.filter(i => i.status === "Closed").length;
  
  if (DOM.kpiOpen) DOM.kpiOpen.textContent = openCount;
  if (DOM.kpiWaiting) DOM.kpiWaiting.textContent = waitingCount;
  if (DOM.kpiVerify) DOM.kpiVerify.textContent = verifyCount;
  if (DOM.kpiClosed) DOM.kpiClosed.textContent = closedCount;
}

function showPage(pageId) {
  if (DOM.pageExceptionsList) DOM.pageExceptionsList.classList.add("hidden");
  if (DOM.pageExceptionDetails) DOM.pageExceptionDetails.classList.add("hidden");
  if (DOM.pageVerifyAsset) DOM.pageVerifyAsset.classList.add("hidden");
  if (DOM.pageDecisionDetails) DOM.pageDecisionDetails.classList.add("hidden");
  
  if (pageId === "page-exceptions-list") {
    if (DOM.pageExceptionsList) DOM.pageExceptionsList.classList.remove("hidden");
    renderExceptionsTable();
    updateKPIs();
  } else if (pageId === "page-exception-details") {
    if (DOM.pageExceptionDetails) DOM.pageExceptionDetails.classList.remove("hidden");
    renderExceptionDetails();
  } else if (pageId === "page-verify-asset") {
    if (DOM.pageVerifyAsset) DOM.pageVerifyAsset.classList.remove("hidden");
    renderVerifyAssetPage();
  } else if (pageId === "page-decision-details") {
    if (DOM.pageDecisionDetails) DOM.pageDecisionDetails.classList.remove("hidden");
    renderDecisionDetailsPage();
  }
}

// ==========================================================================
// 5. TOAST NOTIFICATION
// ==========================================================================
function showToast(message, type = "success") {
  const container = document.getElementById("toast-container");
  if (!container) return;
  
  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  
  let icon = "";
  if (type === "success") {
    icon = `<svg style="width:16px;height:16px;margin-right:8px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>`;
  } else {
    icon = `<svg style="width:16px;height:16px;margin-right:8px;" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;
  }
  
  toast.innerHTML = `${icon}<span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => toast.classList.add("show"), 10);
  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// ==========================================================================
// 6. RENDER VIEWS
// ==========================================================================
function renderExceptionsTable() {
  const filtered = getFilteredExceptions();
  if (!DOM.exceptionsTableBody) return;
  DOM.exceptionsTableBody.innerHTML = "";
  
  if (filtered.length === 0) {
    DOM.exceptionsTableBody.innerHTML = `
      <tr>
        <td colspan="9" class="text-center text-muted" style="padding: 30px;">
          No exceptions found matching filters.
        </td>
      </tr>
    `;
    return;
  }
  
  filtered.forEach(item => {
    const tr = document.createElement("tr");
    
    // Status Badge classes
    let statusClass = "badge-status open";
    if (item.status === "Waiting Approval") statusClass = "badge-status pending";
    else if (item.status === "Found Awaiting Verify") statusClass = "badge-status verify";
    else if (item.status === "Closed") statusClass = "badge-status closed";
    
    // Type Badge class
    const typeClass = item.type === "Missing" ? "badge missing" : "badge damaged";
    
    // Action Button mapping
    let actionBtn = "";
    if (item.status === "Found Awaiting Verify") {
      actionBtn = `<button class="btn btn-primary btn-sm btn-action" data-id="${item.id}" data-action="verify">Verify</button>`;
    } else if (item.status === "Waiting Approval") {
      actionBtn = `<button class="btn btn-secondary btn-sm btn-action" data-id="${item.id}" data-action="decision" style="border-color:var(--state-pending);color:var(--state-pending);">Decision</button>`;
    } else {
      actionBtn = `<button class="btn btn-secondary btn-sm btn-action" data-id="${item.id}" data-action="view">View</button>`;
    }
    
    tr.innerHTML = `
      <td><strong>${item.id}</strong></td>
      <td>${item.asset}</td>
      <td><span class="${typeClass}">${item.type}</span></td>
      <td>${item.category}</td>
      <td>${item.team}</td>
      <td>${item.project}</td>
      <td>${item.daysOpen} days</td>
      <td><span class="${statusClass}">${item.status}</span></td>
      <td class="text-center">${actionBtn}</td>
    `;
    
    // Wire action button
    const btn = tr.querySelector(".btn-action");
    if (btn) {
      btn.addEventListener("click", () => {
        state.activeExceptionId = item.id;
        const action = btn.getAttribute("data-action");
        if (action === "verify") {
          showPage("page-verify-asset");
        } else if (action === "decision") {
          showPage("page-decision-details");
        } else {
          showPage("page-exception-details");
        }
      });
    }
    
    DOM.exceptionsTableBody.appendChild(tr);
  });
}

function renderExceptionDetails() {
  const item = state.exceptions.find(i => i.id === state.activeExceptionId);
  if (!item) return;
  
  // Render main detail labels
  const dId = document.getElementById("detail-exception-id");
  const dAsset = document.getElementById("detail-asset");
  const dType = document.getElementById("detail-type");
  const dCategory = document.getElementById("detail-category");
  const dTeam = document.getElementById("detail-team");
  const dProject = document.getElementById("detail-project");
  const dFaculty = document.getElementById("detail-faculty");
  const dReturnId = document.getElementById("detail-returnid");
  const dReportedBy = document.getElementById("detail-reportedby");
  const dCreatedOn = document.getElementById("detail-createdon");
  const dDays = document.getElementById("detail-days");
  const dRemarks = document.getElementById("detail-remarks");
  
  if (dId) dId.textContent = item.id;
  if (dAsset) dAsset.textContent = item.asset;
  if (dType) {
    dType.textContent = item.type;
    dType.className = item.type === "Missing" ? "badge missing" : "badge damaged";
  }
  if (dCategory) dCategory.textContent = item.category;
  if (dTeam) dTeam.textContent = item.team;
  if (dProject) dProject.textContent = item.project;
  if (dFaculty) dFaculty.textContent = item.faculty;
  if (dReturnId) dReturnId.textContent = item.returnId;
  if (dReportedBy) dReportedBy.textContent = item.reportedBy;
  if (dCreatedOn) dCreatedOn.textContent = item.reportedOn;
  if (dDays) dDays.textContent = `${item.daysOpen} Days`;
  if (dRemarks) dRemarks.textContent = item.remarks;
  
  // Render status header card
  const dStatusCard = document.getElementById("detail-status-card");
  if (dStatusCard) {
    dStatusCard.innerHTML = `
      <div style="font-size: 11px; font-weight:700; color:var(--text-secondary); text-transform:uppercase;">Current Status</div>
      <div style="font-size: 20px; font-weight:800; color:var(--text-primary); margin-top:4px;">${item.status}</div>
    `;
  }
  
  // Render Timeline/History
  const tList = document.getElementById("detail-timeline-list");
  if (tList) {
    tList.innerHTML = "";
    item.timeline.forEach(step => {
      const stepItem = document.createElement("div");
      stepItem.className = `timeline-item ${step.time ? 'completed' : 'active'}`;
      stepItem.innerHTML = `
        <div class="timeline-dot"></div>
        <div class="timeline-content">
          <span class="timeline-time">${step.time || 'Pending Decision'}</span>
          <span class="timeline-title">${step.title}</span>
          <span class="timeline-desc">${step.desc}</span>
        </div>
      `;
      tList.appendChild(stepItem);
    });
  }
}

function renderVerifyAssetPage() {
  const item = state.exceptions.find(i => i.id === state.activeExceptionId);
  if (!item) return;
  
  const vId = document.getElementById("verify-exception-id");
  const vAsset = document.getElementById("verify-asset-name");
  const vTeam = document.getElementById("verify-team-name");
  const vProject = document.getElementById("verify-project-name");
  const vReported = document.getElementById("verify-reported-on");
  const vReturned = document.getElementById("verify-returned-on");
  const vIncharge = document.getElementById("verify-incharge-name");
  
  if (vId) vId.textContent = item.id;
  if (vAsset) vAsset.textContent = item.asset;
  if (vTeam) vTeam.textContent = item.team;
  if (vProject) vProject.textContent = item.project;
  if (vReported) vReported.textContent = item.reportedOn;
  if (vReturned) vReturned.textContent = item.returnedOn;
  if (vIncharge) vIncharge.textContent = item.reportedBy;
}

function renderDecisionDetailsPage() {
  const item = state.exceptions.find(i => i.id === state.activeExceptionId);
  if (!item) return;
  
  // Render Exception summary in Decision View
  const sId = document.getElementById("decision-exception-id");
  const sAsset = document.getElementById("decision-asset");
  const sTeam = document.getElementById("decision-team");
  const sProject = document.getElementById("decision-project");
  const sReported = document.getElementById("decision-reported");
  const sDays = document.getElementById("decision-days");
  
  if (sId) sId.textContent = item.id;
  if (sAsset) sAsset.textContent = `${item.asset} (${item.type})`;
  if (sTeam) sTeam.textContent = item.team;
  if (sProject) sProject.textContent = item.project;
  if (sReported) sReported.textContent = item.reportedOn;
  if (sDays) sDays.textContent = `${item.daysOpen} Days`;
  
  // Render Faculty Decision Block
  const decTitle = document.getElementById("decision-result-title");
  const decBy = document.getElementById("decision-faculty-by");
  const decDate = document.getElementById("decision-faculty-date");
  const decRemarks = document.getElementById("decision-faculty-remarks");
  
  if (item.decision) {
    if (decTitle) decTitle.textContent = item.decision.type;
    if (decBy) decBy.textContent = item.decision.decisionBy;
    if (decDate) decDate.textContent = item.decision.date;
    if (decRemarks) decRemarks.textContent = item.decision.remarks;
    
    // Status box coloring
    const decBox = document.getElementById("decision-status-badge");
    if (decBox) {
      decBox.textContent = item.decision.type;
      decBox.className = "badge-status " + (item.decision.type === "Accepted" ? "closed" : "open");
    }
  } else {
    if (decTitle) decTitle.textContent = "Under Review";
    if (decBy) decBy.textContent = item.faculty;
    if (decDate) decDate.textContent = "Decision pending";
    if (decRemarks) decRemarks.textContent = "Senior Faculty review in progress. No decisions have been logged yet.";
  }
  
  // Render Timeline
  const tList = document.getElementById("decision-timeline-list");
  if (tList) {
    tList.innerHTML = "";
    item.timeline.forEach(step => {
      const stepItem = document.createElement("div");
      stepItem.className = `timeline-item ${step.time ? 'completed' : 'active'}`;
      stepItem.innerHTML = `
        <div class="timeline-dot"></div>
        <div class="timeline-content">
          <span class="timeline-time">${step.time || 'Pending Decision'}</span>
          <span class="timeline-title">${step.title}</span>
          <span class="timeline-desc">${step.desc}</span>
        </div>
      `;
      tList.appendChild(stepItem);
    });
  }
}

// ==========================================================================
// 7. EVENT BINDINGS
// ==========================================================================
function bindEvents() {
  // Tab Filter Tab switches
  const filterTabs = document.querySelectorAll(".filter-tab");
  filterTabs.forEach(tab => {
    tab.addEventListener("click", () => {
      filterTabs.forEach(el => el.classList.remove("active"));
      tab.classList.add("active");
      state.activeFilterTab = tab.getAttribute("data-status");
      
      // Sync active KPI card highlights
      const kpis = document.querySelectorAll(".kpi-card");
      kpis.forEach(k => k.classList.remove("active"));
      
      if (state.activeFilterTab === "Open") document.getElementById("kpi-open-card").classList.add("active");
      else if (state.activeFilterTab === "Waiting Approval") document.getElementById("kpi-waiting-card").classList.add("active");
      else if (state.activeFilterTab === "Found Awaiting Verify") document.getElementById("kpi-verify-card").classList.add("active");
      else if (state.activeFilterTab === "Closed") document.getElementById("kpi-closed-card").classList.add("active");
      
      renderExceptionsTable();
    });
  });

  // KPI card click bindings (filters table dynamically)
  const wireKPICard = (cardId, tabStatus) => {
    const card = document.getElementById(cardId);
    if (card) {
      card.addEventListener("click", () => {
        const correspondingTab = document.querySelector(`.filter-tab[data-status="${tabStatus}"]`);
        if (correspondingTab) correspondingTab.click();
      });
    }
  };
  wireKPICard("kpi-open-card", "Open");
  wireKPICard("kpi-waiting-card", "Waiting Approval");
  wireKPICard("kpi-verify-card", "Found Awaiting Verify");
  wireKPICard("kpi-closed-card", "Closed");

  // Filters inputs
  const applyFilters = () => {
    state.filters.search = DOM.searchInput ? DOM.searchInput.value : "";
    state.filters.type = DOM.typeSelect ? DOM.typeSelect.value : "All";
    state.filters.category = DOM.categorySelect ? DOM.categorySelect.value : "All";
    state.filters.faculty = DOM.facultySelect ? DOM.facultySelect.value : "All";
    state.filters.date = DOM.dateInput ? DOM.dateInput.value : "";
    
    renderExceptionsTable();
  };

  if (DOM.searchInput) DOM.searchInput.addEventListener("input", applyFilters);
  if (DOM.typeSelect) DOM.typeSelect.addEventListener("change", applyFilters);
  if (DOM.categorySelect) DOM.categorySelect.addEventListener("change", applyFilters);
  if (DOM.facultySelect) DOM.facultySelect.addEventListener("change", applyFilters);
  if (DOM.dateInput) DOM.dateInput.addEventListener("change", applyFilters);

  if (DOM.btnClearFilters) {
    DOM.btnClearFilters.addEventListener("click", () => {
      if (DOM.searchInput) DOM.searchInput.value = "";
      if (DOM.typeSelect) DOM.typeSelect.value = "All";
      if (DOM.categorySelect) DOM.categorySelect.value = "All";
      if (DOM.facultySelect) DOM.facultySelect.value = "All";
      if (DOM.dateInput) DOM.dateInput.value = "";
      
      state.filters = { search: "", type: "All", category: "All", faculty: "All", date: "" };
      renderExceptionsTable();
      showToast("Filters cleared.");
    });
  }

  // Back buttons
  document.querySelectorAll(".btn-back-list").forEach(btn => {
    btn.addEventListener("click", () => showPage("page-exceptions-list"));
  });

  // Verify Form Submit Handler
  const verifyForm = document.getElementById("verify-asset-form");
  if (verifyForm) {
    verifyForm.addEventListener("submit", (e) => {
      e.preventDefault();
      
      const item = state.exceptions.find(i => i.id === state.activeExceptionId);
      if (!item) return;
      
      const condition = document.getElementById("verify-condition").value;
      const remarks = document.getElementById("verify-remarks").value.trim();
      
      if (!remarks) {
        showToast("Please enter verification remarks.", "error");
        return;
      }
      
      // Update inventory list dynamically in localStorage
      try {
        const storedInventory = localStorage.getItem("rplms_inventory");
        if (storedInventory) {
          const invList = JSON.parse(storedInventory);
          const invItem = invList.find(i => i.id === item.assetId);
          if (invItem) {
            if (condition === "Good") {
              invItem.available++;
              invItem.status = invItem.available >= invItem.minLevel ? "In Stock" : "Low Stock";
            }
            localStorage.setItem("rplms_inventory", JSON.stringify(invList));
          }
        }
      } catch (err) {
        console.warn("Failed to update inventory storage:", err);
      }
      
      // Update Exception Status to Closed
      item.status = "Closed";
      
      // Add timeline entries
      const now = new Date();
      const formatTime = now.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' }) + " " + 
                         now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      item.timeline.push(
        { time: formatTime, title: "Asset found and verified", desc: `Condition: ${condition}. Remarks: "${remarks}"`, type: "completed" },
        { time: formatTime, title: "Case closed", desc: "Returned asset successfully verified and re-entered to inventory database.", type: "closed" }
      );
      
      // Save Faculty decision mock data
      item.decision = {
        type: "Accepted",
        decisionBy: "Lab In-Charge (Self-Verified)",
        date: formatTime,
        remarks: `Condition: ${condition}. Remarks: "${remarks}"`,
        attachment: ""
      };
      
      saveDatabase();
      showToast(`Asset verified successfully! Exception ${item.id} is now closed.`);
      showPage("page-exceptions-list");
    });
  }
}

// ==========================================================================
// 8. APP INITIALIZATION
// ==========================================================================
function initialize() {
  loadDatabase();
  updateKPIs();
  bindEvents();
  showPage("page-exceptions-list");
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initialize);
} else {
  initialize();
}




/* Auto-initialize layout on page load */
document.addEventListener('DOMContentLoaded', () => {
    renderBaseLayout('asset-exceptions');
});

(function() {
    // date
    const dateEl = document.getElementById('todayDate');
    if (dateEl) {
        dateEl.textContent = new Date().toLocaleDateString('en-US', {
            day: '2-digit',
            month: 'long',
            year: 'numeric',
            weekday: 'long'
        });
    }

    // sidebar toggle (mobile)
    const hamburger = document.getElementById('hamburger');
    const sidebar = document.getElementById('sidebar');
    if (hamburger && sidebar) {
        hamburger.addEventListener('click', () => sidebar.classList.toggle('open'));
    }

    // Profile modal
    const profileBtn = document.getElementById('profileBtn');
    const modal = document.getElementById('profileModal');
    const closeProfile = document.getElementById('closeProfile');

    function openModal() {
        if (modal) modal.classList.add('active');
    }

    function closeModal() {
        if (modal) modal.classList.remove('active');
    }

    if (profileBtn) profileBtn.addEventListener('click', openModal);
    if (closeProfile) closeProfile.addEventListener('click', closeModal);
    if (modal) {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) closeModal();
        });
    }

    // Pending actions - view details
    const viewLinks = document.querySelectorAll('.view-link');
    const pendingItems = document.querySelectorAll('.action-card');

    function showPendingDetail(type) {
        let title = '';
        let details = [];

        if (type === 'requests') {
            title = 'Material Requests';
            details = [
                'Tools: Drill set (3)',
                'Tools: Angle grinder (2)',
                'Components: Resistor pack (10)',
                'Components: PCB board (4)'
            ];
        } else if (type === 'returns') {
            title = 'Material Returns';
            details = [
                'Tools: Wrench set (2)',
                'Components: Capacitors (6)',
                'Tools: Screwdriver kit (1)'
            ];
        } else if (type === 'equipment') {
            title = 'Equipment Booking Requests';
            details = [
                '3D Printer (Ultimaker) - 2 requests',
                'Laser Cutter (Epilog) - 2 requests',
                'CNC Router - 1 request'
            ];
        } else {
            return;
        }

        alert(`${title}\n\n${details.join('\n')}`);
    }

    viewLinks.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            const target = this.getAttribute('data-target');
            showPendingDetail(target);
        });
    });

    pendingItems.forEach(item => {
        item.addEventListener('click', function() {
            const action = this.getAttribute('data-action');
            if (action) showPendingDetail(action);
        });
    });
})();

/**
 * Prototrack Dashboard - Interactive Client-Side Engine
 * Handles State, Searching, Filtering, Multi-Selection, 
 * Dynamic KPI Updating, Page Switches, and CSV Exporting.
 * Restored sidebar and navbar element bindings, and removed help card toggles.
 */

// ==========================================================================
// 1. INITIAL MOCK DATASET
// ==========================================================================
const initialLowStockItems = [
  { id: "CMP-001", name: "Arduino Uno R3", category: "Component", specification: "Original", availableQty: 2, minQty: 10, unit: "Nos" },
  { id: "CMP-003", name: "Servo Motor SG90", category: "Component", specification: "Tower Pro", availableQty: 1, minQty: 10, unit: "Nos" },
  { id: "CMP-007", name: "Breadboard 830 Points", category: "Component", specification: "Solderless", availableQty: 3, minQty: 10, unit: "Nos" },
  { id: "TOL-015", name: "Wire Cutter", category: "Tool", specification: "6 inch", availableQty: 1, minQty: 5, unit: "Nos" },
  { id: "TOL-022", name: "Screwdriver Set", category: "Tool", specification: "Phillips & Flat", availableQty: 2, minQty: 5, unit: "Set" },
  { id: "TOL-030", name: "Heat Gun", category: "Tool", specification: "2000W", availableQty: 0, minQty: 2, unit: "Nos" },
  { id: "CMP-002", name: "Raspberry Pi 4", category: "Component", specification: "4GB RAM", availableQty: 1, minQty: 5, unit: "Nos" },
  { id: "CMP-004", name: "Ultrasonic Sensor", category: "Component", specification: "HC-SR04", availableQty: 3, minQty: 15, unit: "Nos" },
  { id: "TOL-016", name: "Soldering Iron", category: "Tool", specification: "60W Adjustable", availableQty: 1, minQty: 4, unit: "Nos" },
  { id: "TOL-025", name: "Digital Multimeter", category: "Tool", specification: "Auto-ranging", availableQty: 2, minQty: 6, unit: "Nos" },
  { id: "CMP-009", name: "Lithium Ion Battery", category: "Component", specification: "3.7V 2200mAh", availableQty: 4, minQty: 20, unit: "Nos" },
  { id: "TOL-008", name: "Mini Rotary Tool", category: "Tool", specification: "12V Cordless", availableQty: 0, minQty: 3, unit: "Set" }
];

// ==========================================================================
// 2. STATE OBJECT
// ==========================================================================
const state = {
  items: JSON.parse(JSON.stringify(initialLowStockItems)), // Deep clone data
  selectedIds: new Set(["CMP-001", "CMP-003", "CMP-007", "TOL-015", "TOL-022", "TOL-030"]), // Default selected items
  requiredQuantities: {}, // Map of id -> quantity
  filters: {
    search: "",
    category: "All",
    sortBy: "lowest-qty"
  },
  currentPage: "page-low-stock-list",
  lastActivePage: "page-low-stock-list" // Tracks which page to go back to from dummy views
};

// ==========================================================================
// 3. DOM ELEMENTS (LAZY GETTERS TO PREVENT NULL QUERY CRASHES)
// ==========================================================================
const DOM = {
  // Sidebar & Navigation
  get sidebarMenuItems() { return document.querySelectorAll(".menu-item"); },
  get dropdownChevron() { return document.querySelector(".dropdown-chevron"); },
  get returnsDropdownParent() { return document.querySelector(".menu-item-dropdown"); },
  get logoutBtn() { return document.querySelector(".logout-btn"); },
  get pageTitle() { return document.getElementById("navbar-page-title"); },
  
  // Page Views
  get pageLowStockList() { return document.getElementById("page-low-stock-list"); },
  get pageReviewQuantities() { return document.getElementById("page-review-quantities"); },
  get pageDummy() { return document.getElementById("page-dummy"); },
  get dummyTitle() { return document.getElementById("dummy-title"); },
  get dummyDesc() { return document.getElementById("dummy-desc"); },
  get btnBackToActive() { return document.getElementById("btn-back-to-active"); },
  
  // KPI Metrics (Low Stock)
  get kpiTotalItems() { return document.getElementById("kpi-total-items"); },
  get kpiComponentsCount() { return document.getElementById("kpi-components-count"); },
  get kpiToolsCount() { return document.getElementById("kpi-tools-count"); },
  get kpiUpdateTime() { return document.getElementById("kpi-update-time"); },
  get timestampVal() { return document.getElementById("timestamp-val"); },
  get refreshDataBtn() { return document.getElementById("refresh-data-btn"); },
  
  // Filters Panel (Low Stock)
  get searchInput() { return document.getElementById("search-input"); },
  get categorySelect() { return document.getElementById("category-select"); },
  get sortSelect() { return document.getElementById("sort-select"); },
  get btnClearFilters() { return document.getElementById("btn-clear-filters"); },
  
  // Tables (Low Stock)
  get tableLowStockBody() { return document.getElementById("low-stock-table-body"); },
  get tableReviewBody() { return document.getElementById("review-table-body"); },
  get selectAllCheckbox() { return document.getElementById("select-all-checkbox"); },
  get tableEmptyState() { return document.getElementById("table-empty-state"); },
  
  // Footer Selection Bar Page 1 (Low Stock)
  get selectedCountBadge() { return document.getElementById("selected-count-badge"); },
  get visibleCountBadge() { return document.getElementById("visible-count-badge"); },
  get btnClearSelection() { return document.getElementById("btn-clear-selection"); },
  get btnNextStep() { return document.getElementById("btn-next-step"); },
  
  // Header / Footer Buttons Page 2 (Low Stock)
  get reviewSelectedCountBadge() { return document.getElementById("review-selected-count-badge"); },
  get btnBackHeader() { return document.getElementById("btn-back-header"); },
  get btnBackFooter() { return document.getElementById("btn-back-footer"); },
  get btnClearAllReview() { return document.getElementById("btn-clear-all-review"); },
  get btnDownloadReport() { return document.getElementById("btn-download-report"); },
  
  // Toast notifications
  get toastContainer() { return document.getElementById("toast-container"); }
};

// ==========================================================================
// 4. BUSINESS LOGIC & STATE MUTATORS
// ==========================================================================

/**
 * Initialize default required quantities for items based on available and minimum stock
 */
function initRequiredQuantities() {
  state.items.forEach(item => {
    if (!state.requiredQuantities[item.id]) {
      if (item.id === "CMP-001") state.requiredQuantities[item.id] = 20;
      else if (item.id === "CMP-003") state.requiredQuantities[item.id] = 15;
      else if (item.id === "CMP-007") state.requiredQuantities[item.id] = 10;
      else if (item.id === "TOL-015") state.requiredQuantities[item.id] = 8;
      else if (item.id === "TOL-022") state.requiredQuantities[item.id] = 8;
      else if (item.id === "TOL-030") state.requiredQuantities[item.id] = 3;
      else {
        const diff = item.minQty - item.availableQty;
        state.requiredQuantities[item.id] = Math.max(item.minQty, diff * 2);
      }
    }
  });
}

/**
 * Retrieve items matching the current filters and sort parameters
 */
function getFilteredItems() {
  let filtered = state.items.filter(item => {
    // 1. Search Query Match
    const matchesSearch = item.name.toLowerCase().includes(state.filters.search.toLowerCase()) || 
                          item.id.toLowerCase().includes(state.filters.search.toLowerCase());
    
    // 2. Category Match
    const matchesCategory = state.filters.category === "All" || item.category === state.filters.category;
    
    return matchesSearch && matchesCategory;
  });

  // 3. Sorting
  filtered.sort((a, b) => {
    switch (state.filters.sortBy) {
      case "lowest-qty":
        return a.availableQty - b.availableQty;
      case "highest-qty":
        return b.availableQty - a.availableQty;
      case "asset-id":
        return a.id.localeCompare(b.id);
      case "asset-name":
        return a.name.localeCompare(b.name);
      default:
        return 0;
    }
  });

  return filtered;
}

/**
 * Update the top metrics blocks (KPIs) dynamically
 */
function updateKPICards() {
  const total = state.items.length;
  const components = state.items.filter(i => i.category === "Component").length;
  const tools = state.items.filter(i => i.category === "Tool").length;
  
  DOM.kpiTotalItems.textContent = total;
  DOM.kpiComponentsCount.textContent = components;
  DOM.kpiToolsCount.textContent = tools;
}

/**
 * Toggle Page switches and Sidebar highlights
 */
function showPage(pageId) {
  state.currentPage = pageId;
  
  // Hide all views
  DOM.pageLowStockList.classList.add("hidden");
  DOM.pageReviewQuantities.classList.add("hidden");
  DOM.pageDummy.classList.add("hidden");
  
  // Reset active state for sidebar links
  DOM.sidebarMenuItems.forEach(item => item.classList.remove("active"));
  
  if (pageId === "page-low-stock-list") {
    DOM.pageLowStockList.classList.remove("hidden");
    DOM.pageTitle.textContent = "Low Stock Alerts";
    
    // Highlight "Low Stock Alerts" in sidebar
    const lowStockMenu = document.querySelector('[data-target="low-stock"]');
    if (lowStockMenu) lowStockMenu.classList.add("active");
    
    state.lastActivePage = pageId;
    renderLowStockTable();
    updateSelectionState();
  } 
  else if (pageId === "page-review-quantities") {
    DOM.pageReviewQuantities.classList.remove("hidden");
    DOM.pageTitle.textContent = "Low Stock Alerts";
    
    // Highlight "Low Stock Alerts" in sidebar
    const lowStockMenu = document.querySelector('[data-target="low-stock"]');
    if (lowStockMenu) lowStockMenu.classList.add("active");
    
    state.lastActivePage = pageId;
    renderReviewTable();
  } 
  else if (pageId.startsWith("dummy-")) {
    const sectionName = pageId.replace("dummy-", "");
    DOM.pageDummy.classList.remove("hidden");
    
    // Customize dummy text
    const titleFormatted = sectionName.split("-").map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(" ");
    DOM.pageTitle.textContent = titleFormatted;
    DOM.dummyTitle.textContent = `${titleFormatted} Module`;
    DOM.dummyDesc.textContent = `The "${titleFormatted}" lab module is currently under layout design for the Prototrack Lab Portal. Switch to the active "Low Stock Alerts" screen to interact with the mock workspace.`;
    
    // Highlight corresponding sidebar link
    const targetMenu = document.querySelector(`[data-target="${sectionName}"]`);
    if (targetMenu) targetMenu.classList.add("active");
  }
}

/**
 * Update selection elements (badge values, button disabled toggles)
 */
function updateSelectionState() {
  const selectedCount = state.selectedIds.size;
  DOM.selectedCountBadge.textContent = selectedCount;
  DOM.reviewSelectedCountBadge.textContent = selectedCount;
  
  const filtered = getFilteredItems();
  const visibleSelected = filtered.filter(item => state.selectedIds.has(item.id)).length;
  
  if (filtered.length > 0 && visibleSelected === filtered.length) {
    DOM.selectAllCheckbox.checked = true;
    DOM.selectAllCheckbox.indeterminate = false;
  } else if (visibleSelected > 0) {
    DOM.selectAllCheckbox.checked = false;
    DOM.selectAllCheckbox.indeterminate = true;
  } else {
    DOM.selectAllCheckbox.checked = false;
    DOM.selectAllCheckbox.indeterminate = false;
  }

  DOM.btnClearSelection.disabled = selectedCount === 0;
  DOM.btnNextStep.disabled = selectedCount === 0;
}

// ==========================================================================
// 5. TOAST NOTIFICATION UTILITY
// ==========================================================================
function showToast(message, type = "success") {
  const toast = document.createElement("div");
  toast.className = `toast toast-${type}`;
  
  let iconSVG = "";
  if (type === "success") {
    iconSVG = `<svg class="toast-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>`;
  } else {
    iconSVG = `<svg class="toast-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;
  }

  toast.innerHTML = `
    ${iconSVG}
    <span>${message}</span>
  `;
  
  DOM.toastContainer.appendChild(toast);
  
  setTimeout(() => toast.classList.add("show"), 10);
  
  setTimeout(() => {
    toast.classList.remove("show");
    setTimeout(() => {
      toast.remove();
    }, 300);
  }, 3500);
}

// ==========================================================================
// 6. RENDER DATA TABLES
// ==========================================================================

/**
 * Populate main table (Page 1)
 */
function renderLowStockTable() {
  const filtered = getFilteredItems();
  DOM.tableLowStockBody.innerHTML = "";
  DOM.visibleCountBadge.textContent = `${filtered.length} items visible`;

  if (filtered.length === 0) {
    DOM.tableEmptyState.classList.remove("hidden");
    return;
  }
  DOM.tableEmptyState.classList.add("hidden");

  filtered.forEach(item => {
    const isSelected = state.selectedIds.has(item.id);
    const tr = document.createElement("tr");
    if (isSelected) tr.classList.add("row-selected");

    tr.innerHTML = `
      <td class="col-checkbox text-center">
        <label class="custom-checkbox">
          <input type="checkbox" data-id="${item.id}" ${isSelected ? "checked" : ""}>
          <span class="checkmark"></span>
        </label>
      </td>
      <td class="font-semibold text-secondary">${item.id}</td>
      <td class="font-medium">${item.name}</td>
      <td>${item.category}</td>
      <td>${item.specification}</td>
      <td class="text-right"><span class="qty-badge-red">${item.availableQty}</span></td>
      <td class="text-right font-medium">${item.minQty}</td>
      <td class="text-right text-muted">-</td>
      <td class="text-secondary">${item.unit}</td>
    `;

    // Row Click Trigger
    tr.addEventListener("click", (e) => {
      if (e.target.closest("label")) return;
      const checkbox = tr.querySelector('input[type="checkbox"]');
      checkbox.checked = !checkbox.checked;
      handleRowSelectChange(item.id, checkbox.checked, tr);
    });

    // Checkbox State Change Trigger
    const checkbox = tr.querySelector('input[type="checkbox"]');
    checkbox.addEventListener("change", (e) => {
      handleRowSelectChange(item.id, e.target.checked, tr);
    });

    DOM.tableLowStockBody.appendChild(tr);
  });
}

/**
 * Selection Mutator
 */
function handleRowSelectChange(id, isChecked, trElement) {
  if (isChecked) {
    state.selectedIds.add(id);
    trElement.classList.add("row-selected");
  } else {
    state.selectedIds.delete(id);
    trElement.classList.remove("row-selected");
  }
  updateSelectionState();
}

/**
 * Populate review table (Page 2)
 */
function renderReviewTable() {
  DOM.tableReviewBody.innerHTML = "";
  const selectedItems = state.items.filter(item => state.selectedIds.has(item.id));
  
  if (selectedItems.length === 0) {
    showToast("No items selected. Returning to list.", "error");
    showPage("page-low-stock-list");
    return;
  }

  selectedItems.forEach(item => {
    const tr = document.createElement("tr");
    const reqQty = state.requiredQuantities[item.id] || item.minQty;

    tr.innerHTML = `
      <td class="col-remove text-center">
        <button class="btn-row-action btn-row-action-danger" data-id="${item.id}" aria-label="Remove item">
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>
        </button>
      </td>
      <td class="font-semibold text-secondary">${item.id}</td>
      <td class="font-medium">${item.name}</td>
      <td>${item.category}</td>
      <td>${item.specification}</td>
      <td class="text-right"><span class="qty-badge-red">${item.availableQty}</span></td>
      <td class="text-right font-medium">${item.minQty}</td>
      <td class="text-center col-required-qty">
        <div class="qty-input-wrapper">
          <button class="qty-spin-btn btn-minus" data-id="${item.id}">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="5" y1="12" x2="19" y2="12"/></svg>
          </button>
          <input type="number" value="${reqQty}" min="1" max="999" data-id="${item.id}">
          <button class="qty-spin-btn btn-plus" data-id="${item.id}">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
          </button>
        </div>
      </td>
      <td class="text-secondary">${item.unit}</td>
    `;

    // 1. Remove Item listener
    tr.querySelector(".btn-row-action-danger").addEventListener("click", () => {
      state.selectedIds.delete(item.id);
      showToast(`Removed "${item.name}" from report selection.`);
      
      renderReviewTable();
      updateSelectionState();
    });

    // 2. Quantity input value sync
    const input = tr.querySelector('input[type="number"]');
    
    input.addEventListener("change", (e) => {
      let value = parseInt(e.target.value);
      if (isNaN(value) || value < 1) value = 1;
      if (value > 999) value = 999;
      
      e.target.value = value;
      state.requiredQuantities[item.id] = value;
    });

    // Plus & Minus spinner controls
    tr.querySelector(".btn-minus").addEventListener("click", () => {
      let currentVal = parseInt(input.value);
      if (currentVal > 1) {
        input.value = currentVal - 1;
        state.requiredQuantities[item.id] = currentVal - 1;
      }
    });

    tr.querySelector(".btn-plus").addEventListener("click", () => {
      let currentVal = parseInt(input.value);
      if (currentVal < 999) {
        input.value = currentVal + 1;
        state.requiredQuantities[item.id] = currentVal + 1;
      }
    });

    DOM.tableReviewBody.appendChild(tr);
  });

  DOM.reviewSelectedCountBadge.textContent = selectedItems.length;
}

// ==========================================================================
// 7. CSV EXPORTER (REPORTS COMPILER)
// ==========================================================================
function downloadReport() {
  const selectedItems = state.items.filter(item => state.selectedIds.has(item.id));
  
  if (selectedItems.length === 0) {
    showToast("No items selected to compile report.", "error");
    return;
  }

  let csvContent = "Asset ID,Asset Name,Category,Specification / Model,Available Quantity,Minimum Quantity,Required Quantity,Unit\n";
  
  selectedItems.forEach(item => {
    const required = state.requiredQuantities[item.id] || item.minQty;
    const nameEscaped = item.name.replace(/"/g, '""');
    const specEscaped = item.specification.replace(/"/g, '""');
    
    csvContent += `"${item.id}","${nameEscaped}","${item.category}","${specEscaped}",${item.availableQty},${item.minQty},${required},"${item.unit}"\n`;
  });

  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", `Prototrack_Low_Stock_Report_${new Date().toISOString().slice(0,10)}.csv`);
  link.style.visibility = 'hidden';
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  showToast(`Successfully downloaded Low Stock Report (${selectedItems.length} items included)!`);
}

function bindEvents() {
  
  // 1. Sidebar switches
  DOM.sidebarMenuItems.forEach(item => {
    item.addEventListener("click", (e) => {
      const target = item.getAttribute("data-target");
      
      if (target === "returns-status") {
        e.preventDefault();
        DOM.returnsDropdownParent.classList.toggle("expanded");
      } else if (target === "low-stock") {
        e.preventDefault();
        showPage("page-low-stock-list");
      } else {
        e.preventDefault();
        showPage(`dummy-${target}`);
      }
    });
  });

  // Back to Active portal button from dummy panels
  DOM.btnBackToActive.addEventListener("click", () => {
    showPage("page-low-stock-list");
  });

  // Logout banner simulated trigger
  DOM.logoutBtn.addEventListener("click", (e) => {
    e.preventDefault();
    showToast("Logout triggered. In a live system, this terminates the user session.", "error");
  });

  // 2. Select All Checkbox logic
  DOM.selectAllCheckbox.addEventListener("change", (e) => {
    const filtered = getFilteredItems();
    filtered.forEach(item => {
      if (e.target.checked) {
        state.selectedIds.add(item.id);
      } else {
        state.selectedIds.delete(item.id);
      }
    });
    
    renderLowStockTable();
    updateSelectionState();
  });

  // 3. KPI / Header Refresh Action
  DOM.refreshDataBtn.addEventListener("click", () => {
    DOM.refreshDataBtn.classList.add("spinning");
    showToast("Fetching live storage inventory data...");
    
    setTimeout(() => {
      const now = new Date();
      const options = { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' };
      const newTimestamp = now.toLocaleDateString('en-GB', options).replace(/,/g, ' -') + " (Updated)";
      
      DOM.timestampVal.textContent = newTimestamp;
      DOM.kpiUpdateTime.textContent = newTimestamp;
      
      state.items.forEach(item => {
        if (item.availableQty < item.minQty && Math.random() > 0.7) {
          item.availableQty = Math.max(0, item.availableQty + (Math.random() > 0.5 ? 1 : -1));
        }
      });

      DOM.refreshDataBtn.classList.remove("spinning");
      initRequiredQuantities();
      renderLowStockTable();
      updateKPICards();
      updateSelectionState();
      
      showToast("Inventory database synced successfully.");
    }, 1200);
  });

  // 4. Filters & Searches (Real-time Auto-filtering)
  const applyFilters = () => {
    state.filters.search = DOM.searchInput.value;
    state.filters.category = DOM.categorySelect.value;
    state.filters.sortBy = DOM.sortSelect.value;
    
    renderLowStockTable();
    updateSelectionState();
  };

  DOM.searchInput.addEventListener("input", applyFilters);
  DOM.categorySelect.addEventListener("change", applyFilters);
  DOM.sortSelect.addEventListener("change", applyFilters);

  DOM.btnClearFilters.addEventListener("click", () => {
    DOM.searchInput.value = "";
    DOM.categorySelect.value = "All";
    DOM.sortSelect.value = "lowest-qty";
    
    state.filters.search = "";
    state.filters.category = "All";
    state.filters.sortBy = "lowest-qty";
    
    renderLowStockTable();
    updateSelectionState();
    showToast("Filters cleared.");
  });

  // 5. Page 1 Footer Buttons
  DOM.btnClearSelection.addEventListener("click", () => {
    state.selectedIds.clear();
    renderLowStockTable();
    updateSelectionState();
    showToast("Selection cleared.");
  });

  DOM.btnNextStep.addEventListener("click", () => {
    showPage("page-review-quantities");
  });

  // 6. Page 2 Navigation Links & Actions
  DOM.btnBackHeader.addEventListener("click", () => showPage("page-low-stock-list"));
  DOM.btnBackFooter.addEventListener("click", () => showPage("page-low-stock-list"));

  DOM.btnClearAllReview.addEventListener("click", () => {
    state.selectedIds.clear();
    showToast("Cleared report list. Returning to low stock view.");
    showPage("page-low-stock-list");
  });

  DOM.btnDownloadReport.addEventListener("click", () => {
    downloadReport();
  });
}

// ==========================================================================
// 9. APP INITIALIZATION ENTRYPOINT
// ==========================================================================
function initializeApp() {
  initRequiredQuantities();
  updateKPICards();
  bindEvents();
  
  // Set initial page
  showPage("page-low-stock-list");
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initializeApp);
} else {
  initializeApp();
}

/**
 * ==========================================================================
 * RAPID PROTOTYPING LAB DASHBOARD - APPLICATION CONTROLLER
 * ==========================================================================
 */

// --------------------------------------------------------------------------
// 1. MOCK DATABASE (INITIAL STATE)
// --------------------------------------------------------------------------
const INITIAL_TEAMS = [
  {
    id: "T-2026-001",
    name: "Team Alpha",
    project: "Smart Irrigation System",
    leader: "Surendhan",
    faculty: "Dr. Kumar",
    department: "Mechanical",
    stage: "Prototyping",
    members: [
      { name: "Surendhan", initial: "S", color: "#1D4ED8" },
      { name: "Aswin", initial: "A", color: "#10B981" },
      { name: "Bala", initial: "B", color: "#F59E0B" },
      { name: "Divya", initial: "D", color: "#EC4899" },
      { name: "Elango", initial: "E", color: "#8B5CF6" }
    ],
    resources: [
      { id: "R1", name: "Soldering Iron", type: "Tool", qtyIssued: 2, qtyReturned: 1, dueDate: "14 Jul 2026", status: "Overdue" },
      { id: "R2", name: "Screwdriver Set", type: "Tool", qtyIssued: 3, qtyReturned: 3, dueDate: "14 Jul 2026", status: "Returned" },
      { id: "R3", name: "Plier", type: "Tool", qtyIssued: 2, qtyReturned: 1, dueDate: "14 Jul 2026", status: "Overdue" },
      { id: "R4", name: "Multimeter", type: "Tool", qtyIssued: 1, qtyReturned: 0, dueDate: "14 Jul 2026", status: "Overdue" },
      { id: "R5", name: "Cutting Plier", type: "Tool", qtyIssued: 2, qtyReturned: 0, dueDate: "14 Jul 2026", status: "Returned" },
      { id: "R6", name: "Arduino Uno", type: "Component", qtyIssued: 5, qtyReturned: 0, dueDate: "18 Aug 2026", status: "Returned" },
      { id: "R7", name: "IR Sensor", type: "Component", qtyIssued: 10, qtyReturned: 0, dueDate: "18 Aug 2026", status: "Overdue" }
    ],
    bookings: [
      { id: "B1", equipment: "3D Printer", date: "14 Jul 2026", timeSlot: "09:00 AM - 11:00 AM", purpose: "Prototype Print", status: "Upcoming" },
      { id: "B2", equipment: "Laser Cutter", date: "15 Jul 2026", timeSlot: "11:30 AM - 01:30 PM", purpose: "Enclosure Cutting", status: "Confirmed" },
      { id: "B3", equipment: "CNC Machine", date: "16 Jul 2026", timeSlot: "02:00 PM - 04:00 PM", purpose: "Acrylic Parts", status: "Confirmed" },
      { id: "B4", equipment: "3D Printer", date: "16 Jul 2026", timeSlot: "04:30 PM - 06:30 PM", purpose: "Prototype Print", status: "Pending" },
      { id: "B5", equipment: "Laser Cutter", date: "17 Jul 2026", timeSlot: "10:00 AM - 12:00 PM", purpose: "Panel Cutting", status: "Pending" }
    ],
    requests: [
      { id: "Q1", type: "Component Request", item: "Arduino Uno", qty: 5, date: "13 Jul 2026", status: "Pending", approvedBy: "--" },
      { id: "Q2", type: "Tool Request", item: "Soldering Iron", qty: 2, date: "13 Jul 2026", status: "Approved", approvedBy: "Dr. Kumar" },
      { id: "Q3", type: "Equipment Booking", item: "3D Printer", qty: 1, date: "13 Jul 2026", status: "Approved", approvedBy: "Lab In-Charge" },
      { id: "Q4", type: "Component Request", item: "IR Sensor", qty: 10, date: "12 Jul 2026", status: "Pending", approvedBy: "--" },
      { id: "Q5", type: "Tool Request", item: "Plier", qty: 2, date: "11 Jul 2026", status: "Approved", approvedBy: "Dr. Kumar" }
    ],
    issues: [
      { id: "I1", description: "Defective Soldering Iron tip", date: "14 Jul 2026", severity: "Low", status: "Open" },
      { id: "I2", description: "3D Printer filament jam", date: "13 Jul 2026", severity: "High", status: "Open" },
      { id: "I3", description: "CNC Machine motor overheating", date: "12 Jul 2026", severity: "Critical", status: "Closed" }
    ]
  },
  {
    id: "T-2026-002",
    name: "Team Delta",
    project: "Autonomous Drone",
    leader: "Aravind",
    faculty: "Dr. Kumar",
    department: "Aerospace",
    stage: "Testing",
    members: [
      { name: "Aravind", initial: "Ar", color: "#10B981" },
      { name: "Priya", initial: "P", color: "#EC4899" },
      { name: "Gopal", initial: "G", color: "#F59E0B" }
    ],
    resources: [
      { id: "R201", name: "LiPo Battery Charger", type: "Tool", qtyIssued: 1, qtyReturned: 1, dueDate: "14 Jul 2026", status: "Returned" },
      { id: "R202", name: "Brushless Motor", type: "Component", qtyIssued: 4, qtyReturned: 0, dueDate: "10 Aug 2026", status: "Returned" },
      { id: "R203", name: "Carbon Fiber Frame", type: "Component", qtyIssued: 1, qtyReturned: 0, dueDate: "10 Aug 2026", status: "Returned" },
      { id: "R204", name: "Hex Wrench", type: "Tool", qtyIssued: 2, qtyReturned: 0, dueDate: "14 Jul 2026", status: "Overdue" }
    ],
    bookings: [
      { id: "B201", equipment: "CNC Machine", date: "14 Jul 2026", timeSlot: "01:00 PM - 03:00 PM", purpose: "Frame Milling", status: "Confirmed" }
    ],
    requests: [
      { id: "Q201", type: "Component Request", item: "ESC 40A", qty: 4, date: "14 Jul 2026", status: "Pending", approvedBy: "--" },
      { id: "Q202", type: "Tool Request", item: "Heat Shrink Gun", qty: 1, date: "12 Jul 2026", status: "Approved", approvedBy: "Dr. Kumar" }
    ],
    issues: [
      { id: "I201", description: "ESC burned during testing", date: "14 Jul 2026", severity: "High", status: "Open" }
    ]
  },
  {
    id: "T-2026-003",
    name: "Team Phoenix",
    project: "Robotic Arm",
    leader: "Kavin",
    faculty: "Dr. Ramesh",
    department: "Robotics",
    stage: "Design",
    members: [
      { name: "Kavin", initial: "K", color: "#8B5CF6" },
      { name: "Meera", initial: "M", color: "#1D4ED8" },
      { name: "Siddharth", initial: "Si", color: "#10B981" },
      { name: "Nisha", initial: "N", color: "#F59E0B" }
    ],
    resources: [
      { id: "R301", name: "Allen Key Set", type: "Tool", qtyIssued: 1, qtyReturned: 1, dueDate: "14 Jul 2026", status: "Returned" },
      { id: "R302", name: "MG996R Servo Motor", type: "Component", qtyIssued: 6, qtyReturned: 0, dueDate: "15 Aug 2026", status: "Returned" },
      { id: "R303", name: "Screws & Nuts Box", type: "Component", qtyIssued: 1, qtyReturned: 0, dueDate: "15 Aug 2026", status: "Returned" }
    ],
    bookings: [
      { id: "B301", equipment: "3D Printer", date: "15 Jul 2026", timeSlot: "10:00 AM - 12:00 PM", purpose: "Joint Design Iteration", status: "Pending" }
    ],
    requests: [
      { id: "Q301", type: "Component Request", item: "Arduino Mega", qty: 1, date: "14 Jul 2026", status: "Pending", approvedBy: "--" },
      { id: "Q302", type: "Component Request", item: "Servo Shield", qty: 1, date: "14 Jul 2026", status: "Pending", approvedBy: "--" }
    ],
    issues: []
  },
  {
    id: "T-2026-004",
    name: "Team Sigma",
    project: "Solar Tracker",
    leader: "Harish",
    faculty: "Dr. Ramesh",
    department: "Electronics",
    stage: "Prototyping",
    members: [
      { name: "Harish", initial: "H", color: "#EC4899" },
      { name: "Ram", initial: "R", color: "#8B5CF6" },
      { name: "Suresh", initial: "Su", color: "#1D4ED8" }
    ],
    resources: [
      { id: "R401", name: "Soldering Station", type: "Tool", qtyIssued: 1, qtyReturned: 1, dueDate: "14 Jul 2026", status: "Returned" },
      { id: "R402", name: "Solar Panel 10W", type: "Component", qtyIssued: 2, qtyReturned: 0, dueDate: "12 Aug 2026", status: "Returned" },
      { id: "R403", name: "Lead Acid Battery", type: "Component", qtyIssued: 1, qtyReturned: 0, dueDate: "12 Aug 2026", status: "Overdue" },
      { id: "R404", name: "Wire Stripper", type: "Tool", qtyIssued: 1, qtyReturned: 0, dueDate: "14 Jul 2026", status: "Overdue" }
    ],
    bookings: [
      { id: "B401", equipment: "Laser Cutter", date: "14 Jul 2026", timeSlot: "04:00 PM - 06:00 PM", purpose: "Solar Mount Cutting", status: "Confirmed" }
    ],
    requests: [
      { id: "Q401", type: "Component Request", item: "LDR Sensors", qty: 4, date: "13 Jul 2026", status: "Approved", approvedBy: "Dr. Ramesh" },
      { id: "Q402", type: "Component Request", item: "Solder Lead Roll", qty: 1, date: "13 Jul 2026", status: "Pending", approvedBy: "--" }
    ],
    issues: [
      { id: "I401", description: "LDR sensor sensitivity issue", date: "14 Jul 2026", severity: "Low", status: "Open" }
    ]
  },
  {
    id: "T-2026-005",
    name: "Team Innovate",
    project: "AI Assistant",
    leader: "Keerthana",
    faculty: "Dr. Meena",
    department: "Computer Science",
    stage: "Development",
    members: [
      { name: "Keerthana", initial: "Ke", color: "#F59E0B" },
      { name: "Varun", initial: "V", color: "#10B981" },
      { name: "Ezhil", initial: "Ez", color: "#EC4899" },
      { name: "Ganga", initial: "Ga", color: "#8B5CF6" }
    ],
    resources: [
      { id: "R501", name: "Raspberry Pi 4", type: "Component", qtyIssued: 2, qtyReturned: 1, dueDate: "25 Aug 2026", status: "Returned" },
      { id: "R502", name: "USB Microphone", type: "Tool", qtyIssued: 1, qtyReturned: 0, dueDate: "14 Jul 2026", status: "Overdue" },
      { id: "R503", name: "HDMI Cable", type: "Tool", qtyIssued: 2, qtyReturned: 2, dueDate: "14 Jul 2026", status: "Returned" }
    ],
    bookings: [
      { id: "B501", equipment: "3D Printer", date: "14 Jul 2026", timeSlot: "11:00 AM - 01:00 PM", purpose: "Pi Case Enclosure", status: "Confirmed" }
    ],
    requests: [
      { id: "Q501", type: "Component Request", item: "Pi Camera Module", qty: 1, date: "14 Jul 2026", status: "Pending", approvedBy: "--" }
    ],
    issues: []
  }
];

// --------------------------------------------------------------------------
// 2. STATE MANAGER
// --------------------------------------------------------------------------
const appState = {
  currentView: 'landing', // 'landing' | 'overview' | 'resources' | 'bookings' | 'requests' | 'issues'
  selectedTeamId: 'T-2026-001',
  recentlyViewedIds: ['T-2026-001', 'T-2026-002', 'T-2026-003', 'T-2026-004', 'T-2026-005'],
  
  // Landing View state variables
  filters: {
    search: '',
    faculty: 'All',
    department: 'All',
    resources: {
      search: '',
      status: 'All'
    },
    bookings: {
      equipment: 'All',
      status: 'All'
    },
    requests: {
      type: 'All',
      status: 'All'
    },
    issues: {
      severity: 'All',
      status: 'All'
    }
  },
  pagination: {
    landing: { page: 1, limit: 5 },
    resources: { page: 1, limit: 5 },
    bookings: { page: 1, limit: 5 },
    requests: { page: 1, limit: 5 },
    issues: { page: 1, limit: 5 }
  },

  // Active resource list sub-tab (All, Tool, Component)
  resourcesSubTab: 'All',

  // Master database
  teams: [...INITIAL_TEAMS]
};

// --------------------------------------------------------------------------
// 3. UI RENDERING CORE
// --------------------------------------------------------------------------

// Initializer
document.addEventListener('DOMContentLoaded', () => {
  initApp();
});

function initApp() {
  // Bind Static Events
  setupEventBindings();
  
  // Refresh & Render initial state
  refreshAppMetrics();
  renderLandingView();
  renderRecentlyViewed();
  
  // Load Lucide Icons
  lucide.createIcons();
}

// Global Metrics Evaluator
function refreshAppMetrics() {
  let totalOverdue = 0;
  let totalPending = 0;
  let totalBookingsToday = 0;
  let totalDefects = 0;

  appState.teams.forEach(team => {
    // 1. Tool Return Overdue (number of teams that have at least one overdue item)
    const hasOverdue = team.resources.some(r => r.status === 'Overdue');
    if (hasOverdue) totalOverdue++;

    // 2. Pending Requests (total sum of pending requests across all teams)
    const pendingCount = team.requests.filter(q => q.status === 'Pending').length;
    totalPending += pendingCount;

    // 3. Bookings Today (bookings on '14 Jul 2026' or just count of today's bookings)
    const bookingsToday = team.bookings.filter(b => b.date === '14 Jul 2026').length;
    totalBookingsToday += bookingsToday;

    // 4. Open Defects (open issues status)
    const openIssues = team.issues.filter(i => i.status === 'Open').length;
    totalDefects += openIssues;
  });

  // Write variables back into DOM
  document.getElementById('count-overdue').innerText = totalOverdue;
  document.getElementById('count-pending').innerText = totalPending;
  document.getElementById('count-bookings').innerText = totalBookingsToday;
  
  const defectsElem = document.getElementById('count-defects');
  if (defectsElem) defectsElem.innerText = totalDefects;
}

// --------------------------------------------------------------------------
// 4. ROUTER ENGINE (VIEW DISPATCHER)
// --------------------------------------------------------------------------
function switchView(targetView, selectedTeamId = null) {
  // Fade active transition effect
  const panels = document.querySelectorAll('.view-panel');
  panels.forEach(p => p.classList.remove('active'));

  if (selectedTeamId) {
    appState.selectedTeamId = selectedTeamId;
    
    // Add to recently viewed if not already in front
    appState.recentlyViewedIds = appState.recentlyViewedIds.filter(id => id !== selectedTeamId);
    appState.recentlyViewedIds.unshift(selectedTeamId);
    renderRecentlyViewed();

    // Reset detailed view filters on team change
    appState.filters.resources.search = '';
    appState.filters.resources.status = 'All';
    appState.filters.bookings.equipment = 'All';
    appState.filters.bookings.status = 'All';
    appState.filters.requests.type = 'All';
    appState.filters.requests.status = 'All';
    appState.filters.issues.severity = 'All';
    appState.filters.issues.status = 'All';

    // Reset pagination to first page
    appState.pagination.resources.page = 1;
    appState.pagination.bookings.page = 1;
    appState.pagination.requests.page = 1;
    appState.pagination.issues.page = 1;

    // Reset sub-tab
    appState.resourcesSubTab = 'All';
    const subTabBtns = document.querySelectorAll('.sub-tab-btn');
    subTabBtns.forEach(b => {
      b.classList.remove('active');
      if (b.getAttribute('data-filter') === 'All') b.classList.add('active');
    });

    // Reset form elements in DOM if they exist
    const rSearch = document.getElementById('res-search');
    if (rSearch) rSearch.value = '';
    const rStatus = document.getElementById('res-filter-status');
    if (rStatus) rStatus.value = 'All';
    const bEquip = document.getElementById('bookings-filter-equip');
    if (bEquip) bEquip.value = 'All';
    const bStatus = document.getElementById('bookings-filter-status');
    if (bStatus) bStatus.value = 'All';
    const qType = document.getElementById('requests-filter-type');
    if (qType) qType.value = 'All';
    const qStatus = document.getElementById('requests-filter-status');
    if (qStatus) qStatus.value = 'All';
    const iSev = document.getElementById('issues-filter-severity');
    if (iSev) iSev.value = 'All';
    const iStatus = document.getElementById('issues-filter-status');
    if (iStatus) iStatus.value = 'All';
  }

  appState.currentView = targetView;
  const viewTitle = document.getElementById('view-title');
  const viewSubtitle = document.getElementById('view-subtitle');
  if (viewSubtitle) viewSubtitle.style.display = 'none'; // Hide badge to match design exactly

  if (targetView === 'landing') {
    document.getElementById('view-landing').classList.add('active');
    viewTitle.innerText = "Team Workspace";
    renderLandingView();
  } 
  else if (targetView === 'overview') {
    document.getElementById('view-overview').classList.add('active');
    viewTitle.innerText = "Team Workspace Overview";
    renderOverviewView();
  } 
  else {
    // Sub-view Tab tables (resources, bookings, requests, issues)
    document.getElementById('view-details-tables').classList.add('active');
    
    // Select correct tab in Details Section and update title
    activateDetailTab(targetView);
  }

}

// Global Redirect Function for Teammate Modules
function redirectToPage(pageId) {
  // 1. Remove active class from all view panels
  const panels = document.querySelectorAll('.view-panel');
  panels.forEach(p => p.classList.remove('active'));

  // 2. Select target sidebar link and add active class, removing from others
  const sidebarItems = document.querySelectorAll('.sidebar-menu .menu-item');
  sidebarItems.forEach(item => {
    item.classList.remove('active');
    if (item.getAttribute('data-page') === pageId) {
      item.classList.add('active');
    }
  });

  // 3. Update top header title
  const viewTitle = document.getElementById('view-title');
  const pageNameMap = {
    'dashboard': 'Dashboard',
    'inventory': 'Inventory Management',
    'material-requests': 'Material Requests',
    'equipment-booking': 'Equipment Booking',
    'material-returns': 'Material Returns',
    'equipment-tracking': 'Equipment Tracking',
    'defect-tracking': 'Defect Tracking',
    'reports': 'Reports & Analytics',
    'settings': 'Settings'
  };
  
  const pageTitle = pageNameMap[pageId] || 'System Module';
  if (viewTitle) {
    viewTitle.innerText = pageTitle;
  }

  // 4. Update the placeholder view details
  const placeholderIcon = document.getElementById('placeholder-icon');
  const placeholderTitle = document.getElementById('placeholder-title');
  const placeholderDescription = document.getElementById('placeholder-description');
  const placeholderIconWrap = document.getElementById('placeholder-icon-wrap');

  // Set page icon and details
  const pageDetails = {
    'dashboard': {
      icon: 'layout-dashboard',
      bg: 'var(--color-info-bg)',
      color: 'var(--color-info)',
      desc: 'The Lab Dashboard provides overview statistics, booking volume, pending tasks, and lab alerts. This interface is managed externally by teammate modules.'
    },
    'inventory': {
      icon: 'package',
      bg: 'hsl(142, 65%, 95%)',
      color: 'var(--color-success)',
      desc: 'The Lab Inventory Management system monitors tool usage, component stock levels, and automated parts ordering. This page is managed externally by teammate modules.'
    },
    'material-requests': {
      icon: 'git-pull-request',
      bg: 'var(--color-pending-bg)',
      color: 'var(--color-pending)',
      desc: 'The Material Requests workflow handles approval and issuing of new sensors, microcontroller boards, and tools to project teams. This page is managed externally by teammate modules.'
    },
    'equipment-booking': {
      icon: 'calendar',
      bg: 'var(--color-info-bg)',
      color: 'var(--color-info)',
      desc: 'The Equipment Booking schedule coordinates 3D Printer, Laser Cutter, and CNC Machine time slots. This page is managed externally by teammate modules.'
    },
    'material-returns': {
      icon: 'rotate-ccw',
      bg: 'var(--color-danger-bg)',
      color: 'var(--color-danger)',
      desc: 'The Material Returns portal handles the logging, inspection, and return processing of tools and components back to the stock room. This page is managed externally by teammate modules.'
    },
    'equipment-tracking': {
      icon: 'map-pin',
      bg: 'hsl(190, 70%, 95%)',
      color: 'hsl(190, 80%, 45%)',
      desc: 'The Equipment Tracking tracker traces portable testing tools, multimeters, and logic analyzers using Bluetooth beacons. This page is managed externally by teammate modules.'
    },
    'defect-tracking': {
      icon: 'alert-triangle',
      bg: 'var(--color-danger-bg)',
      color: 'var(--color-danger)',
      desc: 'The Defect Tracking ticketing system logs broken tools, machine malfunctions, and filament jams for immediate technician review. This page is managed externally by teammate modules.'
    },
    'reports': {
      icon: 'bar-chart-2',
      bg: 'hsl(270, 60%, 95%)',
      color: 'hsl(270, 70%, 50%)',
      desc: 'Reports and Analytics aggregates data on machine utilization rates, popular tools, and material consumption rates. This page is managed externally by teammate modules.'
    },
    'settings': {
      icon: 'settings',
      bg: 'hsl(215, 30%, 91%)',
      color: 'var(--color-text-main)',
      desc: 'System Configuration, technician assignment permissions, notification rules, and database tools. This page is managed externally by teammate modules.'
    }
  };

  const details = pageDetails[pageId] || {
    icon: 'arrow-up-right',
    bg: 'var(--color-brand-blue-light)',
    color: 'var(--color-brand-blue)',
    desc: 'This page is managed externally by another system component. Redirecting to your teammate\'s interface.'
  };

  if (placeholderIcon) {
    placeholderIcon.setAttribute('data-lucide', details.icon);
  }
  if (placeholderIconWrap) {
    placeholderIconWrap.style.backgroundColor = details.bg;
    placeholderIconWrap.style.color = details.color;
  }
  if (placeholderTitle) {
    placeholderTitle.innerText = pageTitle;
  }
  if (placeholderDescription) {
    placeholderDescription.innerText = details.desc;
  }

  // Show placeholder panel
  document.getElementById('view-external-placeholder').classList.add('active');

  // Trigger Lucide icon render for new icons
  lucide.createIcons();

  // Scroll to top
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// --------------------------------------------------------------------------
// 5. LANDING PAGE RENDERING
// --------------------------------------------------------------------------
function renderLandingView() {
  const tbody = document.getElementById('teams-table-body');
  tbody.innerHTML = '';

  // Get current filters
  const { search, faculty } = appState.filters;

  // Filter teams array
  const filteredTeams = appState.teams.filter(team => {
    // Multivariable Search match
    const matchesSearch = 
      team.name.toLowerCase().includes(search.toLowerCase()) ||
      team.project.toLowerCase().includes(search.toLowerCase()) ||
      team.leader.toLowerCase().includes(search.toLowerCase()) ||
      team.id.toLowerCase().includes(search.toLowerCase());

    const matchesFaculty = (faculty === 'All' || team.faculty === faculty);

    return matchesSearch && matchesFaculty;
  });

  // Paginate list
  const pgState = appState.pagination.landing;
  const totalItems = filteredTeams.length;
  const totalPages = Math.ceil(totalItems / pgState.limit) || 1;
  
  if (pgState.page > totalPages) pgState.page = totalPages;
  
  const startIndex = (pgState.page - 1) * pgState.limit;
  const endIndex = Math.min(startIndex + pgState.limit, totalItems);
  const paginatedTeams = filteredTeams.slice(startIndex, endIndex);

  // Render rows
  if (paginatedTeams.length === 0) {
    tbody.innerHTML = `<tr><td colspan="5" style="text-align: center; color: var(--color-text-muted); padding: 2rem;">No matching teams found. Try adjusting your filters.</td></tr>`;
  } else {
    paginatedTeams.forEach(team => {
      const tr = document.createElement('tr');

      tr.innerHTML = `
        <td><strong>${team.id}</strong></td>
        <td>${team.project}</td>
        <td>${team.leader}</td>
        <td>${team.faculty}</td>
        <td>
          <a href="#" class="action-link" data-id="${team.id}">
            <i data-lucide="folder-open"></i> Open Workspace
          </a>
        </td>
      `;
      tbody.appendChild(tr);
    });

    // Row Click navigation mapping
    tbody.querySelectorAll('.action-link').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        const teamId = btn.getAttribute('data-id');
        switchView('overview', teamId);
      });
    });
  }

  // Update Pagination Info
  document.getElementById('teams-pagination-info').innerText = 
    totalItems > 0 
      ? `Showing ${startIndex + 1} to ${endIndex} of ${totalItems} teams`
      : `Showing 0 to 0 of 0 teams`;

  // Draw Page Navigation numbers
  const pagesContainer = document.getElementById('teams-pagination-pages');
  pagesContainer.innerHTML = '';
  
  for (let i = 1; i <= totalPages; i++) {
    const pageTag = document.createElement('span');
    pageTag.className = `pagination-page-tag ${i === pgState.page ? 'active' : ''}`;
    pageTag.innerText = i;
    pageTag.addEventListener('click', () => {
      pgState.page = i;
      renderLandingView();
      lucide.createIcons();
    });
    pagesContainer.appendChild(pageTag);
  }

  // Button States
  document.getElementById('teams-prev-btn').disabled = (pgState.page === 1);
  document.getElementById('teams-next-btn').disabled = (pgState.page === totalPages);
}

// Draw Recently Viewed row
function renderRecentlyViewed() {
  const container = document.getElementById('recently-viewed-container');
  container.innerHTML = '';

  appState.recentlyViewedIds.forEach(id => {
    const team = appState.teams.find(t => t.id === id);
    if (!team) return;

    let iconClass = 'alpha';
    if (team.name.includes('Delta')) iconClass = 'delta';
    if (team.name.includes('Phoenix')) iconClass = 'phoenix';
    if (team.name.includes('Sigma')) iconClass = 'sigma';
    if (team.name.includes('Innovate')) iconClass = 'innovate';

    const card = document.createElement('div');
    card.className = 'recent-team-card';
    card.innerHTML = `
      <div class="recent-icon-wrap ${iconClass}">
        <i data-lucide="folder-open"></i>
      </div>
      <div class="recent-info">
        <h4>${team.id}</h4>
        <p>${team.project}</p>
      </div>
    `;
    card.addEventListener('click', () => {
      switchView('overview', team.id);
    });
    container.appendChild(card);
  });
}

// --------------------------------------------------------------------------
// 6. TEAM OVERVIEW PAGE (TEAM DETAILS)
// --------------------------------------------------------------------------
function renderOverviewView() {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  if (!team) return;

  // 1. Text metadata binds
  document.getElementById('detail-team-name').innerText = team.id;
  document.getElementById('detail-project-name').innerText = team.project;
  document.getElementById('detail-team-id').innerText = team.id;
  document.getElementById('detail-team-leader').innerText = team.leader;
  document.getElementById('detail-team-faculty').innerText = team.faculty;

  // 2. Member avatars list
  const avatarsWrap = document.getElementById('detail-team-members');
  avatarsWrap.innerHTML = '';
  
  team.members.forEach((m, idx) => {
    if (idx < 3) {
      const avatar = document.createElement('div');
      avatar.className = 'member-avatar';
      avatar.style.backgroundColor = m.color;
      avatar.innerText = m.initial;
      avatar.title = m.name;
      avatarsWrap.appendChild(avatar);
    }
  });
  
  if (team.members.length > 3) {
    const overflow = document.createElement('div');
    overflow.className = 'member-avatar overflow-badge';
    overflow.innerText = `+${team.members.length - 3}`;
    overflow.title = `${team.members.slice(3).map(m => m.name).join(', ')}`;
    avatarsWrap.appendChild(overflow);
  }

  // 3. Quick Summary count indicators (Calculated dynamically)
  const upbookings = team.bookings.filter(b => b.status === 'Upcoming' || b.status === 'Confirmed').length;
  document.getElementById('sum-bookings-count').innerText = upbookings;
  document.getElementById('sum-bookings-sub').innerText = `${upbookings} Scheduled`;

  const totalTools = team.resources.filter(r => r.type === 'Tool');
  const overdueTools = totalTools.filter(r => r.status === 'Overdue').length;
  document.getElementById('sum-tools-count').innerText = totalTools.length;
  document.getElementById('sum-tools-sub').innerText = `${overdueTools} Overdue`;
  document.getElementById('sum-tools-sub').className = overdueTools > 0 ? "mini-card-sub text-danger" : "mini-card-sub text-info";

  const totalComps = team.resources.filter(r => r.type === 'Component');
  const pendingReturn = totalComps.filter(r => r.status === 'Overdue').length; // let's label overdue components as pending return
  document.getElementById('sum-components-count').innerText = totalComps.length;
  document.getElementById('sum-components-sub').innerText = `${pendingReturn} Overdue`;
  document.getElementById('sum-components-sub').className = pendingReturn > 0 ? "mini-card-sub text-warning" : "mini-card-sub text-info";

  const pendingRequests = team.requests.filter(q => q.status === 'Pending').length;
  document.getElementById('sum-requests-count').innerText = pendingRequests;
  document.getElementById('sum-requests-sub').innerText = `${pendingRequests} Pending`;
  document.getElementById('sum-requests-sub').className = pendingRequests > 0 ? "mini-card-sub text-warning" : "mini-card-sub text-info";
}

// --------------------------------------------------------------------------
// 7. SUB-PAGES & TABBED TABLES
// --------------------------------------------------------------------------
function activateDetailTab(tabId) {
  // Tab headers activation
  const tabBtns = document.querySelectorAll('.tab-btn');
  tabBtns.forEach(btn => {
    btn.classList.remove('active');
    if (btn.getAttribute('data-tab') === tabId) {
      btn.classList.add('active');
    }
  });

  // Content panels activation
  const panels = document.querySelectorAll('.tab-panel');
  panels.forEach(p => p.classList.remove('active'));
  
  const targetPanel = document.getElementById(`tab-${tabId}`);
  if (targetPanel) {
    targetPanel.classList.add('active');
  }

  // Update dynamic header title to match screenshots 3, 4, 5
  const viewTitle = document.getElementById('view-title');
  if (viewTitle) {
    if (tabId === 'resources') viewTitle.innerText = "Resources";
    if (tabId === 'bookings') viewTitle.innerText = "Equipment Bookings";
    if (tabId === 'requests') viewTitle.innerText = "Requests";
    if (tabId === 'issues') viewTitle.innerText = "Issues";
  }

  // Draw correct table rows
  if (tabId === 'resources') renderResourcesTable();
  if (tabId === 'bookings') renderBookingsTable();
  if (tabId === 'requests') renderRequestsTable();
  if (tabId === 'issues') renderIssuesTable();
}

/* Tab 3: RESOURCES TABLE */
function renderResourcesTable() {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  if (!team) return;

  // Update counts
  const total = team.resources.length;
  const tools = team.resources.filter(r => r.type === 'Tool').length;
  const comps = team.resources.filter(r => r.type === 'Component').length;

  document.getElementById('cnt-res-all').innerText = total;
  document.getElementById('cnt-res-tools').innerText = tools;
  document.getElementById('cnt-res-comps').innerText = comps;

  // Filter list
  const filteredRes = team.resources.filter(r => {
    // Sub-tab filter
    const matchesSubTab = (appState.resourcesSubTab === 'All' || r.type === appState.resourcesSubTab);
    // Search filter
    const matchesSearch = r.name.toLowerCase().includes(appState.filters.resources.search.toLowerCase());
    // Status filter
    const matchesStatus = (appState.filters.resources.status === 'All' || r.status === appState.filters.resources.status);

    return matchesSubTab && matchesSearch && matchesStatus;
  });

  // Paginate list
  const pgState = appState.pagination.resources;
  const totalItems = filteredRes.length;
  const totalPages = Math.ceil(totalItems / pgState.limit) || 1;
  if (pgState.page > totalPages) pgState.page = totalPages;

  const start = (pgState.page - 1) * pgState.limit;
  const end = Math.min(start + pgState.limit, totalItems);
  const pageData = filteredRes.slice(start, end);

  // Render rows
  const tbody = document.getElementById('resources-table-body');
  tbody.innerHTML = '';

  if (pageData.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--color-text-muted); padding: 1.5rem;">No items cataloged.</td></tr>`;
  } else {
    pageData.forEach(r => {
      const tr = document.createElement('tr');
      const qtyWithTeam = Math.max(r.qtyIssued - r.qtyReturned, 0);
      
      let statusClass = 'success';
      if (r.status === 'Overdue') statusClass = 'danger';
      
      tr.innerHTML = `
        <td><strong>${r.name}</strong></td>
        <td>${r.type}</td>
        <td>${r.qtyIssued}</td>
        <td>${r.qtyReturned}</td>
        <td>${qtyWithTeam}</td>
        <td>${r.dueDate}</td>
        <td><span class="badge-status ${statusClass}">${r.status}</span></td>
      `;
      tbody.appendChild(tr);
    });
  }

  // Draw Pagination Bar
  renderTablePaginationControls('resources', totalItems, start, end, 'res-pagination', renderResourcesTable);
}

/* Tab 4: BOOKINGS TABLE */
function renderBookingsTable() {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  if (!team) return;

  // Filter list
  const filteredBookings = team.bookings.filter(b => {
    // Equipment filter
    const matchesEquip = (appState.filters.bookings.equipment === 'All' || b.equipment === appState.filters.bookings.equipment);
    // Status filter
    const matchesStatus = (appState.filters.bookings.status === 'All' || b.status === appState.filters.bookings.status);

    return matchesEquip && matchesStatus;
  });

  const pgState = appState.pagination.bookings;
  const totalItems = filteredBookings.length;
  const totalPages = Math.ceil(totalItems / pgState.limit) || 1;
  if (pgState.page > totalPages) pgState.page = totalPages;

  const start = (pgState.page - 1) * pgState.limit;
  const end = Math.min(start + pgState.limit, totalItems);
  const pageData = filteredBookings.slice(start, end);

  const tbody = document.getElementById('bookings-table-body');
  tbody.innerHTML = '';

  if (pageData.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--color-text-muted); padding: 1.5rem;">No equipment bookings recorded.</td></tr>`;
  } else {
    pageData.forEach(b => {
      const tr = document.createElement('tr');
      
      let statusClass = 'info';
      if (b.status === 'Confirmed') statusClass = 'success';
      if (b.status === 'Pending') statusClass = 'pending';

      tr.innerHTML = `
        <td><strong>${b.equipment}</strong></td>
        <td>${b.date}</td>
        <td>${b.timeSlot}</td>
        <td>${b.purpose}</td>
        <td><span class="badge-status ${statusClass}">${b.status}</span></td>
        <td>
          <button class="btn-table-action btn-redirect-page" data-target="equipment-booking" style="background-color: var(--color-brand-blue-light); color: var(--color-brand-blue); border-color: transparent;">Go to Bookings</button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    tbody.querySelectorAll('.btn-redirect-page').forEach(btn => {
      btn.addEventListener('click', () => {
        const target = btn.getAttribute('data-target');
        redirectToPage(target);
      });
    });
  }

  renderTablePaginationControls('bookings', totalItems, start, end, 'bookings-pagination', renderBookingsTable);
}

/* Tab 5: REQUESTS TABLE */
function renderRequestsTable() {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  if (!team) return;

  // Filter list
  const filteredRequests = team.requests.filter(q => {
    // Type filter
    const matchesType = (appState.filters.requests.type === 'All' || q.type === appState.filters.requests.type);
    // Status filter
    const matchesStatus = (appState.filters.requests.status === 'All' || q.status === appState.filters.requests.status);

    return matchesType && matchesStatus;
  });

  const pgState = appState.pagination.requests;
  const totalItems = filteredRequests.length;
  const totalPages = Math.ceil(totalItems / pgState.limit) || 1;
  if (pgState.page > totalPages) pgState.page = totalPages;

  const start = (pgState.page - 1) * pgState.limit;
  const end = Math.min(start + pgState.limit, totalItems);
  const pageData = filteredRequests.slice(start, end);

  const tbody = document.getElementById('requests-table-body');
  tbody.innerHTML = '';

  if (pageData.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: var(--color-text-muted); padding: 1.5rem;">No requests submitted.</td></tr>`;
  } else {
    pageData.forEach(q => {
      const tr = document.createElement('tr');
      
      let statusClass = 'pending';
      if (q.status === 'Approved') statusClass = 'success';

      tr.innerHTML = `
        <td>${q.type}</td>
        <td><strong>${q.item}</strong></td>
        <td>${q.qty}</td>
        <td>${q.date}</td>
        <td><span class="badge-status ${statusClass}">${q.status}</span></td>
        <td>${q.approvedBy}</td>
        <td>
          <button class="btn-table-action btn-redirect-page" data-target="material-requests" style="background-color: var(--color-brand-blue-light); color: var(--color-brand-blue); border-color: transparent;">Go to Requests</button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    tbody.querySelectorAll('.btn-redirect-page').forEach(btn => {
      btn.addEventListener('click', () => {
        const target = btn.getAttribute('data-target');
        redirectToPage(target);
      });
    });
  }

  renderTablePaginationControls('requests', totalItems, start, end, 'requests-pagination', renderRequestsTable);
}

/* Tab 6: ISSUES TABLE */
function renderIssuesTable() {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  if (!team) return;

  // Filter list
  const filteredIssues = team.issues.filter(i => {
    // Severity filter
    const matchesSeverity = (appState.filters.issues.severity === 'All' || i.severity === appState.filters.issues.severity);
    // Status filter
    const matchesStatus = (appState.filters.issues.status === 'All' || i.status === appState.filters.issues.status);

    return matchesSeverity && matchesStatus;
  });

  const pgState = appState.pagination.issues;
  const totalItems = filteredIssues.length;
  const totalPages = Math.ceil(totalItems / pgState.limit) || 1;
  if (pgState.page > totalPages) pgState.page = totalPages;

  const start = (pgState.page - 1) * pgState.limit;
  const end = Math.min(start + pgState.limit, totalItems);
  const pageData = filteredIssues.slice(start, end);

  const tbody = document.getElementById('issues-table-body');
  tbody.innerHTML = '';

  if (pageData.length === 0) {
    tbody.innerHTML = `<tr><td colspan="6" style="text-align: center; color: var(--color-text-muted); padding: 1.5rem;">No defects reported.</td></tr>`;
  } else {
    pageData.forEach(i => {
      const tr = document.createElement('tr');
      
      let statusClass = 'pending';
      if (i.status === 'Closed') statusClass = 'success';
      if (i.status === 'Open') statusClass = 'danger';

      tr.innerHTML = `
        <td>${i.id}</td>
        <td><strong>${i.description}</strong></td>
        <td>${i.date}</td>
        <td><span class="badge-status ${i.severity.toLowerCase() === 'critical' ? 'danger' : i.severity.toLowerCase() === 'high' ? 'pending' : 'info'}">${i.severity}</span></td>
        <td><span class="badge-status ${statusClass}">${i.status}</span></td>
        <td>
          <button class="btn-table-action btn-redirect-page" data-target="defect-tracking" style="background-color: var(--color-brand-blue-light); color: var(--color-brand-blue); border-color: transparent;">Go to Defects</button>
        </td>
      `;
      tbody.appendChild(tr);
    });

    tbody.querySelectorAll('.btn-redirect-page').forEach(btn => {
      btn.addEventListener('click', () => {
        const target = btn.getAttribute('data-target');
        redirectToPage(target);
      });
    });
  }

  renderTablePaginationControls('issues', totalItems, start, end, 'issues-pagination', renderIssuesTable);
}

// --------------------------------------------------------------------------
// 8. PAGINATION CONTROLS DRAWER
// --------------------------------------------------------------------------
function renderTablePaginationControls(key, totalItems, start, end, targetDivId, callback) {
  const container = document.getElementById(targetDivId);
  if (!container) return;

  const pgState = appState.pagination[key];
  const totalPages = Math.ceil(totalItems / pgState.limit) || 1;

  container.innerHTML = `
    <span class="pagination-info">Showing ${totalItems > 0 ? start + 1 : 0} to ${end} of ${totalItems} rows</span>
    <div class="pagination-controls-wrap">
      <button class="btn-pagination-arrow btn-prev" ${pgState.page === 1 ? 'disabled' : ''}><i data-lucide="chevron-left"></i></button>
      <div class="pagination-pages">
        <!-- Render tags -->
      </div>
      <button class="btn-pagination-arrow btn-next" ${pgState.page === totalPages ? 'disabled' : ''}><i data-lucide="chevron-right"></i></button>
    </div>
    <div class="rows-per-page">
      <select class="sel-rows">
        <option value="5" ${pgState.limit === 5 ? 'selected' : ''}>5 / page</option>
        <option value="10" ${pgState.limit === 10 ? 'selected' : ''}>10 / page</option>
        <option value="20" ${pgState.limit === 20 ? 'selected' : ''}>20 / page</option>
      </select>
    </div>
  `;

  // Page Numbers
  const pagesContainer = container.querySelector('.pagination-pages');
  for (let i = 1; i <= totalPages; i++) {
    const pageTag = document.createElement('span');
    pageTag.className = `pagination-page-tag ${i === pgState.page ? 'active' : ''}`;
    pageTag.innerText = i;
    pageTag.addEventListener('click', () => {
      pgState.page = i;
      callback();
      lucide.createIcons();
    });
    pagesContainer.appendChild(pageTag);
  }

  // Bind Arrows
  container.querySelector('.btn-prev').addEventListener('click', () => {
    if (pgState.page > 1) {
      pgState.page--;
      callback();
      lucide.createIcons();
    }
  });

  container.querySelector('.btn-next').addEventListener('click', () => {
    if (pgState.page < totalPages) {
      pgState.page++;
      callback();
      lucide.createIcons();
    }
  });

  // Bind Rows Select
  container.querySelector('.sel-rows').addEventListener('change', (e) => {
    pgState.limit = parseInt(e.target.value, 10);
    pgState.page = 1;
    callback();
    lucide.createIcons();
  });
}

// --------------------------------------------------------------------------
// 9. EVENT BINDINGS & ACTIONS
// --------------------------------------------------------------------------
function setupEventBindings() {
  
  // Landing Filters
  document.getElementById('search-query').addEventListener('input', (e) => {
    appState.filters.search = e.target.value;
    appState.pagination.landing.page = 1;
    renderLandingView();
    lucide.createIcons();
  });

  document.getElementById('filter-faculty').addEventListener('change', (e) => {
    appState.filters.faculty = e.target.value;
    appState.pagination.landing.page = 1;
    renderLandingView();
    lucide.createIcons();
  });

  document.getElementById('btn-reset-filters').addEventListener('click', () => {
    document.getElementById('search-query').value = '';
    document.getElementById('filter-faculty').value = 'All';
    
    appState.filters.search = '';
    appState.filters.faculty = 'All';
    appState.filters.department = 'All';
    appState.pagination.landing.page = 1;
    
    renderLandingView();
    lucide.createIcons();
    showToast("Filters successfully reset!");
  });

  // Rows Limit landing dropdown
  document.getElementById('teams-rows-select').addEventListener('change', (e) => {
    appState.pagination.landing.limit = parseInt(e.target.value, 10);
    appState.pagination.landing.page = 1;
    renderLandingView();
    lucide.createIcons();
  });

  document.getElementById('teams-prev-btn').addEventListener('click', () => {
    if (appState.pagination.landing.page > 1) {
      appState.pagination.landing.page--;
      renderLandingView();
      lucide.createIcons();
    }
  });

  document.getElementById('teams-next-btn').addEventListener('click', () => {
    const filteredCount = appState.teams.filter(team => {
      const matchesSearch = 
        team.name.toLowerCase().includes(appState.filters.search.toLowerCase()) ||
        team.project.toLowerCase().includes(appState.filters.search.toLowerCase()) ||
        team.leader.toLowerCase().includes(appState.filters.search.toLowerCase());
      const matchesFaculty = (appState.filters.faculty === 'All' || team.faculty === appState.filters.faculty);
      return matchesSearch && matchesFaculty;
    }).length;
    
    const maxPages = Math.ceil(filteredCount / appState.pagination.landing.limit);
    if (appState.pagination.landing.page < maxPages) {
      appState.pagination.landing.page++;
      renderLandingView();
      lucide.createIcons();
    }
  });

  // Metric cards jumps
  document.querySelectorAll('.view-detail-link').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const target = link.getAttribute('data-target');
      switchView(target, appState.selectedTeamId);
    });
  });

  // Detail Sub-tabs buttons
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const tab = btn.getAttribute('data-tab');
      activateDetailTab(tab);
      lucide.createIcons();
    });
  });

  // Back Navigations
  document.getElementById('btn-back-to-teams').addEventListener('click', (e) => {
    e.preventDefault();
    switchView('landing');
  });

  document.getElementById('btn-back-to-overview').addEventListener('click', (e) => {
    e.preventDefault();
    switchView('overview');
  });

  // Placeholder navigation back links
  document.getElementById('btn-placeholder-back').addEventListener('click', (e) => {
    e.preventDefault();
    switchView('landing');
  });

  document.getElementById('btn-placeholder-home').addEventListener('click', () => {
    switchView('landing');
  });

  // Sidebar Menu Item Click Handling
  document.querySelectorAll('.sidebar-menu .menu-item').forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault();
      const page = item.getAttribute('data-page');
      if (page === 'team-workspace') {
        switchView('landing');
      } else {
        redirectToPage(page);
      }
    });
  });

  // Click View Details on Overview activity cards
  document.querySelectorAll('.activity-card').forEach(card => {
    card.addEventListener('click', () => {
      const tab = card.getAttribute('data-tab');
      switchView(tab);
    });
  });

  // Click mini cards on Overview
  document.querySelectorAll('.select-details-tab').forEach(card => {
    card.addEventListener('click', () => {
      const tab = card.getAttribute('data-tab');
      switchView(tab);
    });
  });

  // Resource Sub-tab filters (All / Tool / Component)
  document.querySelectorAll('.sub-tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.sub-tab-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      appState.resourcesSubTab = btn.getAttribute('data-filter');
      appState.pagination.resources.page = 1;
      renderResourcesTable();
    });
  });

  // Modal Closing binds
  document.getElementById('btn-close-modal').addEventListener('click', closeModal);
  document.getElementById('action-modal').addEventListener('click', (e) => {
    if (e.target.id === 'action-modal') closeModal();
  });

  // Exports click trigger
  document.querySelectorAll('.btn-export').forEach(btn => {
    btn.addEventListener('click', () => {
      const type = btn.getAttribute('data-type');
      showToast(`Exported ${type} spreadsheet successfully!`);
    });
  });

  // Filter click visual trigger
  document.querySelectorAll('.btn-filter').forEach(btn => {
    btn.addEventListener('click', () => {
      showToast("Advanced table sorting enabled.");
    });
  });

  // Resources detailed tab inputs
  document.getElementById('res-search').addEventListener('input', (e) => {
    appState.filters.resources.search = e.target.value;
    appState.pagination.resources.page = 1;
    renderResourcesTable();
  });
  document.getElementById('res-filter-status').addEventListener('change', (e) => {
    appState.filters.resources.status = e.target.value;
    appState.pagination.resources.page = 1;
    renderResourcesTable();
  });

  // Bookings detailed tab inputs
  document.getElementById('bookings-filter-equip').addEventListener('change', (e) => {
    appState.filters.bookings.equipment = e.target.value;
    appState.pagination.bookings.page = 1;
    renderBookingsTable();
  });
  document.getElementById('bookings-filter-status').addEventListener('change', (e) => {
    appState.filters.bookings.status = e.target.value;
    appState.pagination.bookings.page = 1;
    renderBookingsTable();
  });

  // Requests detailed tab inputs
  document.getElementById('requests-filter-type').addEventListener('change', (e) => {
    appState.filters.requests.type = e.target.value;
    appState.pagination.requests.page = 1;
    renderRequestsTable();
  });
  document.getElementById('requests-filter-status').addEventListener('change', (e) => {
    appState.filters.requests.status = e.target.value;
    appState.pagination.requests.page = 1;
    renderRequestsTable();
  });

  // Issues detailed tab inputs
  document.getElementById('issues-filter-severity').addEventListener('change', (e) => {
    appState.filters.issues.severity = e.target.value;
    appState.pagination.issues.page = 1;
    renderIssuesTable();
  });
  document.getElementById('issues-filter-status').addEventListener('change', (e) => {
    appState.filters.issues.status = e.target.value;
    appState.pagination.issues.page = 1;
    renderIssuesTable();
  });
}

// --------------------------------------------------------------------------
// 10. INTERACTIVE WRITE OPERATIONS
// --------------------------------------------------------------------------

// Return Item Modal Builder
function openReturnModal(resId) {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  const resource = team.resources.find(r => r.id === resId);

  const modal = document.getElementById('action-modal');
  const title = document.getElementById('modal-title');
  const body = document.getElementById('modal-body-content');

  title.innerText = `Return Resource: ${resource.name}`;
  const maxToReturn = resource.qtyIssued - resource.qtyReturned;

  body.innerHTML = `
    <p style="font-size: 0.85rem; color: var(--color-text-muted);">
      Specify the quantity of <strong>${resource.name}</strong> being returned to the inventory.
    </p>
    <div class="form-group">
      <label>Current Outstanding Issued</label>
      <input type="text" value="${maxToReturn}" disabled style="background-color: var(--color-bg-app);">
    </div>
    <div class="form-group">
      <label for="return-qty">Quantity to Return</label>
      <input type="number" id="return-qty" min="1" max="${maxToReturn}" value="${maxToReturn}">
    </div>
    <div class="modal-actions">
      <button class="btn btn-secondary" id="btn-modal-cancel">Cancel</button>
      <button class="btn btn-primary" id="btn-modal-submit">Confirm Return</button>
    </div>
  `;

  // Bind controls inside modal
  document.getElementById('btn-modal-cancel').addEventListener('click', closeModal);
  document.getElementById('btn-modal-submit').addEventListener('click', () => {
    const qty = parseInt(document.getElementById('return-qty').value, 10);
    if (qty >= 1 && qty <= maxToReturn) {
      // Apply modification
      resource.qtyReturned += qty;
      if (resource.qtyReturned === resource.qtyIssued) {
        resource.status = 'Returned';
      }
      
      closeModal();
      refreshAppMetrics();
      renderResourcesTable();
      showToast(`Returned ${qty}x ${resource.name} successfully!`);
    } else {
      alert(`Please enter a quantity between 1 and ${maxToReturn}.`);
    }
  });

  modal.classList.add('active');
}

// Confirm Equipment Booking
function confirmBooking(bookingId) {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  const booking = team.bookings.find(b => b.id === bookingId);
  
  booking.status = 'Confirmed';
  refreshAppMetrics();
  renderBookingsTable();
  showToast(`Booking for ${booking.equipment} is now Confirmed!`);
}

// Approve Request
function approveRequest(reqId) {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  const req = team.requests.find(q => q.id === reqId);

  req.status = 'Approved';
  req.approvedBy = 'Lab In-Charge';
  
  // If component/tool request, let's append it to team resources!
  if (req.type.includes('Component') || req.type.includes('Tool')) {
    const existing = team.resources.find(r => r.name.toLowerCase() === req.item.toLowerCase());
    if (existing) {
      existing.qtyIssued += req.qty;
      if (existing.status === 'Returned') existing.status = 'Issued';
    } else {
      team.resources.push({
        id: 'R_NEW_' + Date.now(),
        name: req.item,
        type: req.type.includes('Tool') ? 'Tool' : 'Component',
        qtyIssued: req.qty,
        qtyReturned: 0,
        dueDate: '20 Aug 2026',
        status: 'Returned' // Initially in safe status
      });
    }
  } else if (req.type.includes('Booking')) {
    team.bookings.push({
      id: 'B_NEW_' + Date.now(),
      equipment: req.item,
      date: '16 Jul 2026',
      timeSlot: '02:00 PM - 04:00 PM',
      purpose: 'Approved Request Allocation',
      status: 'Confirmed'
    });
  }

  refreshAppMetrics();
  renderRequestsTable();
  showToast(`Request for ${req.item} approved successfully!`);
}

// Resolve Issue Ticket
function resolveIssue(issueId) {
  const team = appState.teams.find(t => t.id === appState.selectedTeamId);
  const issue = team.issues.find(i => i.id === issueId);

  issue.status = 'Closed';
  refreshAppMetrics();
  renderIssuesTable();
  showToast(`Defect ticket ${issue.id} marked as Resolved!`);
}

// Utility Modal Close
function closeModal() {
  document.getElementById('action-modal').classList.remove('active');
}

// Toaster Notification
function showToast(message) {
  const toast = document.getElementById('toast-notification');
  document.getElementById('toast-message').innerText = message;
  
  toast.classList.add('active');
  setTimeout(() => {
    toast.classList.remove('active');
  }, 2500);
}
